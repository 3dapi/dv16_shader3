// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXBUFFER9			PDVB;
typedef LPDIRECT3DINDEXBUFFER9			PDIB;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef	LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxN
	{
		VEC3	p;
		VEC3	n;
		enum { FVF = (D3DFVF_XYZ | D3DFVF_NORMAL),};
	};

protected:
	PDEV		m_pDev;
	
	PDVD		m_pFVF;
    PDEF		m_pEft;

	MATA		m_mtWld;
	MATA		m_mtRot;

	PDTX		m_pTxSph;
	CMcMesh*	m_pTeapot;

public:
	CShaderEx();
	~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	void	SetTexture(PDTX	pTex);
};


#endif


