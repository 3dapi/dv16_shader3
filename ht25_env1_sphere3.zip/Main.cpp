

#include "_StdAfx.h"


const	int	ENVMAP_RESOLUTION	= 512;


CMain::CMain()
:	m_pD3DXFont	(0)
,	m_pInput	(0)
,	m_pCam		(0)
,	m_pGrid		(0)
,	m_pShader	(0)
{
	m_pSkyBox	= NULL;
	m_pRndEnv	= NULL;
	m_pTxSph	= NULL;
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(m_pInput , CMcInput		, m_hWnd);
	SAFE_NEWCREATE1(m_pCam	 , CMcCam		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pGrid	 , CMcGrid		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pShader, CShaderEx	, m_pd3dDevice);

	
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, NONANTIALIASED_QUALITY
		, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;



	m_pSkyBox      = new CMcMesh;
	m_pSkyBox->Create(m_pd3dDevice, "data/lobby_skybox.x", "data/");

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pShader	);

	SAFE_DELETE(	m_pSkyBox	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	HRESULT	hr = 0;
	PDEV	pDev = m_pd3dDevice;

	LPDIRECT3DSURFACE9	pSrf;
	D3DSURFACE_DESC		dscC;
	D3DSURFACE_DESC		dscD;

	if(FAILED(pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pSrf)))
			return-1;

	pSrf->GetDesc( &dscC);
	pSrf->Release();

	if(FAILED(pDev->GetDepthStencilSurface(&pSrf)))
		return -1;

	pSrf->GetDesc(&dscD);
	pSrf->Release();


	// Create Rendering Environment Mapping Object
	hr = D3DXCreateRenderToEnvMap( pDev, ENVMAP_RESOLUTION
								, 1, dscC.Format
								, TRUE, dscD.Format
								, &m_pRndEnv );

	if( FAILED( hr ) )
		return -1;
	
	// Create Spheremap
	hr = D3DXCreateTexture( pDev
							, ENVMAP_RESOLUTION, ENVMAP_RESOLUTION
							, 1, D3DUSAGE_RENDERTARGET
							, dscC.Format
							, D3DPOOL_DEFAULT, &m_pTxSph);
	if( FAILED( hr ) )
		hr = D3DXCreateTexture(pDev
								, ENVMAP_RESOLUTION, ENVMAP_RESOLUTION
								, 1, 0
								, dscC.Format
								, D3DPOOL_DEFAULT, &m_pTxSph );



	if( FAILED( hr ) )
		return -1;


	m_pShader->SetTexture(m_pTxSph);

	m_pD3DXFont->OnResetDevice();
	m_pShader->Restore();
		
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	SAFE_RELEASE(	m_pRndEnv	);
	SAFE_RELEASE(	m_pTxSph	);

	m_pD3DXFont->OnLostDevice();
	m_pShader->Invalidate();

	return S_OK;
}


void T_SetupCubeViewMatrix(D3DXMATRIX* pmtViw, DWORD dwFace )
{
    D3DXVECTOR3 vcEye   = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vcLook;
    D3DXVECTOR3 vcUp;

    switch( dwFace )
    {
        case D3DCUBEMAP_FACE_POSITIVE_X:
            vcLook = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_X:
            vcLook = D3DXVECTOR3(-1.0f, 0.0f, 0.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Y:
            vcLook = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Y:
            vcLook = D3DXVECTOR3( 0.0f,-1.0f, 0.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Z:
            vcLook = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Z:
            vcLook = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            vcUp   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
    }

    // Set the view transform for this cubemap surface
    D3DXMatrixLookAtLH(pmtViw, &vcEye, &vcLook, &vcUp );
}


HRESULT CMain::FrameMove()
{
	INT	i;


	SAFE_FRMOV(	m_pInput	);

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* .1f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 0.3F, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-0.3F, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSide(-0.3F);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSide(0.3F);
	

	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);
	}

	m_pCam->FrameMove();

	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pShader	);

	sprintf( m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);



	D3DXMATRIX mtViwCur;	// Current View Matrix
	D3DXMATRIX mtPrjCur;	// Current Projection Matrix

	m_pd3dDevice->GetTransform(D3DTS_VIEW, &mtViwCur);
	m_pd3dDevice->GetTransform(D3DTS_PROJECTION, &mtPrjCur);



	D3DXMATRIX mtViw[6];	// the view matries for the cubemap surface
	D3DXMATRIX mtPrj;


	// Set the projection matrix for a field of view of 90 degrees
	D3DXMatrixPerspectiveFovLH( &mtPrj, D3DX_PI/2.F, 1.0F, 1.0F, 5000.0f );	


	// Set the view transform for this cubemap surface
	for(i=0; i<6; ++i)
	{
		T_SetupCubeViewMatrix(&mtViw[i], (D3DCUBEMAP_FACES) i );
		mtViw[i] = mtViwCur * mtViw[i];
	}


	// Rendering to Sphere surface
	m_pRndEnv->BeginSphere(m_pTxSph);
	{
		for(i=0; i<6; ++i)
		{
			m_pRndEnv->Face( (D3DCUBEMAP_FACES) i, 0 );
			RenderScene( &mtViw[i], &mtPrj);
		}
	}
	m_pRndEnv->End(0);




	m_pd3dDevice->SetTransform(D3DTS_VIEW, &mtViwCur);
	m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &mtPrjCur);


	return S_OK;
}


HRESULT CMain::Render()
{
	HRESULT hr=0;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, D3DXCOLOR(0.9F, 1.0F, 1.0F, 1.0F)
						, 1.0f
						, 0L
						);

	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();
	
	//�׸��带 �׸���.
	if(m_pInput->KeyState(VK_F12))
		SAFE_RENDER(	m_pGrid		);




	RenderScene();



	// shader ����
	SAFE_RENDER(	m_pShader	);

	m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);


	D3DXMATRIX	mtScl;
	D3DXMatrixScaling(&mtScl, 0.4f, 0.4f, 1.f);

	RECT rc={0,0, ENVMAP_RESOLUTION, ENVMAP_RESOLUTION};
	m_pd3dSprite->SetTransform(&mtScl);
	m_pd3dSprite->Draw(m_pTxSph, &rc, NULL, NULL, 0xFFFFFFFF);
	m_pd3dSprite->End();
	
//	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}


HRESULT CMain::RenderScene()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	D3DXMATRIX mtWld;
	D3DXMatrixScaling( &mtWld, 100.0f, 100.0f, 100.0f );

	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtWld);
	m_pSkyBox->Render(TRUE);


	D3DXMatrixIdentity(&mtWld);
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtWld);


	return S_OK;
}

HRESULT CMain::RenderScene(D3DXMATRIX *pView, D3DXMATRIX *pProj)
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0L);
	m_pd3dDevice->SetTransform( D3DTS_VIEW, pView );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, pProj );

	RenderScene();

	return S_OK;
}




void CMain::RenderText()
{
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	
	RECT	rc;
	SetRect(&rc, 5, 5, m_d3dsdBackBuffer.Width - 20, 30);
	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC m_hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, m_hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}