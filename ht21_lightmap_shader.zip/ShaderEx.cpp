// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;
	m_pFVF		= NULL;
	
	m_pTxDif	= NULL;
	m_pTxLgt	= NULL;	
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/stones.bmp", &m_pTxDif);
	D3DXCreateTextureFromFile( m_pDev, "data/lighting.tga", &m_pTxLgt);
	
	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);
	
	SAFE_RELEASE(	m_pTxLgt	);
	SAFE_RELEASE(	m_pTxDif	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	INT i=0;

	MATA	mtWld;
	MATA	mtViw;
	MATA	mtPrj;
	MATA	mtWVP;

	D3DXMatrixIdentity(&mtWld);
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	mtWVP = mtWld * mtViw * mtPrj;


	m_pDev->SetFVF(VtxUV1::FVF);

	m_pEft->SetMatrix("m_mtWVP", &mtWVP);
	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);



	VtxUV1	pVtx[4];
	pVtx[0] =	VtxUV1(-40.f,  40.f, 0.f, 0.f, 0.f);
	pVtx[1] =	VtxUV1( 40.f,  40.f, 0.f, 1.f, 0.f);
	pVtx[2] =	VtxUV1( 40.f, -40.f, 0.f, 1.f, 1.f);
	pVtx[3] =	VtxUV1(-40.f, -40.f, 0.f, 0.f, 1.f);



	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map
	m_pEft->SetTexture( "m_TxLgt", m_pTxLgt);			// ������ ��


	// ���� �簢��1
	m_pEft->BeginPass(0);
	{
		VtxUV1	pVtxR[4];
		memcpy(pVtxR, pVtx, 4 * sizeof(VtxUV1));

		for(i=0; i<4; ++i)
			pVtxR[i].p += VEC3(-55, 41, 0);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtxR, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// ���� �簢��2
	m_pEft->BeginPass(1);
	{
		VtxUV1	pVtxR[4];
		memcpy(pVtxR, pVtx, 4 * sizeof(VtxUV1));

		for(i=0; i<4; ++i)
			pVtxR[i].p += VEC3(-55, -41, 0);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtxR, sizeof(VtxUV1));
	}
	m_pEft->EndPass();

	
	// ������ �簢��1
	m_pEft->BeginPass(2);
	{
		VtxUV1	pVtxR[4];
		memcpy(pVtxR, pVtx, 4 * sizeof(VtxUV1));

		for(i=0; i<4; ++i)
			pVtxR[i].p += VEC3(55, +41, 0);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtxR, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// ������ �簢��1
	m_pEft->BeginPass(3);
	{
		VtxUV1	pVtxR[4];
		memcpy(pVtxR, pVtx, 4 * sizeof(VtxUV1));

		for(i=0; i<4; ++i)
			pVtxR[i].p += VEC3(55, -41, 0);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtxR, sizeof(VtxUV1));
	}
	m_pEft->EndPass();

	m_pEft->End();
}


