// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxNUV1
	{
		VEC3	p;
		VEC3	n;
		FLOAT	u, v;
		VEC3	t;			// Tangent
		VEC3	b;			// Binormal

		VtxNUV1() : p(0,0,0),u(0),v(0), t(0,0,0), b(0,0,0){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX3|D3DFVF_TEXCOORDSIZE3(1)|D3DFVF_TEXCOORDSIZE3(2) )	};
	};


public:
	PDEV		m_pDev;			// Device

	PDEF		m_pEft;			// Vertex Shader
	PDVD		m_pFVF;			// Declarator

	PDTX		m_pTxN;			// Normal Map

	INT			m_iNvx;			// Vertex Number
	VtxNUV1*	m_pVtx;			// Vertex Buffer

	VEC3		m_vcLgt;		// Lighting Direction

public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

