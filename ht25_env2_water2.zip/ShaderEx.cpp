// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pFVF		= NULL;
	m_pEft		= NULL;

	m_TileN		= 0;
	m_TileW		= 0;
	m_nVtx		= 0;
	m_nFce		= 0;

	m_pFce		= NULL;
	m_pVtx		= NULL;

}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr;


	m_pDev = pDev;

	
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
			sprintf(sErr, "Cannot Compile Shader.");


		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = Vtx::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	int x;
	int z;
	int n;
	INT	nVtxT;		// �࿡ ���� ���ؽ� ��

	VEC3	vcEps;


	m_TileN = 64;
	m_TileW = 4.f;

	vcEps = -VEC3(m_TileN * m_TileW/2, 30, m_TileN * m_TileW/2);

	nVtxT	= m_TileN+1;
	m_nVtx	= nVtxT * nVtxT;
	m_nFce	= 2* m_TileN * m_TileN;


	m_pVtx = new Vtx   [m_nVtx];
	m_pFce = new VtxIdx[m_nFce];


	// 1. ������ �ε��� ����

	//	1-----3
	//	.\    |
	//	.  \  |
	//	.    \|
	//	0-----2

	n=0;

	for(z=0; z<m_TileN; ++z)
	{
		for(x=0;x<m_TileN; ++x)
		{
			int _0 = nVtxT*(z+0) +x;
			int _1 = nVtxT*(z+1) +x;
			int _2 = nVtxT*(z+0) +x +1;
			int _3 = nVtxT*(z+1) +x +1;


			m_pFce[n] = VtxIdx(_0, _1, _2);
			++n;
			m_pFce[n] = VtxIdx(_3, _2, _1);
			++n;
		}
	}


	for(z=0; z<=m_TileN; ++z)
	{
		for(x=0;x<=m_TileN; ++x)
		{
			n = z * nVtxT + x;

			m_pVtx[n].p = VEC3( FLOAT(x), 0.F, FLOAT(z));
			m_pVtx[n].p *= m_TileW;
			m_pVtx[n].p +=vcEps;
		}
	}

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF		);
	SAFE_RELEASE(	m_pEft		);

	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::Restore()
{

	m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}



INT CShaderEx::FrameMove()
{
	return 0;
}

void CShaderEx::Render()
{
	INT		hr=0;

	MATA	mtWld;
	MATA	mtViw;
	MATA	mtPrj;
	FLOAT	fTime;

	D3DXMatrixIdentity(&mtWld);


	fTime = g_pApp->GetTime();

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetVertexDeclaration(m_pFVF);

	hr = m_pEft->SetMatrix( "m_mtWld", &mtWld);
	hr = m_pEft->SetMatrix( "m_mtViw", &mtViw);
	hr = m_pEft->SetMatrix( "m_mtPrj", &mtPrj);
	hr = m_pEft->SetFloat ( "m_fTime", fTime);
	
	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0
										, m_nVtx, m_nFce
										, m_pFce, (D3DFORMAT)VtxIdx::FVF
										, m_pVtx, sizeof(Vtx) );

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
}


