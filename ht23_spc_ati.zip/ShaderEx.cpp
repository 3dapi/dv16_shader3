// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;

	m_pTexD	= NULL;
	m_pTexL	= NULL;
	m_pTexS	= NULL;

	m_pVtx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	m_pDev	= pDev;


	// Create Vertex
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new VtxNUV1[m_iNvx];
	VtxNUV1* pVtx = m_pVtx;

	// Generate the group of rings for the sphere
	for( DWORD ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for( DWORD seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pVtx->p.x = x0;
			pVtx->p.y = y0;
			pVtx->p.z = z0;
			pVtx->n.x = x0;
			pVtx->n.y = y0;
			pVtx->n.z = z0;
			
			D3DXVec3Normalize(&pVtx->n, &pVtx->n);
			
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+0)/(FLOAT)iNSphereSegments;
			pVtx++;

			pVtx->p.x = x1;
			pVtx->p.y = y1;
			pVtx->p.z = z1;
			pVtx->n.x = x1;
			pVtx->n.y = y1;
			pVtx->n.z = z1;
			
			D3DXVec3Normalize(&pVtx->n, &pVtx->n);
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+1)/(FLOAT)iNSphereSegments;
			pVtx++;
		}
	}


	D3DXCreateTextureFromFile(m_pDev, "data/earth_d.bmp", &m_pTexD);
	D3DXCreateTextureFromFile(m_pDev, "data/earth_l.bmp", &m_pTexL);
	D3DXCreateTextureFromFile(m_pDev, "data/earth_s.bmp", &m_pTexS);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);


	SAFE_RELEASE(	m_pTexD		);
	SAFE_RELEASE(	m_pTexL		);
	SAFE_RELEASE(	m_pTexS		);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=50.f * g_pApp->m_fTime;

//	c=30;
	if(c>360.f)
		c -=360.f;

	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	MATA matTexScale;
	D3DXMatrixIdentity(&matTexScale);

	matTexScale._11 = 0.5f;
	matTexScale._22 = -0.5f;
	matTexScale._33 = 0.0f; 
	matTexScale._41 = 0.5f; 
	matTexScale._42 = 0.5f;
	matTexScale._43 = 1.0f; 
	matTexScale._44 = 1.0f;


	m_pDev->SetFVF(VtxNUV1::FVF);

	m_pEft->SetTexture( "m_pTexL", m_pTexL);			// Lighting Map
	m_pEft->SetTexture( "m_pTexD", m_pTexD);			// Diffuse Map
	m_pEft->SetTexture( "m_pTexS", m_pTexS);			// Specular Map

	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACENORMAL );
		m_pDev->SetTextureStageState( 2, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR );
	
		m_pDev->SetTransform( D3DTS_TEXTURE0, &matTexScale );
		m_pDev->SetTransform( D3DTS_TEXTURE1, &matTexScale );
		m_pDev->SetTransform( D3DTS_TEXTURE2, &matTexScale );
		
		m_pDev->SetTransform( D3DTS_WORLD, &m_mtWld );

		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP
										, m_iNvx - 2
										, m_pVtx
										, sizeof(VtxNUV1)
										);
	
	m_pEft->EndPass();
	m_pEft->End();


	D3DXMATRIX mtI;
	D3DXMatrixIdentity( &mtI);
	
	m_pDev->SetTransform( D3DTS_WORLD, &mtI );
	m_pDev->SetTransform( D3DTS_TEXTURE0, &mtI );
	m_pDev->SetTransform( D3DTS_TEXTURE1, &mtI );
	m_pDev->SetTransform( D3DTS_TEXTURE2, &mtI );


	m_pDev->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0);
	m_pDev->SetTextureStageState( 2, D3DTSS_TEXCOORDINDEX, 2 );
}



