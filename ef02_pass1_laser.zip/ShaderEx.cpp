// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;

	m_pMsh1	= NULL;
	m_pMsh2	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = CShaderEx::VtxN::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;




	if(FAILED(D3DXCreateCylinder(m_pDev, 6, 6, 1000, 30, 5, &m_pMsh1, NULL)))
		return -1;

	if(FAILED(D3DXCreateCylinder(m_pDev, 10, 8, 1000, 30, 10, &m_pMsh2, NULL)))
		return -1;


//	DWORD dFVF = m_pMsh1->GetFVF();
//	DWORD nVtx = m_pMsh1->GetNumVertices();
//
//	VtxN* pVtx = NULL;
//	m_pMsh->LockVertexBuffer(0, (void**)&pVtx);
//	
//
//	for( DWORD n = 0; n < nVtx; ++n)
//	{
//		pVtx[n].p *=1.f;
//	}
//
//	m_pMsh->UnlockVertexBuffer();


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);

	SAFE_RELEASE(	m_pMsh1	);
	SAFE_RELEASE(	m_pMsh2	);
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	static float c=0;

//	c=100.f * g_pApp->m_fTime;
//
//	if(c>360.f)
//		c -=360.f;

	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	HRESULT	hr=-1;
	
	MATA	mtViw;							// View Matrix
	MATA	mtViwI;							// Inverse View Matrix
	MATA	mtPrj;							// Projection Matrix
	VEC3	CamZ;							// Camera Z Axis
	VEC3	AxsZ = VEC3(0,0,1);				// Glow Direction(0,0,1)

	VEC4	vcLight(1, 0.0F, 0.0F, 0.0F);	// ��������
	DCOL	xcGlow (1, 1.0F, 0.2F, 1.0F);	// Glow ����
	FLOAT	fThick=40.F;					// Glow �β�
	DCOL	xColor;							// Glow Color
	FLOAT	Bright;							// Bright


	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);
	D3DXMatrixInverse(&mtViwI, NULL, &mtViw);


	// �ü��� ���� Normal Vector: Nor = dot(AxsZ, CamZ) * AxsZ - CamZ. Nor �� (0,0,1)
	CamZ = VEC3(mtViwI._41, mtViwI._42, mtViwI._43);	// Camera Z Axis
	FLOAT a = D3DXVec3Dot(&AxsZ, &CamZ);				// a = dot(AxsZ, CamZ)
	VEC4 Nor = a * AxsZ - CamZ;							// Nor = a * AxsZ - CamZ
	Nor.w = 0;
	D3DXVec4Normalize(&Nor, &Nor);



	m_pDev->SetVertexDeclaration( m_pFVF);			// ��������

	// ��� ����
	hr = m_pEft->SetMatrix("m_mtWld", &m_mtWld);
	hr = m_pEft->SetMatrix("m_mtViw", &mtViw);
	hr = m_pEft->SetMatrix("m_mtPrj", &mtPrj);
	hr = m_pEft->SetVector("g_vcNor", &Nor);

	hr = m_pEft->SetTechnique("Tech");

	Bright = (94 + rand()%7)*0.01;
	xColor	= DCOL(0, 0, 1, 1);
	xColor  *= Bright;

	hr = m_pEft->Begin(NULL, 0);

	hr = m_pEft->BeginPass(0);
		hr = m_pEft->SetVector("g_xcCol", (VEC4*)&xColor);
		hr = m_pMsh2->DrawSubset(0);
	m_pEft->EndPass();

	Bright = (94 + rand()%7)*0.01;
	xColor	= DCOL(.2f, 1, 0, 0.1f);
	xColor *=Bright;
		
	hr = m_pEft->BeginPass(1);
		hr = m_pEft->SetVector("g_xcCol", (VEC4*)&xColor);
		hr = m_pMsh1->DrawSubset(0);
	m_pEft->EndPass();

	m_pEft->End();


	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}

