// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;
typedef D3DXCOLOR						DCOL;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxN
	{
		VEC3	p;
		VEC3	n;

		VtxN()		: p(0,0,0),n(0,0,0){}
		VtxN(	FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT NX, FLOAT NY, FLOAT NZ)	: p(X,Y,Z),n(NX,NY,NZ){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL)	};

	};

public:
	PDEV		m_pDev;				// Device
	PDEF		m_pEft;				// ID3DXEffect Instance
	PDVD		m_pFVF;				// Vertex Declarator

	MATA		m_mtWld;			// World Matrix

	LPD3DXMESH	m_pMsh1;
	LPD3DXMESH	m_pMsh2;


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

