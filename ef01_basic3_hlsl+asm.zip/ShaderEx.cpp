// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;

	m_pTx0	= NULL;
	m_pTx1	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxDUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	m_pVtx[0] = VtxDUV1(-60, 100,  0,	0.f, 0.f, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxDUV1( 60, 100,  0,	1.f, 0.f, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxDUV1( 60,  0,  0,	1.f, 1.f, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxDUV1(-60,  0,  0,	0.f, 1.f, D3DXCOLOR(1,0,1,1));

	D3DXCreateTextureFromFile(m_pDev, "texture/dx5_logo.bmp", &m_pTx0);
	D3DXCreateTextureFromFile(m_pDev, "texture/earth.bmp", &m_pTx1);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pTx0	);
	SAFE_RELEASE(	m_pTx1	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	HRESULT	hr=-1;

	D3DXMATRIX		mtWld;			// World Matrix
	D3DXMATRIX		mtViw;			// View Matrix
	D3DXMATRIX		mtPrj;			// Projection Matrix


	FLOAT fAngle = D3DXToRadian(GetTickCount()*0.1f);
//	fAngle = 0;
	D3DXMatrixRotationY(&mtWld, fAngle);
	mtWld._43 -=1.f;


	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);



	// Setup Constant
	hr = m_pEft->SetMatrix("m_mtWld", &mtWld);
	hr = m_pEft->SetMatrix("m_mtViw", &mtViw);
	hr = m_pEft->SetMatrix("m_mtPrj", &mtPrj);

	hr = m_pEft->SetTexture("m_Tex0", m_pTx0);
	hr = m_pEft->SetTexture("m_Tex1", m_pTx1);


	// Rendering
	hr = m_pDev->SetVertexDeclaration(m_pFVF);
	hr = m_pEft->SetTechnique("Tech0"); 

	UINT nPass=0;	
	hr = m_pEft->Begin( &nPass, 0);

	for(UINT n = 0; n < nPass; ++n)
	{
		hr = m_pEft->BeginPass(n);
			hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
		m_pEft->EndPass();
	}

	m_pEft->End();


	// ����, �ȼ� Shader ����
	hr = m_pDev->SetVertexDeclaration(NULL);
	hr = m_pDev->SetVertexShader(NULL);
	hr = m_pDev->SetPixelShader(NULL);
}


INT CShaderEx::Restore()
{
	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}