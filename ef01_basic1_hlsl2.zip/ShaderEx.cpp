// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;

	m_pMsh	= NULL;
	m_pTx0	= NULL;
	m_pTx1	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}




	D3DXCreateTextureFromFile(m_pDev, "data/earth.bmp", &m_pTx0);
	D3DXCreateTextureFromFile(m_pDev, "data/wood.jpg",  &m_pTx1);

	// Read Teapot Mesh
	m_pMsh = new CMcMesh;

	hr = m_pMsh->Create(m_pDev, "data/teapot.x");
	
	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_DELETE(	m_pMsh	);
	SAFE_RELEASE(	m_pTx0	);
	SAFE_RELEASE(	m_pTx1	);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=50.f * g_pApp->m_fTime;
//	c=90;
	if(c>360.f)
		c -=360.f;

	MATA	mtS;
	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixScaling(&mtS, 40, 40, 40);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;
	m_mtWld = mtS * m_mtRot;

	m_mtWld._41 = 10;
	m_mtWld._42 = 30;
	
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	static INT nPassIndex = 0;

	if(::GetAsyncKeyState('1') &0x8000)
		nPassIndex = 0;

	if(::GetAsyncKeyState('2') &0x8000)
		nPassIndex = 1;

	if(::GetAsyncKeyState('3') &0x8000)
		nPassIndex = 2;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWld);
	m_pDev->SetTexture(1, m_pTx1);

	m_pEft->SetTexture("m_TxDif0", m_pTx0);
	m_pEft->SetTexture("m_TxDif1", m_pTx1);

	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(nPassIndex);
	
		m_pMsh->Render();

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);

	MATA	mtI;
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
}


