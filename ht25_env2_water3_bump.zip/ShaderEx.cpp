// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;

	m_pTxHgt	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr;


	m_pDev = pDev;


	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	DWORD dwFlags = 0;
#if defined( _DEBUG ) || defined( DEBUG )
	dwFlags |= D3DXSHADER_DEBUG;
#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
			sprintf(sErr, "Cannot Compile Shader.");


		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	hr = D3DXCreateTextureFromFile(m_pDev, "data/Height.bmp", &m_pTxHgt);
	if (FAILED(hr))
		return hr;


	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);

	SAFE_RELEASE(	m_pTxHgt	);
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}



INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		struct _TvtxRHWUV1
		{
			FLOAT	x,y,z,w;
			float	u,v;
		}vtx[4]	=
		{
			  0,   0,	0,	1,		0,	0,
			512,   0,	0,	1,		1,	0,
			512, 512,	0,	1,		1,	1,
			  0, 512,	0,	1,		0,	1,
		};

		m_pEft->SetTexture("m_TxHgt", m_pTxHgt);
		m_pDev->SetFVF( D3DFVF_XYZRHW|D3DFVF_TEX1);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, vtx, sizeof(_TvtxRHWUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexShader( NULL );
	m_pDev->SetPixelShader( NULL );

	m_pDev->SetTexture(0, NULL);
}


