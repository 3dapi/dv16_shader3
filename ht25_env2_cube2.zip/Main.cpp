

#include "_StdAfx.h"


CMain::CMain()
:	m_pD3DXFont	(0)
,	m_pInput	(0)
,	m_pCam		(0)
,	m_pGrid		(0)
,	m_pShader	(0)
{
	m_pRndEnv	= NULL;
	m_pTexCbm	= NULL;
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(m_pInput , CMcInput		, m_hWnd);
	SAFE_NEWCREATE1(m_pCam	 , CMcCam		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pGrid	 , CMcGrid		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pShader, CShaderEx	, m_pd3dDevice);

	
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, NONANTIALIASED_QUALITY
		, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pShader		);

	return S_OK;
}



HRESULT CMain::Restore()
{
	HRESULT	hr = 0;
	PDEV	pDev = m_pd3dDevice;

	const	int	ENVMAP_RESOLUTION	= 256;

	LPDIRECT3DSURFACE9	pSrf;
	D3DSURFACE_DESC		dscC;
	D3DSURFACE_DESC		dscD;

	if(FAILED(pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pSrf)))
			return-1;

	pSrf->GetDesc( &dscC);
	pSrf->Release();

	if(FAILED(pDev->GetDepthStencilSurface(&pSrf)))
		return -1;

	pSrf->GetDesc(&dscD);
	pSrf->Release();


	// Create Rendering Environment Mapping Object
	hr = D3DXCreateRenderToEnvMap( pDev, ENVMAP_RESOLUTION
								, 1, dscC.Format
								, TRUE, dscD.Format
								, &m_pRndEnv );

	if( FAILED( hr ) )
		return -1;
	
	// Create Cube Map
	hr = D3DXCreateCubeTexture( pDev
							, ENVMAP_RESOLUTION
							, 1, D3DUSAGE_RENDERTARGET
							, dscC.Format
							, D3DPOOL_DEFAULT, &m_pTexCbm);
	if( FAILED( hr ) )
		hr = D3DXCreateCubeTexture(pDev
								, ENVMAP_RESOLUTION
								, 1, 0
								, dscC.Format
								, D3DPOOL_DEFAULT, &m_pTexCbm );



	if( FAILED( hr ) )
		return -1;


	m_pShader->SetTexture(m_pTexCbm);

	m_pD3DXFont->OnResetDevice();
	m_pShader->Restore();
		
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	SAFE_RELEASE(	m_pRndEnv	);
	SAFE_RELEASE(	m_pTexCbm	);

	m_pD3DXFont->OnLostDevice();
	m_pShader->Invalidate();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* .1f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 0.3F, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-0.3F, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSide(-0.3F);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSide(0.3F);
	

	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);
	}

	m_pCam->FrameMove();



	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pShader	);

	sprintf( m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);

	return S_OK;
}


HRESULT CMain::Render()
{
	HRESULT hr=0;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, D3DXCOLOR(0.9F, 1.0F, 1.0F, 1.0F)
						, 1.0f
						, 0L
						);

	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();
	
	//�׸��带 �׸���.
	if(m_pInput->KeyState(VK_F12))
		SAFE_RENDER(	m_pGrid		);

	// shader ����
	SAFE_RENDER(	m_pShader	);
	
	
//	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}


void CMain::RenderText()
{
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	
	RECT	rc;
	SetRect(&rc, 5, 5, m_d3dsdBackBuffer.Width - 20, 30);
	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC m_hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, m_hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}