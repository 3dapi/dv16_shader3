// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pFVF		= NULL;
	m_pEft		= NULL;

	m_pTxCbm	= NULL;

	m_pTeapot	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr;


	m_pDev = pDev;

	
	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
			sprintf(sErr, "Cannot Compile Shader.");


		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxN::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;




	m_pTeapot = new CMcMesh;

	// Load the file objects
	if( FAILED( m_pTeapot->Create( m_pDev, "data/teapot.x" )))
		return -1;


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF		);
	SAFE_RELEASE(	m_pEft		);
	
	SAFE_DELETE(	m_pTeapot	);
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}



INT CShaderEx::FrameMove()
{
	float c= GetTickCount()*0.05f;

	c = 90;
	MATA	mtS;
	MATA	mtY;
	MATA	mtZ;

	D3DXMatrixScaling(&mtS, 50, 50, 50);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;

	m_mtWld	= mtS * m_mtRot;
	m_mtWld._41 = 0;
	m_mtWld._42 = 0;
	m_mtWld._43 = 0;

	return 0;
}

void CShaderEx::Render()
{
	INT		hr=0;
	MATA	mtWld = m_mtWld;
	MATA	mtViw;
	MATA	mtPrj;

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	hr = m_pEft->SetMatrix( "m_mtWld", &mtWld);
	hr = m_pEft->SetMatrix( "m_mtViw", &mtViw);
	hr = m_pEft->SetMatrix( "m_mtPrj", &mtPrj);
	hr = m_pEft->SetTexture( "m_TxCbm", m_pTxCbm );


	m_pDev->SetVertexDeclaration(m_pFVF);

	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pTeapot->Render();

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
}


void CShaderEx::SetTexture(PDTC pTex)
{
	m_pTxCbm = pTex;
}