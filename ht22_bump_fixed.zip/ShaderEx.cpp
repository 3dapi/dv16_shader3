// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


inline DWORD VectorToRGB(D3DXVECTOR3* vcNor)
{
	FLOAT	r = vcNor->x;
	FLOAT	g = vcNor->y;
	FLOAT	b = vcNor->z;

	DWORD dwR = (DWORD)(127 * r + 128);
	DWORD dwG = (DWORD)(127 * g + 128);
	DWORD dwB = (DWORD)(127 * b + 128);

	return (DWORD)(0xff000000 + (dwR << 16) + (dwG << 8) + dwB);
}


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;
	
	m_pTxDif	= NULL;
	m_pTxNor	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}



	D3DXCreateTextureFromFile( m_pDev, "data/rock_d.tga", &m_pTxDif);
	D3DXCreateTextureFromFile( m_pDev, "data/rock_n.tga", &m_pTxNor);
	
	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);

	SAFE_RELEASE(	m_pTxNor	);
	SAFE_RELEASE(	m_pTxDif	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	m_pDev->SetFVF(VtxUV1::FVF);

	VEC3	vcLgt(-1.0f,0.0f,1.0f);
	m_dTFactor = VectorToRGB(&vcLgt);

	D3DXCOLOR dFactor = m_dTFactor;


	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ���� ��
	m_pEft->SetVector(  "m_dTFactor", (D3DXVECTOR4*)&dFactor);
	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);


	// �»��
	m_pEft->BeginPass(0);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f -90.f, -40.f+45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f -90.f,  40.f+45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f -90.f,  40.f+45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f -90.f, -40.f+45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// �߾� ���
	m_pEft->BeginPass(1);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f, -40.f+45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f,  40.f+45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f,  40.f+45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f, -40.f+45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// ����
	m_pEft->BeginPass(2);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f +90.F, -40.f+45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f +90.F,  40.f+45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f +90.F,  40.f+45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f +90.F, -40.f+45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// ���� �ϴ�.
	m_pEft->BeginPass(3);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f -90.f, -40.f-45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f -90.f,  40.f-45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f -90.f,  40.f-45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f -90.f, -40.f-45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// �߾� �ϴ�
	// �븻 ���� ���� ó���ϸ� �������� ���� �� �ִ�.
	m_pEft->BeginPass(4);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f, -40.f-45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f,  40.f-45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f,  40.f-45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f, -40.f-45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	// ���ϴ�
	m_pEft->BeginPass(5);
	{
		VtxUV1	pVtx1[4];
		pVtx1[0] =	VtxUV1(-40.f +90.F, -40.f-45.f, 0.f, 0.f, 1.f);
		pVtx1[1] =	VtxUV1(-40.f +90.F,  40.f-45.f, 0.f, 0.f, 0.f);
		pVtx1[2] =	VtxUV1( 40.f +90.F,  40.f-45.f, 0.f, 1.f, 0.f);
		pVtx1[3] =	VtxUV1( 40.f +90.F, -40.f-45.f, 0.f, 1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxUV1));
	}
	m_pEft->EndPass();


	m_pEft->End();
}



