

#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont	= NULL;
	m_pSprite	= NULL;
	m_Tex.pTex	= NULL;
}


HRESULT CMain::Init()
{
	INT hr=-1;

	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, NONANTIALIASED_QUALITY
		, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;


	if(FAILED(LcDev_CreateSprite(NULL, &m_pSprite, m_pd3dDevice)))
		return -1;



	D3DXIMAGE_INFO	Img;
	D3DSURFACE_DESC	dsc;
	PDTX 	pTex = NULL;

	
	hr = D3DXCreateTextureFromFileEx(	m_pd3dDevice
									, "Texture/mario.png"
									, D3DX_DEFAULT
									, D3DX_DEFAULT
									, 1
									, 0
									, D3DFMT_UNKNOWN
									, D3DPOOL_MANAGED
									, D3DX_FILTER_NONE
									, D3DX_FILTER_NONE
									, 0x00FFFFFF
									, &Img
									, NULL
									, &pTex);

	pTex->GetLevelDesc(0, &dsc);

	m_Tex.ImgW	= Img.Width;
	m_Tex.ImgH	= Img.Height;
	m_Tex.ImgD	= Img.Depth;
	m_Tex.TexW	= dsc.Width;
	m_Tex.TexH	= dsc.Height;
	m_Tex.pTex = pTex;

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);

	SAFE_RELEASE(	m_Tex.pTex	);

	SAFE_DELETE(	m_pSprite	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnResetDevice();	


	m_pSprite->OnResetDevice();
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnLostDevice();


	m_pSprite->OnLostDevice();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	sprintf( m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);

	return S_OK;
}


HRESULT CMain::Render()
{
	HRESULT hr=0;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, D3DXCOLOR(0.9F, 1.0F, 1.0F, 1.0F)
						, 1.0f
						, 0L
						);



	{
		RECT	rc1={60, 0, 80, 32};
		D3DXVECTOR2	vTrn1(160.f, 120.f);
		D3DXVECTOR2	vTrn2(160.f, 180.f+ 8.f*32.f);
		D3DXVECTOR2	vScl1(10.0f, 10.0f);
		D3DXVECTOR2	vScl2(9.0f, -3.0f);
		D3DXVECTOR2	vRot(200.f, 200.f+ 8.f*32.f);

		float t=0;

		// �׸���.
		m_pSprite->DrawEx(&m_Tex, &rc1, &vScl2, NULL, 0, &vTrn2, 0x88333333, TRUE);

		// ĳ����
		m_pSprite->DrawEx(&m_Tex, &rc1, &vScl1, &vRot, D3DXToRadian(t), &vTrn1, 0xFFFFFFFF, FALSE);
	}


	{
		RECT	rc1={80, 0, 100, 32};
		D3DXVECTOR2	vTrn1(420.f, 120.f);
		D3DXVECTOR2	vTrn2(420.f, 180.f+ 8.f*32.f);
		D3DXVECTOR2	vScl1(-10.0f, 10.0f);
		D3DXVECTOR2	vScl2(-9.0f, -3.0f);
		D3DXVECTOR2	vRot(200.f, 200.f+ 8.f*32.f);

		// �׸���.
		m_pSprite->DrawEx(&m_Tex, &rc1, &vScl2, NULL, 0, &vTrn2, 0x88333333, TRUE);

		// ĳ����
		m_pSprite->DrawEx(&m_Tex, &rc1, &vScl1, &vRot, 0, &vTrn1, 0xFFFFFFFF, FALSE);
	}

	
	
	// RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}


void CMain::RenderText()
{
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	
	RECT	rc;
	SetRect(&rc, 5, 5, m_d3dsdBackBuffer.Width - 20, 30);
	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC m_hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, m_hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}