// Interface for the CLcSprite class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LcSprite_H_
#define _LcSprite_H_


#ifndef interface
	#define interface struct
#endif

#ifndef LC_CLASS_DESTROYER
	#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif




typedef D3DXVECTOR2							VEC2;
typedef LPDIRECT3DTEXTURE9					PDTX;


struct LcTexture
{
	INT		ImgW;		// Original Image Width
	INT		ImgH;		// Original Image Height
	INT		ImgD;		// Original Image Depth

	INT		TexW;		// Texture Width
	INT		TexH;		// Texture Height
	PDTX	pTex;

	LcTexture()
	{
		ImgW	= 0;
		ImgH	= 0;
		ImgD	= 0;

		TexW	= 0;
		TexH	= 0;
		pTex	= NULL;
	}
};


interface ILcSprite
{
	LC_CLASS_DESTROYER(	ILcSprite	);

	virtual INT		DrawEx(void* pTex, RECT* pRc1, VEC2* pScl, VEC2* pRot, FLOAT fRot, VEC2* pTrl, DWORD dColor, INT bMono)=0;
	virtual INT		OnResetDevice()=0;
	virtual void	OnLostDevice()=0;
};


INT LcDev_CreateSprite(char* sCmd, ILcSprite** pData, void* pDev, void* p2=0, void* p3=0, void* p4=0);


#endif

