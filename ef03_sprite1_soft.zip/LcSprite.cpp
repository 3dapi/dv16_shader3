// Implementation of the CLcSprite class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "LcSprite.h"

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;
typedef D3DXCOLOR							DCOL;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DVERTEXSHADER9				PDVS;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	ID3DXEffect*						PDEF;



class CLcSprite : public ILcSprite
{
public:
	struct VtxRHWUV1
	{
		VEC2	p;
		FLOAT	z;
		FLOAT	w;
		VEC2	t;
		
		VtxRHWUV1()	: p(0,0), z(0), w(1), t(0,0){}
		VtxRHWUV1(FLOAT X,FLOAT Y,FLOAT Z
					,FLOAT U,FLOAT V
					):p(X,Y), z(Z), w(1), t(U,V){}

		enum {FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1),};
	};

public:
	PDEV			m_pDev;			// Device
	PDVD			m_pFVF;
	PDEF			m_pEft;			// ID3DXEffect
	VtxRHWUV1		m_pVtx[4];		// Vertex Buffer

	INT				m_nScnW;
	INT				m_nScnH;

	
public:
	CLcSprite();
	virtual ~CLcSprite();

	virtual INT		DrawEx(void* pTex, RECT* pRc1, VEC2* pScl, VEC2* pRot, FLOAT fRot, VEC2* pTrl, DWORD dColor, INT bMono);
	virtual INT		OnResetDevice();
	virtual void	OnLostDevice();

	INT		Create(void* pDev);
	void	Destroy();
};



CLcSprite::CLcSprite()
{
	m_pDev		= NULL;

	m_pFVF		= NULL;
	m_pEft		= NULL;

	m_nScnW		= 1024;
	m_nScnH		= 768;
}


CLcSprite::~CLcSprite()
{
	Destroy();
}


INT CLcSprite::Create(void* pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	char	sShader[]=
		"   int     m_bMono;                                   \n"
		"   float4  m_Diff;                                    \n"
		"                                                      \n"
		"   sampler smp0 : register(s0);                       \n"
		"   sampler smp1 : register(s1);                       \n"
		"                                                      \n"
		"   void VtxProc( in  float4 inPos0: POSITION          \n"
		"               , in  float2 inTex0: TEXCOORD0         \n"
		"               , out float4 otPos0: POSITION          \n"
		"               , out float2 otTex0: TEXCOORD0         \n"
		"               )                                      \n"
		"   {                                                  \n"
		"       otPos0 = inPos0;                               \n"
		"       otTex0 = inTex0;                               \n"
		"   }                                                  \n"
		"                                                      \n"
		"   float4 PxlProc(float4 Pos0: POSITION               \n"
		"               , float2 Tex0: TEXCOORD0) : COLOR0     \n"
		"   {                                                  \n"
		"       float4  Out= tex2D(smp0, Tex0);                \n"
		"                                                      \n"
		"       Out *= m_Diff;                                 \n"
		"                                                      \n"
		"       if(0 != m_bMono)                               \n"
		"       {                                              \n"
		"           Out.a *= m_Diff.a;                         \n"
		"           Out.r= m_Diff.r;                           \n"
		"           Out.g= m_Diff.g;                           \n"
		"           Out.b= m_Diff.b;                           \n"
		"       }                                              \n"
		"                                                      \n"
		"       return Out;                                    \n"
		"   }                                                  \n"
		"                                                      \n"
		"   technique Tech                                     \n"
		"   {                                                  \n"
		"       pass P0                                        \n"
		"       {                                              \n"
		"           VertexShader = compile vs_1_1 VtxProc();   \n"
		"           PixelShader  = compile ps_2_0 PxlProc();   \n"
		"       }                                              \n"
		"   }                                                  \n"
		;


	LPD3DXBUFFER	pError	= NULL;
	DWORD		dFlag=0;

	#if defined( _DEBUG ) || defined( DEBUG )
	dFlag |= D3DXSHADER_DEBUG;
	#endif

	// ������
	hr = D3DXCreateEffect(
								  m_pDev
								, sShader
								, strlen(sShader)-4
								, NULL
								, NULL
								, dFlag
								, NULL
								, &m_pEft
								, &pError);
	if(FAILED(hr))
	{
		MessageBox(GetActiveWindow()
					, (char*)pError->GetBufferPointer()
					, "Error", 0);
		return -1;
	}
	
	// ���� ���� ����
	D3DVERTEXELEMENT9 pVertexElement[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(CLcSprite::VtxRHWUV1::FVF, pVertexElement);
	m_pDev->CreateVertexDeclaration(pVertexElement, &m_pFVF);


	return 0;
}

void CLcSprite::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVF		);
}


INT CLcSprite::DrawEx(void* _pTex, RECT* pRc, VEC2* pScl, VEC2* pRot, FLOAT fRot, VEC2* pTrn, DWORD _dCol, INT _bMono)
{
	HRESULT hr=0;

	INT		bMono = 0;
	DCOL	dDiff = 0XFFFFFFFF;
	VEC2	vScl(1,1);
	VEC2	vRot(0,0);
	VEC2	vTrn(0,0);

	RECT	rc = {0, 0, 2048, 2048};

	VEC2	uv0(0,0);
	VEC2	uv1(1,1);
	FLOAT	rcW  = 0;
	FLOAT	rcH  = 0;
	
	FLOAT	PosL = 0;
	FLOAT	PosT = 0;
	FLOAT	PosR = 0;
	FLOAT	PosB = 0;


	LcTexture*	pTex = (LcTexture*)_pTex;			// Texture

	if(!pTex)
		return 0;


	// 1. �Է� �� ����
	dDiff = _dCol;
	bMono = _bMono;


	// 1.1 �̹��� �ҽ� 1 ���� ����
	if(pRc)
	{
		rc.left  = pRc->left  ;
		rc.right = pRc->right ;
		rc.top	 = pRc->top	  ;
		rc.bottom= pRc->bottom;
	}
	else
	{
		rc.right = pTex->ImgW;
		rc.bottom= pTex->ImgH;
	}


	// ���� �� ����
	if(rc.left<0)				rc.left  = 0;
	if(rc.right>pTex->ImgW)		rc.right = pTex->ImgW;
	if(rc.top<0)				rc.top   = 0;
	if(rc.bottom>pTex->ImgH)	rc.bottom= pTex->ImgH;


	// ������ �߸� ������ �����
	if(rc.top>=rc.bottom || rc.left>=rc.right)
		return 0;


	// uv ����
	uv0.x = FLOAT(rc.left-0.5f)/FLOAT(pTex->TexW);
	uv0.y = FLOAT(rc.top -0.5f)/FLOAT(pTex->TexH);
	uv1.x = FLOAT(rc.right    )/FLOAT(pTex->TexW);
	uv1.y = FLOAT(rc.bottom   )/FLOAT(pTex->TexH);


	// 2. Scaling, Rot, Position Setup
	if(pScl)	vScl = *pScl;
	if(pRot)	vRot = *pRot;
	if(pTrn)	vTrn = *pTrn;


	rcW	= FLOAT(rc.right - rc.left);
	rcH	= FLOAT(rc.bottom- rc.top );


	// Scaling ����
	if(vScl.x>=0.f)
	{
		PosL =  vTrn.x;
		PosR = PosL + rcW * vScl.x;
	}
	else
	{
		PosR =  vTrn.x;
		PosL = PosR - rcW * vScl.x;
	}


	if(vScl.y>=0.f)
	{
		PosT = vTrn.y;
		PosB = PosT + rcH * vScl.y;
	}
	else
	{
		PosB = vTrn.y;
		PosT = PosB - rcH * vScl.y;
	}


	// ���� ����
	m_pVtx[0].p = VEC2(PosL, PosT);
	m_pVtx[1].p = VEC2(PosR, PosT);
	m_pVtx[2].p = VEC2(PosR, PosB);
	m_pVtx[3].p = VEC2(PosL, PosB);

	m_pVtx[0].t= VEC2(uv0.x, uv0.y);
	m_pVtx[1].t= VEC2(uv1.x, uv0.y);
	m_pVtx[2].t= VEC2(uv1.x, uv1.y);
	m_pVtx[3].t= VEC2(uv0.x, uv1.y);



	// ȸ�� ����
	if(pRot)
	{
		FLOAT	fCos = cosf(-fRot);
		FLOAT	fSin = sinf(-fRot);

		VEC2	t;

		for(int i=0; i<4; ++i)
		{
			t = m_pVtx[i].p - vRot;

			m_pVtx[i].p.x = t.x * fCos - t.y * fSin + vRot.x;
			m_pVtx[i].p.y = t.x * fSin + t.y * fCos + vRot.y;
		}
	}



	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetSamplerState(0,D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0,D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);


	// �ܻ��� ��� �ε巴�� ó����
	if(bMono)
	{
		m_pDev->SetSamplerState(0,D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(0,D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(0,D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}
	else
	{
		m_pDev->SetSamplerState(0,D3DSAMP_MAGFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0,D3DSAMP_MINFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0,D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	}


	// SetTexture to Device
	m_pDev->SetTexture(0, pTex->pTex);


	hr = m_pDev->SetVertexDeclaration(m_pFVF);

	hr = m_pEft->SetTechnique("Tech");
	hr = m_pEft->SetInt("m_bMono", bMono);
	hr = m_pEft->SetVector("m_Diff", (D3DXVECTOR4*)&dDiff);
	
	hr = m_pEft->Begin(NULL, 0);
	hr = m_pEft->BeginPass(0);

		hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(CLcSprite::VtxRHWUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	return 0;
}


INT CLcSprite::OnResetDevice()
{
	LPDIRECT3DSURFACE9	pSfc;
	D3DSURFACE_DESC		desc;

	m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pSfc);
	pSfc->GetDesc(&desc);

	m_nScnW = desc.Width;
	m_nScnH = desc.Height;
	pSfc->Release();


	m_pEft->OnResetDevice();

	return 0;
}


void CLcSprite::OnLostDevice()
{
	m_pEft->OnLostDevice();
}



INT LcDev_CreateSprite(char* sCmd, ILcSprite** pData, void* pDev, void* p2, void* p3, void* p4)
{
	CLcSprite*	pObj = NULL;
	*pData = NULL;

	pObj = new CLcSprite;
	if(FAILED(pObj->Create(pDev)))
	{
		delete pObj;
		return -1;
	}

	(*pData) = pObj;
	return 0;
}

