// Implementation of the CMcMesh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcMesh::CMcMesh()
{
	m_pMesh	= NULL;
	m_dMtrl	= 0;
	m_pMtrl	= NULL;
	m_pTex	= NULL;

	m_pVtx	= NULL;
	m_pIdx	= NULL;

	m_nFce	= 0;
	m_nVtx	= 0;

	m_vFVF	= 0;
	m_iFVF	= 0;
}

CMcMesh::~CMcMesh()
{
	Destroy();
}





INT CMcMesh::Create(LPDIRECT3DDEVICE9 pDev, char* xFileName, char* TexturePath)
{
	HRESULT hr=-1;

	m_pDev = pDev;

	char	sTexPath[MAX_PATH]={0};
	
	if(TexturePath)
	{
		strcpy(sTexPath, TexturePath);

		if('/' == sTexPath[strlen(sTexPath)-1])
			sTexPath[strlen(sTexPath)-1]=0;
	}

	//��Ƽ���� ���۸� �������� ���� �ӽ� ����
	LPD3DXBUFFER pD3DXMtrlBuffer;

	//1. �޽��� ���� �ε��Ѵ�.

	if( FAILED( D3DXLoadMeshFromX( xFileName
		,	D3DXMESH_SYSTEMMEM
		,	m_pDev, NULL
		,	&pD3DXMtrlBuffer, NULL
		,	&m_dMtrl, &m_pMesh ) ) )
	{
		return -1;
	}


	// 2. ��Ƽ����� �ؽ�ó�� �����Ѵ�.
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	m_pMtrl = new D3DMATERIAL9[m_dMtrl];
	m_pTex  = new LPDIRECT3DTEXTURE9[m_dMtrl];

	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		m_pMtrl[i] = d3dxMaterials[i].MatD3D;		// ��Ƽ���� ����
		m_pMtrl[i].Ambient = m_pMtrl[i].Diffuse;	// ��Ƽ������ Ambient ����
		m_pTex[i] = NULL;

		if(NULL == TexturePath)
			continue;


		if( d3dxMaterials[i].pTextureFilename != NULL &&  lstrlen(d3dxMaterials[i].pTextureFilename) > 0 )
		{

			// �ؽ�ó�� �����Ѵ�.
			TCHAR	sFile[512];

			sprintf(sFile, "%s/%s", sTexPath, d3dxMaterials[i].pTextureFilename);

			//�ؽ�ó ����
			hr = D3DXCreateTextureFromFileEx(m_pDev
							, sFile
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, D3DFMT_UNKNOWN
							, D3DPOOL_MANAGED
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0x00FFFFFF
							, NULL
							, NULL
							, &m_pTex[i]);

			if( FAILED( hr ) )
			{
	//			MessageBox( GetActiveWindow(), "Could not find texture map", "Meshes.exe", MB_OK);
			}

		}
	}

	// �ӽ� ���۸� �����Ѵ�.
	pD3DXMtrlBuffer->Release();


	LPDIRECT3DINDEXBUFFER9  pIB = NULL;

	m_nFce = m_pMesh->GetNumFaces();
	m_nVtx = m_pMesh->GetNumVertices();

	m_vFVF = m_pMesh->GetFVF();
	m_iFVF = D3DFMT_INDEX16;


	//m_pMesh->GetIndexBuffer (&pIB);
	//D3DINDEXBUFFER_DESC dsc;
	//pIB->GetDesc(&dsc);
	//nIdx = dsc.Format;
	//pIB->Release();

	m_pVtx = new TvtxNUV1[m_nVtx];
	m_pIdx = new TvtxIdx [m_nFce];

	LPVOID	buf;
    m_pMesh->LockVertexBuffer(0, &buf);

	memcpy(m_pVtx, buf, m_nVtx * sizeof(TvtxNUV1) );
    m_pMesh->UnlockVertexBuffer();

	m_pMesh->LockIndexBuffer(0, &buf);
	memcpy(m_pIdx, buf, m_nFce * sizeof(TvtxIdx ) );
    m_pMesh->UnlockIndexBuffer();


	int n;
	FILE* fp = fopen("E:/_Document/_Afew_work/glc300/example/ex1/gl5_lgt2/teapot.cpp", "wt");

	fprintf(fp, "\nunsigned short teapot_idx [] = {\n");
	for(n=0; n<m_nFce; ++n)
	{
		int a = m_pIdx[n].a;
		int b = m_pIdx[n].b;
		int c = m_pIdx[n].c;

		fprintf(fp, "%4d, %4d, %4d,", a, c, b);

		c = (n+1) % 8;
		if(0 == c )
			fprintf(fp, "\n");
		else
			fprintf(fp, "   ");
	}

	fprintf(fp, "\n};\n\n");


	fprintf(fp, "float teapot_vtx [] = {\n");

	for(n=0; n<m_nVtx; ++n)
	{
		int c;
		TvtxNUV1*	pVtx = &m_pVtx[n];

		D3DXVECTOR3 pos = pVtx->p;
		D3DXVECTOR3 nor = pVtx->n;
		D3DXVECTOR2 tx0 = pVtx->t;

		pos *= 10;

		fprintf(fp, "%+ff, %+ff, %+ff,", pos.x, pos.z, pos.y);
		fprintf(fp, "%+ff, %+ff, %+ff,", nor.x, nor.z, nor.y);
		fprintf(fp, "%+ff, %+ff,"      , tx0.x, 1.0F - tx0.y);

		c = (n+1) % 4;
		if(0 == c )		fprintf(fp, "\n");
		else			fprintf(fp, "   ");
	}

	fprintf(fp, "\n};\n\n\n");
	fprintf(fp, "unsigned short* GetIdx(){	return teapot_idx;}\n");
	fprintf(fp, "float* GetVtx(){	return teapot_vtx;}\n");
	fprintf(fp, "\n");
	fprintf(fp, "int GetIdxCount(){ return sizeof(teapot_idx)/sizeof(short); }\n");
	fprintf(fp, "int GetVtxCount(){ 	return sizeof(teapot_vtx)/sizeof(float); }\n");
	fprintf(fp, "\n");

	fclose(fp);


	m_pMesh->Release();
	m_pMesh = NULL;

	return 0;
}

void CMcMesh::Destroy()
{
	if(m_pMtrl)
	{
		delete[] m_pMtrl;
		m_pMtrl = NULL;
	
		for( DWORD i = 0; i < m_dMtrl; i++ )
		{
			if( m_pTex[i] )
				m_pTex[i]->Release();
		}

		delete[] m_pTex;
		m_pTex = NULL;
	}

	if(m_pMesh)
	{
		m_pMesh->Release();
		m_pMesh = NULL;
	}


	delete [] m_pVtx;
	delete [] m_pIdx;
}

INT CMcMesh::FrameMove()
{
	return 0;
}

void CMcMesh::Render(BOOL bUseMaterial)
{
	// �ؽ�ó U, V, W�� ��巹�� ��带 Wrap���� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

	// �ؽ�ó�� ���͸��� Linear�� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_ALPHAREF,        156 );
	m_pDev->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATER );


	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		if(bUseMaterial)
		{
			m_pDev->SetMaterial( &m_pMtrl[i] );
			m_pDev->SetTexture( 0, m_pTex[i] );
		}

		m_pDev->SetFVF(m_vFVF);
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_nVtx, m_nFce, m_pIdx, (D3DFORMAT)m_iFVF, m_pVtx, sizeof(TvtxNUV1));
	}


	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetTexture( 0, NULL);
}
