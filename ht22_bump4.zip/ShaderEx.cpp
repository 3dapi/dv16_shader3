// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pEft		= NULL;
	m_pFVF		= NULL;
	
	m_pTxDif	= NULL;
	m_pTxNor	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxNUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/concrete.bmp", &m_pTxDif);
	D3DXCreateTextureFromFile( m_pDev, "data/saint.tga", &m_pTxNor);
	
	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);
	
	SAFE_RELEASE(	m_pTxNor	);
	SAFE_RELEASE(	m_pTxDif	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	MATA	mtWVP;			// World * View * Projection Matrix
	MATA	mtViw;			// View Matrix
	MATA	mtPrj;			// Projection Matrix

	VEC4	vcLgt(-20, 0, 0, 0);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	mtWVP	= mtViw * mtPrj;

	// Render
	m_pDev->SetVertexDeclaration(m_pFVF);

	m_pEft->SetMatrix( "m_mtWVP", &mtWVP);
	m_pEft->SetVector( "m_vcLgt", &vcLgt);


	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);

	
	// �»��
	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map

	m_pEft->BeginPass(0);
	{
		VtxNUV1	pVtx1[4];
		pVtx1[0] =	VtxNUV1(-40.f -90.f, -40.f+45.f, 0.f,	0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f -90.f,  40.f+45.f, 0.f,	0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f -90.f,  40.f+45.f, 0.f,	0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f -90.f, -40.f+45.f, 0.f,	0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();


	// �߾� ���
	m_pEft->SetTexture( "m_TxDif", m_pTxNor);			// Diffuse Map
	m_pEft->BeginPass(0);
	{
		VtxNUV1	pVtx1[4];
		pVtx1[0] =	VtxNUV1(-40.f, -40.f+45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f,  40.f+45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f,  40.f+45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f, -40.f+45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();


	// ����
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ������ ��

	m_pEft->BeginPass(1);
	{
		VtxNUV1	pVtx1[4];

		pVtx1[0] =	VtxNUV1(-40.f +90.F, -40.f+45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f +90.F,  40.f+45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f +90.F,  40.f+45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f +90.F, -40.f+45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();


	// ���ϴ�
	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ������ ��

	m_pEft->BeginPass(2);
	{
		VtxNUV1	pVtx1[4];

		pVtx1[0] =	VtxNUV1(-40.f -90.f, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f -90.f,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f -90.f,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f -90.f, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();


	// �߾� �ϴ�
	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ������ ��

	m_pEft->BeginPass(3);
	{
		VtxNUV1	pVtx1[4];

		pVtx1[0] =	VtxNUV1(-40.f, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();


	// ���ϴ�
	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// Diffuse Map
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ������ ��

	m_pEft->BeginPass(4);
	{
		VtxNUV1	pVtx1[4];

		pVtx1[0] =	VtxNUV1(-40.f +90.F, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 1.f);
		pVtx1[1] =	VtxNUV1(-40.f +90.F,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		0.f, 0.f);
		pVtx1[2] =	VtxNUV1( 40.f +90.F,  40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 0.f);
		pVtx1[3] =	VtxNUV1( 40.f +90.F, -40.f-45.f, 0.f,		0.f, 0.f, -1.f,		1.f, 1.f);

		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx1, sizeof(VtxNUV1));
	}
	m_pEft->EndPass();

	m_pEft->End();

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);
}



