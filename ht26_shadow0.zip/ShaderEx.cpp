// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;
	m_pMdl		= NULL;
	m_pTxLogo	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile(
							m_pDev
							,	"data/shader.fx"
							,	NULL
							,	NULL
							,	dwFlags
							,	NULL
							,	&m_pEft
							,	&pErr);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}




	// Load Model
	SAFE_NEWCREATE2(m_pMdl, CMcMesh, m_pDev, "data/tiger.x");
	m_pMdl->SetFVF(Vtx::FVF);

	// Setup Plane
	m_pPlane[0] = Vtx(-25, 0, -25);
	m_pPlane[1] = Vtx(-25, 0,  25);
	m_pPlane[2] = Vtx( 25, 0,  25);
	m_pPlane[3] = Vtx( 25, 0, -25);


	D3DXCreateTextureFromFile(m_pDev, "data/dx5_logo.png", &m_pTxLogo);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);

	SAFE_DELETE(	m_pMdl		);
	SAFE_RELEASE(	m_pTxLogo	);
}



INT CShaderEx::FrameMove()
{
	VEC3	vcLgtPos(43, 30, 43);
	VEC3	vcLgtLook(0, 0, 0);

	FLOAT fRotAngle = D3DXToRadian( GetTickCount() * 0.02f );
//	fRotAngle = D3DXToRadian(-45);

	vcLgtPos.x *= cosf(fRotAngle);
	vcLgtPos.z *= sinf(fRotAngle);

	D3DXMatrixLookAtLH(&m_mtSdV, &vcLgtPos, &vcLgtLook, &VEC3(0,1,0));
//	D3DXMatrixPerspectiveFovLH(&m_mtSdP, D3DXToRadian(45), 1, 1, 1000);
	D3DXMatrixOrthoLH(&m_mtSdP, 30.0F, 30.0F, 0.0F, 1.0F);

	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	
	MATA	mtWld;
	MATA	mtViw;
	MATA	mtPrj;
	MATA	mtSdV;
	MATA	mtSdP;


	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetTexture(0, m_pTxLogo);

	m_pEft->SetTechnique("Tech0");

	// Setup Model Scaling
	D3DXMatrixScaling(&mtWld, 15, 15, 15);
	mtWld._42 = 10;

	m_pEft->SetMatrix("m_mtWld", &mtWld);
	m_pEft->SetMatrix("m_mtViw", &mtViw);
	m_pEft->SetMatrix("m_mtPrj", &mtPrj);
	m_pEft->SetMatrix("m_mtSdV", &m_mtSdV);
	m_pEft->SetMatrix("m_mtSdP", &m_mtSdP);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		// Draw Model
		m_pMdl->Render();

		// Draw Plane
		D3DXMatrixIdentity(&mtWld);
		m_pEft->SetMatrix("m_mtWld", &mtWld);
		m_pDev->SetFVF(Vtx::FVF);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pPlane, sizeof(Vtx));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


