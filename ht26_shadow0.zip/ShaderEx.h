// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef	LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct Vtx
	{
		VEC3	p;

		Vtx(){}
		Vtx(	FLOAT X, FLOAT Y, FLOAT Z) : p(X,Y,Z){}

		enum { FVF = (D3DFVF_XYZ)};
	};


protected:
	PDEV		m_pDev;			// IDirect3DDevice
	PDEF		m_pEft;			// ID3DXEffect

	CMcMesh*	m_pMdl;			// Model
	Vtx			m_pPlane[4];	// Plane
	PDTX		m_pTxLogo;

	MATA		m_mtSdV;
	MATA		m_mtSdP;


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};


#endif


