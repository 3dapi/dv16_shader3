// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3						VEC3;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DCUBETEXTURE9			PDTC;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef	LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxIdx
	{
		WORD a, b, c;

		VtxIdx() : a(0), b(0), c(0){}
		VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		enum {FVF = D3DFMT_INDEX16, };
	};
	
	struct Vtx
	{
		VEC3	p;
		enum { FVF = (D3DFVF_XYZ),};
	};

protected:
	PDEV		m_pDev;
	
	PDVD		m_pFVF;
    PDEF		m_pEft;

	int			m_TileN;
	FLOAT		m_TileW;
	int			m_nVtx;
	int			m_nFce;
	VtxIdx*		m_pFce;
	Vtx*		m_pVtx;
	
	PDTC		m_pTxCbm;
	PDTX		m_pTxNor;

public:
	CShaderEx();
	~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	void	SetTexture(PDTC	pTex);
};


#endif


