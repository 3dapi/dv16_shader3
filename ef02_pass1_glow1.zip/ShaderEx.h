// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxNDUV1
	{
		VEC3	p;
		VEC3	n;
		DWORD	d;
		FLOAT	u, v;

		VtxNDUV1()						: p(0,0,0),n(0,0,0),u(0),v(0), d(0xFFFFFFFF){}
		VtxNDUV1(	FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT NX, FLOAT NY, FLOAT NZ
				, FLOAT U, FLOAT V
				, DWORD D=0XFFFFFFFF)	: p(X,Y,Z),n(NX,NY,NZ),u(U),v(V),d(D){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1)	};

	};

public:
	PDEV		m_pDev;				// Device
	PDEF		m_pEft;				// ID3DXEffect Instance
	PDVD		m_pFVF;				// Vertex Declarator

	MATA		m_mtWld;			// World Matrix

	INT			m_iNvx;				// Vertex Number
	VtxNDUV1*	m_pVtx;				// Vertex Buffer
	PDTX		m_pTx;


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

