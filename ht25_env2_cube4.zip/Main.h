// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


typedef LPDIRECT3DTEXTURE9		PDTX;
typedef LPD3DXRenderToEnvMap	PDRE;
typedef LPDIRECT3DCUBETEXTURE9	PDTC;


class CMain : public CD3DApplication
{
public:
	ID3DXFont*	m_pD3DXFont;														// D3DX font
	TCHAR		m_sMsg[512];

	CMcInput*	m_pInput;
	CMcCam*		m_pCam;
	CMcGrid*	m_pGrid;

	CMcMesh*	m_pSkyBox;
	
	CShaderEx*	m_pShader;

	INT			m_nEnvOpt;
	PDRE		m_pRndEnv;
    PDTC		m_pTxCbm;
	
public:
	CMain();

protected:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();

	virtual	LRESULT MsgProc(HWND,UINT,WPARAM,LPARAM);

	void	RenderText();
	HRESULT RenderScene();
	HRESULT RenderScene(D3DXMATRIX *pView, D3DXMATRIX *pProject);
};


extern CMain*	g_pApp;


#endif
