// Implementation of the CLcSpriteX class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "LcSpriteX.h"

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;
typedef D3DXCOLOR						DCOL;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DPIXELSHADER9			PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef	LPD3DXEFFECT					PDEF;


class CLcSpriteX : public ILcSpriteX
{
public:
	struct VtxRHWUV1
	{
		VEC2	p;
		FLOAT	z;
		FLOAT	w;
		VEC2	t0;
		VEC2	t1;
		
		VtxRHWUV1()	: p(0,0), z(0), w(1), t0(0,0), t1(0,0){}
		VtxRHWUV1(FLOAT X,FLOAT Y,FLOAT Z
					,FLOAT U0,FLOAT V0
					,FLOAT U1,FLOAT V1
					):p(X,Y), z(Z), w(1), t0(U0,V0), t1(U1,V1){}

		enum {FVF = (D3DFVF_XYZRHW|D3DFVF_TEX2),};
	};

public:
	PDEV			m_pDev;			// Device
	PDVD			m_pFVF;
	PDEF			m_pEft;			// ID3DXEffect
	VtxRHWUV1		m_pVtx[4];		// Vertex Buffer

	INT				m_nScnW;
	INT				m_nScnH;

	
public:
	CLcSpriteX();
	virtual ~CLcSpriteX();
	
	INT		Create(void* pDev);
	void	Destroy();

	virtual INT		DrawEx(void* pTex0, void* pTex1, RECT* rc1, RECT* rc2, VEC2* pScl, VEC2* pRot, FLOAT fRot, VEC2* pTrl, DWORD dColor, INT bMono);
	virtual INT		OnResetDevice();
	virtual void	OnLostDevice();
};




CLcSpriteX::CLcSpriteX()
{
	m_pDev		= NULL;
	m_pFVF		= NULL;
	m_pEft		= NULL;

	m_nScnW		= 1024;
	m_nScnH		= 768;


	m_pVtx[0].t0 = VEC2(0, 0);
	m_pVtx[1].t0 = VEC2(1, 0);
	m_pVtx[2].t0 = VEC2(1, 1);
	m_pVtx[3].t0 = VEC2(0, 1);

	m_pVtx[0].t1 = VEC2(0, 0);
	m_pVtx[1].t1 = VEC2(1, 0);
	m_pVtx[2].t1 = VEC2(1, 1);
	m_pVtx[3].t1 = VEC2(0, 1);

}


CLcSpriteX::~CLcSpriteX()
{
	Destroy();
}


INT CLcSpriteX::Create(void* pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	char	sShader[]=
		" int     m_bTx1;                               \n"
		" int     m_bMono;                              \n"
		" float4  m_Diff;                               \n"
		"                                               \n"
		" sampler smp0 : register(s0);                  \n"
		" sampler smp1 : register(s1);                  \n"
		"                                               \n"
		" void VtxProc( in  float4 inPos0: POSITION     \n"
		"             , in  float2 inTex0: TEXCOORD0    \n"
		"             , in  float2 inTex1: TEXCOORD1    \n"
		"             , out float4 otPos0: POSITION     \n"
		"             , out float2 otTex0: TEXCOORD0    \n"
		"             , out float2 otTex1: TEXCOORD1    \n"
		"             )                                 \n"
		" {                                             \n"
		"     otPos0 = inPos0;                          \n"
		"     otTex0 = inTex0;                          \n"
		"     otTex1 = inTex1;                          \n"
		" }                                             \n"
		"                                               \n"
		" float4 PxlProc(float4 Pos0: POSITION          \n"
		"             , float2 Tex0: TEXCOORD0          \n"
		"             , float2 Tex1: TEXCOORD1):COLOR0  \n"
		" {                                             \n"
		"     float4  Out= 0;                           \n"
		"     float4  t0 = tex2D(smp0, Tex0);           \n"
		"     float4  t1 = tex2D(smp1, Tex1);           \n"
		"                                               \n"
		"     if(0 != m_bTx1)                           \n"
		"         Out = t0 * t1;                        \n"
		"     else                                      \n"
		"         Out = t0;                             \n"
		"                                               \n"
		"     Out *= m_Diff;                            \n"
		"     if(0 != m_bMono)                          \n"
		"     {                                         \n"
		"         Out.a *= m_Diff.a;                    \n"
		"         Out.r= m_Diff.r;                      \n"
		"         Out.g= m_Diff.g;                      \n"
		"         Out.b= m_Diff.b;                      \n"
		"     }                                         \n"
		"                                               \n"
		"     return Out;                               \n"
		" }                                             \n"
		"                                               \n"
		" technique Tech                                \n"
		" {                                             \n"
		"    pass P0                                    \n"
		"    {                                          \n"
		"      VertexShader = compile vs_1_1 VtxProc(); \n"
		"      PixelShader  = compile ps_2_0 PxlProc(); \n"
		"    }                                          \n"
		" };                                            \n"
		;


	LPD3DXBUFFER	pError	= NULL;
	DWORD		dFlag=0;

	#if defined( _DEBUG ) || defined( DEBUG )
	dFlag |= D3DXSHADER_DEBUG;
	#endif

	// ������
	hr = D3DXCreateEffect(	m_pDev
							, sShader
							, strlen(sShader)-4
							, NULL
							, NULL
							, dFlag
							, NULL
							, &m_pEft
							, &pError);
	if(FAILED(hr))
	{
		MessageBox(GetActiveWindow()
					, (char*)pError->GetBufferPointer()
					, "Error", 0);
		return -1;
	}
	
	// ���� ���� ����
	D3DVERTEXELEMENT9 pVertexElement[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(CLcSpriteX::VtxRHWUV1::FVF, pVertexElement);
	m_pDev->CreateVertexDeclaration(pVertexElement, &m_pFVF);


	return 0;
}

void CLcSpriteX::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVF		);
}


INT CLcSpriteX::DrawEx(void* pLcTex0, void* pLcTex1, RECT* pRc1, RECT* pRc2, VEC2* pScl, VEC2* pRot, FLOAT fRot, VEC2* pTrn, DWORD _dCol, INT _bMono)
{
	HRESULT hr=0;

	INT		bTex1 = 0;
	INT		bMono = 0;
	DCOL	dDiff = 0XFFFFFFFF;
	VEC2	vScl(1,1);
	VEC2	vRot(0,0);
	VEC2	vTrn(0,0);

	RECT	rc1	 = {0, 0, 2048, 2048};
	RECT	rc2	 = {0, 0, 2048, 2048};

	VEC2	uv00(0,0);
	VEC2	uv01(1,1);
	VEC2	uv10(0,0);
	VEC2	uv11(1,1);

	FLOAT	rcW1 = 0;
	FLOAT	rcH1 = 0;
	FLOAT	rcW2 = 0;
	FLOAT	rcH2 = 0;
	
	FLOAT	PosL = 0;
	FLOAT	PosT = 0;
	FLOAT	PosR = 0;
	FLOAT	PosB = 0;

	LcTexture*	pTex0= (LcTexture*)pLcTex0;
	LcTexture*	pTex1= (LcTexture*)pLcTex1;

	PDTX	pDXTx0 = NULL;
	PDTX	pDXTx1 = NULL;

	// �ؽ�ó�� ������ ���� ����.
	if(NULL == pTex0 || NULL == pTex0->pTex)
		return 0;



	// 1. �Է� �� ����
	dDiff = _dCol;
	bMono = _bMono;


	// 1.1 �̹��� �ҽ� 1 ���� ����
	if(pRc1)
	{
		rc1.left  = pRc1->left  ;
		rc1.right = pRc1->right ;
		rc1.top	  = pRc1->top	 ;
		rc1.bottom= pRc1->bottom;
	}
	else
	{
		rc1.right = pTex0->ImgW;
		rc1.bottom= pTex0->ImgH;
	}


	// ���� �� ����
	if(rc1.left<0)				rc1.left  = 0;
	if(rc1.right>pTex0->ImgW)	rc1.right = pTex0->ImgW;
	if(rc1.top<0)				rc1.top   = 0;
	if(rc1.bottom>pTex0->ImgH)	rc1.bottom= pTex0->ImgH;


	// ������ �߸� ������ �����
	if(rc1.top>=rc1.bottom || rc1.left>=rc1.right)
		return 0;


	// uv ����
	uv00.x = FLOAT(rc1.left  )/FLOAT(pTex0->TexW);
	uv00.y = FLOAT(rc1.top   )/FLOAT(pTex0->TexH);
	uv01.x = FLOAT(rc1.right )/FLOAT(pTex0->TexW);
	uv01.y = FLOAT(rc1.bottom)/FLOAT(pTex0->TexH);

	// 1.2 �̹��� �ҽ� 2 ���� ����
	if(pRc2)
	{
		rc2.left  = pRc2->left  ;
		rc2.right = pRc2->right ;
		rc2.top	  = pRc2->top	;
		rc2.bottom= pRc2->bottom;
	}
	else if(pTex1)
	{
		rc2.right = pTex1->ImgW;
		rc2.bottom= pTex1->ImgH;
	}


	// ���� �� ����
	if(rc2.left<0)						rc2.left  = 0;
	if(pTex1 &&rc2.right>pTex1->ImgW)	rc2.right = pTex1->ImgW;
	if(rc2.top<0)						rc2.top   = 0;
	if(pTex1 &&rc2.bottom>pTex1->ImgH)	rc2.bottom= pTex1->ImgH;

	if(pTex1)
	{
		uv10.x = FLOAT(rc2.left  )/ FLOAT(pTex1->TexW);
		uv10.y = FLOAT(rc2.top   )/ FLOAT(pTex1->TexH);
		uv11.x = FLOAT(rc2.right )/ FLOAT(pTex1->TexW);
		uv11.y = FLOAT(rc2.bottom)/ FLOAT(pTex1->TexH);
	}
	

	if(pScl)	vScl = *pScl;
	if(pRot)	vRot = *pRot;
	if(pTrn)	vTrn = *pTrn;


	rcW1	= FLOAT(rc1.right - rc1.left);
	rcH1	= FLOAT(rc1.bottom- rc1.top );

	rcW2	= FLOAT(rc2.right - rc2.left);
	rcH2	= FLOAT(rc2.bottom- rc2.top );



	// Scaling ����
	if(vScl.x>=0.f)
	{
		PosL =  vTrn.x;
		PosR = PosL + rcW1 * vScl.x;
	}
	else
	{
		PosR =  vTrn.x;
		PosL = PosR - vScl.x;
	}


	if(vScl.y>=0.f)
	{
		PosT = vTrn.y;
		PosB = PosT + rcH1 * vScl.y;
	}
	else
	{
		PosB = vTrn.y;
		PosT = PosB - rcH1 * vScl.y;
	}


	// ���� ����
	m_pVtx[0].p = VEC2(PosL, PosT);
	m_pVtx[1].p = VEC2(PosR, PosT);
	m_pVtx[2].p = VEC2(PosR, PosB);
	m_pVtx[3].p = VEC2(PosL, PosB);

	m_pVtx[0].t0= VEC2(uv00.x, uv00.y);
	m_pVtx[1].t0= VEC2(uv01.x, uv00.y);
	m_pVtx[2].t0= VEC2(uv01.x, uv01.y);
	m_pVtx[3].t0= VEC2(uv00.x, uv01.y);

	m_pVtx[0].t1= VEC2(uv10.x, uv10.y);
	m_pVtx[1].t1= VEC2(uv11.x, uv10.y);
	m_pVtx[2].t1= VEC2(uv11.x, uv11.y);
	m_pVtx[3].t1= VEC2(uv10.x, uv11.y);



	// ȸ�� ����
	if(pRot)
	{
		FLOAT	fCos = cosf(-fRot);
		FLOAT	fSin = sinf(-fRot);

		VEC2	t;

		for(int i=0; i<4; ++i)
		{
			t = m_pVtx[i].p - vRot;

			m_pVtx[i].p.x = t.x * fCos - t.y * fSin + vRot.x;
			m_pVtx[i].p.y = t.x * fSin + t.y * fCos + vRot.y;
		}
	}



	bTex1 = (INT)pTex1;
	pDXTx0 = pTex0->pTex;

	if(pTex1)
		pDXTx1 = pTex1->pTex;


	for(INT i=0; i<2; ++i)
	{
		m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

		// �ܻ��� ��� �ε巴�� ó��
		if(bMono)
		{
			m_pDev->SetSamplerState(i,D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
			m_pDev->SetSamplerState(i,D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
			m_pDev->SetSamplerState(i,D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		}
		else
		{
			m_pDev->SetSamplerState(i,D3DSAMP_MAGFILTER, D3DTEXF_NONE);
			m_pDev->SetSamplerState(i,D3DSAMP_MINFILTER, D3DTEXF_NONE);
			m_pDev->SetSamplerState(i,D3DSAMP_MIPFILTER, D3DTEXF_NONE);	
		}
	}


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


	m_pDev->SetTexture(0, pDXTx0);
	m_pDev->SetTexture(1, pDXTx1);

	hr = m_pDev->SetVertexDeclaration(m_pFVF);

	hr = m_pEft->SetTechnique("Tech");
	hr = m_pEft->SetInt("m_bTx1" , bTex1);
	hr = m_pEft->SetInt("m_bMono", bMono);
	hr = m_pEft->SetVector("m_Diff", (D3DXVECTOR4*)&dDiff);
	
	hr = m_pEft->Begin(NULL, 0);
	hr = m_pEft->BeginPass(0);

		hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(CLcSpriteX::VtxRHWUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	return 0;
}


INT CLcSpriteX::OnResetDevice()
{
	LPDIRECT3DSURFACE9	pSfc;
	D3DSURFACE_DESC		desc;

	m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pSfc);
	pSfc->GetDesc(&desc);

	m_nScnW = desc.Width;
	m_nScnH = desc.Height;
	pSfc->Release();


	m_pEft->OnResetDevice();

	return 0;
}


void CLcSpriteX::OnLostDevice()
{
	m_pEft->OnLostDevice();
}




INT LcDev_CreateSpriteX(char* sCmd, ILcSpriteX** pData, void* pDev, void* p2, void* p3, void* p4)
{
	CLcSpriteX*	pObj = NULL;
	*pData = NULL;

	pObj = new CLcSpriteX;
	if(FAILED(pObj->Create(pDev)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}

