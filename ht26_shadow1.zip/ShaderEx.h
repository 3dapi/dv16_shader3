// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;
typedef D3DXCOLOR						DCOL;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef	LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxN
	{
		VEC3	p;
		VEC3	n;

		VtxN()	: p(0,0,0),n(0,0,0){}
		VtxN(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT Nx,FLOAT Ny,FLOAT Nz): p(X,Y,Z),n(Nx,Ny,Nz){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL)	};
	};


protected:
	PDEV		m_pDev;			// IDirect3DDevice
	PDEF		m_pEft;			// ID3DXEffect

	MATA		m_mtWld[2];		// World Matrix for Model
	MATA		m_mtSdV;		// Shadow View Matrix
	MATA		m_mtSdP;		// Shadow Projection Matrix

	VEC4		m_vcLgt;		// Lighting Direction

	CMcMesh*	m_pStar;		// Star
	VtxN		m_Floor[4];		// Floor
	IrenderTarget*	m_pTrnd;	// Rendering Target for Shadow Map

public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
	
protected:
	void	RenderToShadowMap();
	void	RenderShadowTexture();
};


#endif


