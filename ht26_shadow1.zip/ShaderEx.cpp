// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


const int	SHADOW_MAP_SIZE = 1024;


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;

	m_pStar		= NULL;
	m_pTrnd		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile(
							m_pDev
							,	"data/shader.fx"
							,	NULL
							,	NULL
							,	dwFlags
							,	NULL
							,	&m_pEft
							,	&pErr);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}



	// Create Texture for Shadow Map: D3DFMT_R32F Format
	if(FAILED(LcD3D_CreateRenderTarget("Shadow", &m_pTrnd, m_pDev, SHADOW_MAP_SIZE, SHADOW_MAP_SIZE)))
		return -1;


	// Load Model
	SAFE_NEWCREATE2(m_pStar, CMcMesh, m_pDev, "data/star.x");
	m_pStar->SetFVF(VtxN::FVF);


	// Floor
	FLOAT	fW = 16.0F;
	m_Floor[0] = VtxN(-fW, -0.F,  fW,   0.F, 1.F, 0.F);
	m_Floor[1] = VtxN( fW, -0.F,  fW,   0.F, 1.F, 0.F);
	m_Floor[2] = VtxN(-fW, -0.F, -fW,   0.F, 1.F, 0.F);
	m_Floor[3] = VtxN( fW, -0.F, -fW,   0.F, 1.F, 0.F);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);

	SAFE_DELETE(	m_pStar		);
	SAFE_DELETE(	m_pTrnd		);
}



INT CShaderEx::FrameMove()
{
	// Model offset
	VEC3 vModelOffs = VEC3(5.0F, 4.0F, -5.0F);


	MATA	mtStar;
	FLOAT	fScale= 2;
	D3DXMatrixScaling(&mtStar, fScale, fScale, fScale);
	mtStar._41 = vModelOffs.x;
	mtStar._42 = vModelOffs.y;
	mtStar._43 = vModelOffs.z;

	m_mtWld[0] =	mtStar;
	D3DXMatrixIdentity(&m_mtWld[1]);



	// Light direction
	VEC3 vLightDir(2.0F, 1.0F, -0.5F);
	FLOAT fTime = (FLOAT)(GetTickCount()) * 0.05f;

//	fTime = -10;
	vLightDir.x = 1.5F* cosf( D3DXToRadian(fTime));
	vLightDir.z = 1.5F* sinf( D3DXToRadian(fTime));
	D3DXVec3Normalize(&vLightDir, &vLightDir);

	VEC3	vcLook = vModelOffs;
	VEC3	vcEye  = vcLook + vLightDir * 20;
	VEC3	vcUp   = VEC3(0.0F, 1.0F,  0.0F);
	float	fRadius = m_pStar->GetRadius();

	D3DXMatrixLookAtLH(&m_mtSdV, &vcEye, &vcLook, &vcUp);	// Setup shadow map transform
	D3DXMatrixOrthoLH(&m_mtSdP
						, fRadius*fScale*2.2F
						, fRadius*fScale*2.2F
						, 0.0F, 100.F
						);	// Projection for directional light

	m_vcLgt = VEC4(vLightDir.x, vLightDir.y, vLightDir.z, 0);



	RenderToShadowMap();


	return 0;
}


void CShaderEx::Render()
{
	MATA	mtViw;
	MATA	mtPrj;

	PDTX	pTex = (PDTX)m_pTrnd->GetTexture();

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pEft->SetTechnique("Tech0");

	m_pEft->SetMatrix("m_mtViw", &mtViw);
	m_pEft->SetMatrix("m_mtPrj", &mtPrj);
	m_pEft->SetMatrix("m_mtSdV", &m_mtSdV);
	m_pEft->SetMatrix("m_mtSdP", &m_mtSdP);
	m_pEft->SetVector("m_vLght", &m_vcLgt);
	m_pEft->SetTexture("m_TxShd", pTex);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(1);

		// Render floor
		m_pEft->SetMatrix("m_mtWld", &m_mtWld[1]);
		m_pEft->SetVector("m_dDiff", (VEC4*)&DCOL(0, 0.7F, 1, 1));

		m_pDev->SetFVF(VtxN::FVF);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_Floor, sizeof(VtxN) );


		// Render Model
		m_pEft->SetMatrix("m_mtWld", &m_mtWld[0]);
		m_pEft->SetVector("m_dDiff", (VEC4*)&DCOL(2, 1.F,0.3f, 1));

		m_pStar->Render();

		m_pDev->SetTexture(0, NULL);

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	RenderShadowTexture();
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();
	m_pTrnd->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
	m_pTrnd->OnLostDevice();
}



void CShaderEx::RenderToShadowMap()
{
	MATA	mtWld;

	// Change Rendering Target and Draw Depth of Map and Model
	if(FAILED(m_pTrnd->BeginScene(D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF)))
		return;

	m_pEft->SetTechnique("Tech0");

	m_pEft->SetMatrix("m_mtSdV", &m_mtSdV);
	m_pEft->SetMatrix("m_mtSdP", &m_mtSdP);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		// Rendering Star
		mtWld = m_mtWld[0];
		m_pEft->SetMatrix("m_mtWld", &mtWld);
		m_pStar->Render();

		// Rendering Floor
		mtWld = m_mtWld[1];
		m_pEft->SetMatrix("m_mtWld", &mtWld);
		m_pDev->SetFVF(VtxN::FVF);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_Floor, sizeof(VtxN) );

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);


	// Restore Rendering Target of Device
	m_pTrnd->EndScene();
}


void CShaderEx::RenderShadowTexture()
{
	// Depth Saved Texture
	PDTX pTex = (PDTX)m_pTrnd->GetTexture();

	float width = 240.0F;

	struct TvtxRhw
	{
		float x,y,z,w;
		float u,v;
	} Vertex[4]=
	{
		{    0,    0, 0, 1, 0, 0},
		{width,    0, 0, 1, 1, 0},
		{width,width, 0, 1, 1, 1},
		{    0,width, 0, 1, 0, 1},
	};

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTexture( 0, pTex );
	m_pDev->SetFVF(D3DFVF_XYZRHW|D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TvtxRhw) );
}



