// Implementation of the IrenderTarget class.
//
//////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>


#include "RenderTarget.h"


typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DSURFACE9				PDSF;
typedef LPDIRECT3DCUBETEXTURE9			PDCB;



#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }



class CrenderTarget : public IrenderTarget
{
protected:
	PDEV	m_pDev	;		// Device
	PDSF	m_pDevC	;		// Color Buffer of Device
	PDSF	m_pDevD	;		// Depth-Stencis Buffer of Device

	INT		m_nType	;		// 0: ID3DXRenderToSurface, 1: ID3DXRenderToEnvMap(Sphere) 2: CubeMap
	INT		m_iW	;		// Width
	INT		m_iH	;		// Height
	DWORD	m_dC	;		// Color Format
	DWORD	m_dD	;		// Depth Format

	PDTX	m_pTexT	;
	PDSF	m_pTexS	;
	PDSF	m_pTexD	;

	PDCB	m_pTexC	;		// Cube Map Texture

public:
	CrenderTarget();
	virtual ~CrenderTarget();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();

	virtual	INT		OnResetDevice();
	virtual	INT		OnLostDevice();

	virtual	INT		BeginScene(DWORD dClearMode = (0x1L|0x2L|0x4L), DWORD dClearColor = 0xFF006699);
	virtual	INT		EndScene();

	virtual	INT		GetWidth();
	virtual	INT		GetHeight();
	virtual	DWORD	GetFmtColor();
	virtual	DWORD	GetFmtDepth();

	virtual	void*	GetTexture() const;
	virtual	void*	GetSurface() const;

protected:
	INT		CreateRenderSurface();
};



CrenderTarget::CrenderTarget()
{
	m_nType	= LCX_TARGET_TEXTURE;
	m_iW	= -1;
	m_iH	= -1;

	m_dC	= 0xFFFFFFFF;
	m_dD	= 0xFFFFFFFF;

	m_pDev	= NULL;
	m_pDevC	= NULL;
	m_pDevD	= NULL;

	m_pTexT	= NULL;
	m_pTexS	= NULL;
	m_pTexD	= NULL;
}


CrenderTarget::~CrenderTarget()
{
	Destroy();
}


INT CrenderTarget::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	m_iW	= (INT )p2;
	m_iH	= (INT )p3;
	m_nType	= (INT )p4;

	return CreateRenderSurface();
}



INT CrenderTarget::CreateRenderSurface()
{
	HRESULT hr=-1;

	D3DSURFACE_DESC		dscC;
	D3DSURFACE_DESC		dscD;

	m_pDev->GetRenderTarget(0,&m_pDevC);
	m_pDev->GetDepthStencilSurface(&m_pDevD);

    m_pDevC->GetDesc(&dscC);
	m_pDevD->GetDesc(&dscD);


	if(m_iW<0)
		m_iW = dscC.Width;
	
	if(m_iH<0)
		m_iH = dscC.Height;


	m_dC = dscC.Format;
	m_dD = dscD.Format;

	if(LCX_TARGET_HDR16 == m_nType)
		m_dC = D3DFMT_A16B16G16R16F;

	else if(LCX_TARGET_HDR32 == m_nType)
		m_dC = D3DFMT_A32B32G32R32F;

	else if(LCX_TARGET_SHADOW== m_nType)
		m_dC = D3DFMT_R32F;


	hr = D3DXCreateTexture(m_pDev
							, m_iW
							, m_iH
							, 1
							, D3DUSAGE_RENDERTARGET
							, (D3DFORMAT)m_dC
							, D3DPOOL_DEFAULT
							, &m_pTexT);

	if(FAILED(hr))
        return -1;

	hr = m_pTexT->GetSurfaceLevel(0, &m_pTexS);

	if(FAILED(hr))
		return -1;

	// Clear 0x0
	m_pDev->ColorFill(m_pTexS, NULL, 0x0);

	hr = m_pDev->CreateDepthStencilSurface(m_iW, m_iH
										, dscD.Format
										, D3DMULTISAMPLE_NONE, 0, TRUE
										, &m_pTexD, NULL);

	return hr;
}


void CrenderTarget::Destroy()
{
	SAFE_RELEASE(	m_pDevC	);
	SAFE_RELEASE(	m_pDevD	);
	SAFE_RELEASE(	m_pTexT	);
	SAFE_RELEASE(	m_pTexS	);
	SAFE_RELEASE(	m_pTexD	);
}


INT CrenderTarget::OnResetDevice()
{
	if(NULL == m_pTexT)
		return CreateRenderSurface();

	return 0;
}

INT CrenderTarget::OnLostDevice()
{
	Destroy();

	return 0;
}


INT CrenderTarget::BeginScene(DWORD dClearMode, DWORD dClearColor)
{
	HRESULT hr = -1;
	
	hr = m_pDev->SetRenderTarget(0, m_pTexS);
	hr = m_pDev->SetDepthStencilSurface(m_pTexD);

	if(0xFFFFFFFF != dClearMode)
		hr = m_pDev->Clear( 0L, NULL, dClearMode, dClearColor, 1.0f, 0L );

	return hr;
}


INT CrenderTarget::EndScene()
{
	HRESULT hr = -1;

	hr = m_pDev->SetRenderTarget(0, m_pDevC);
	hr = m_pDev->SetDepthStencilSurface(m_pDevD);

	return hr;
}


INT CrenderTarget::GetWidth()
{
	return m_iW;
}

INT CrenderTarget::GetHeight()
{
	return m_iH;
}


DWORD CrenderTarget::GetFmtDepth()
{
	return m_dD;
}

DWORD CrenderTarget::GetFmtColor()
{
	return m_dC;
}


void* CrenderTarget::GetTexture() const
{
	return m_pTexT;
}


void* CrenderTarget::GetSurface() const
{
	return m_pTexS;
}





INT LcD3D_CreateRenderTarget(char* sCmd, IrenderTarget** pData, void* pDev, INT iWidth, INT iHeight)
{
	*pData = NULL;

	CrenderTarget*	p = new CrenderTarget;

	INT	nType = IrenderTarget::LCX_TARGET_TEXTURE;

	if(sCmd && 0 == _stricmp("HDR16", sCmd))
		nType	= IrenderTarget::LCX_TARGET_HDR16;

	if(sCmd && 0 == _stricmp("HDR32", sCmd))
		nType	= IrenderTarget::LCX_TARGET_HDR32;
	
	if(sCmd && 0 == _stricmp("Sphere", sCmd))
		nType	= IrenderTarget::LCX_TARGET_SPHERE;

	if(sCmd && 0 == _stricmp("Cube", sCmd))
		nType	= IrenderTarget::LCX_TARGET_CUBE;

	if(sCmd && 0 == _stricmp("Shadow", sCmd))
		nType	= IrenderTarget::LCX_TARGET_SHADOW;

	if(FAILED(p->Create(pDev, (void*)iWidth, (void*)iHeight, (void*)nType)))
	{
		delete p;
		return -1;
	}

	*pData = p;

	return 0;
}



