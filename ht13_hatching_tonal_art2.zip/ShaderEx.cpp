// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pEft		= NULL;
	m_pFVF		= NULL;

	for(int i=0; i<6; ++i)
		m_pTxStr[i]	= NULL;

	m_pTxDif	= NULL;

	m_pMesh		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxNUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/stroke0.bmp", &m_pTxStr[0]);
	D3DXCreateTextureFromFile( m_pDev, "data/stroke1.bmp", &m_pTxStr[1]);
	D3DXCreateTextureFromFile( m_pDev, "data/stroke2.bmp", &m_pTxStr[2]);
	D3DXCreateTextureFromFile( m_pDev, "data/stroke3.bmp", &m_pTxStr[3]);
	D3DXCreateTextureFromFile( m_pDev, "data/stroke4.bmp", &m_pTxStr[4]);
	D3DXCreateTextureFromFile( m_pDev, "data/stroke5.bmp", &m_pTxStr[5]);

	D3DXCreateTextureFromFile( m_pDev, "data/wood.jpg", &m_pTxDif);


	// Teapot
	LPD3DXMESH		pMshO = NULL;
	LPD3DXBUFFER	pAdjc = NULL;

    // Load the mesh
    hr = D3DXLoadMeshFromX( "Data/teapot.x"
							, D3DXMESH_SYSTEMMEM
							, m_pDev
							, &pAdjc
							, NULL
							, NULL
							, NULL
							, &pMshO );

	if(FAILED(hr))
		return hr;


    // Optimize the mesh for performance
	hr = pMshO->OptimizeInplace(
                        D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE
						, (DWORD*)pAdjc->GetBufferPointer()
						, NULL
						, NULL
						, NULL );

    if( FAILED(hr))
        return hr;


	pMshO->CloneMeshFVF(D3DXMESH_MANAGED, VtxNUV1::FVF, m_pDev, &m_pMesh );
	D3DXComputeNormals( m_pMesh, NULL );

	SAFE_RELEASE(	pMshO	);
	SAFE_RELEASE(	pAdjc	);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);


	for(int i=0; i<6; ++i)
	{
		SAFE_RELEASE(	m_pTxStr[i]	);
	}
	
	SAFE_RELEASE(	m_pTxDif	);

	SAFE_RELEASE(	m_pMesh		);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=50.f * g_pApp->m_fTime;
//	c=90.f;

	if(c>360.f)
		c -=360.f;

	MATA	mtS;
	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixScaling(&mtS, 40, 40, 40);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;
	m_mtWld = mtS * m_mtRot;

	m_mtWld._41 = 10;
	m_mtWld._42 = 30;

	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	// ��ļ���
	MATA	mtWld=m_mtWld;		// World
	MATA	mtViw;				// View Matrix
	MATA	mtPrj;				// Projection Matrix
	MATA	mtRot=m_mtRot;		// Rotation Matrix

	MATA	mtVwI;
	VEC4	vcCam;
	VEC4	vcLgt;

	float	fHtchW	= 2.f;

	FLOAT	fTime = g_pApp->GetTime()*0.3f;

	m_pDev->GetTransform( D3DTS_VIEW,  &mtViw );
	m_pDev->GetTransform( D3DTS_PROJECTION,  &mtPrj );

	D3DXMatrixInverse(&mtVwI, NULL, &mtViw);			// Get the Camera Position in the View Matrix.

	vcCam	= VEC4(mtVwI._41, mtVwI._42, mtVwI._43, 0);
	vcLgt	= VEC4( 1.2f, -0.2f, -.3f, 0);					// Lighting Direction

	D3DXVec4Normalize( &vcLgt, &vcLgt );


	// Render
	m_pDev->SetVertexDeclaration( m_pFVF );				// Vertex Declarator

	m_pEft->SetMatrix( "m_mtWld", &mtWld);
	m_pEft->SetMatrix( "m_mtViw", &mtViw);
	m_pEft->SetMatrix( "m_mtPrj", &mtPrj);
	m_pEft->SetMatrix( "m_mtRot", &mtRot);
	m_pEft->SetVector( "m_vcLgt", &vcLgt );				// Lighting Direction

	m_pEft->SetFloat( "m_fHtchW", fHtchW);				// Hatching Width
	m_pEft->SetTexture("m_TxDif", m_pTxDif);			// Diffuse Texture


	for(int i=0; i<6; ++i)
		m_pDev->SetTexture(i, m_pTxStr[i]);				// Stroke

	m_pEft->SetTechnique( "Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pMesh->DrawSubset( 0 );

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);

	m_pDev->SetTexture(0, NULL);
}



