// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;

	m_pTex	= NULL;
	m_pMsh	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxNUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "data/wood.jpg", &m_pTex);

	// Read Teapot Mesh
	m_pMsh = new CMcMesh;

	hr = m_pMsh->Create(m_pDev, "Data/teapot.x");
	
	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);

	SAFE_RELEASE(	m_pTex	);

	SAFE_DELETE(	m_pMsh	);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=50.f * g_pApp->m_fTime;
//	c=90;

	if(c>360.f)
		c -=360.f;

	MATA	mtS;
	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixScaling(&mtS, 40, 40, 40);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;
	m_mtWld = mtS * m_mtRot;

	m_mtWld._41 = 10;
	m_mtWld._42 = 30;
	
	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	MATA	mtViw;			// View Matrix
	MATA	mtPrj;			// Projection Matrix
	MATA	mtTM; 
	VEC4	vcLgt(-1, -1, 0.5f, 0);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	D3DXVec4Normalize(&vcLgt, &vcLgt);
	mtTM = m_mtWld * mtViw * mtPrj;

	// Render
	m_pDev->SetVertexDeclaration(m_pFVF);

	m_pEft->SetMatrix( "m_mtWVP", &mtTM);
	m_pEft->SetMatrix( "m_mtRot", &m_mtRot);
	m_pEft->SetVector( "m_vcLgt", &vcLgt);
	m_pEft->SetTexture("m_TxDif", m_pTex);

	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);
	
		m_pMsh->Render();

	m_pEft->EndPass();
	m_pEft->End();
	
	
	m_pDev->SetTexture(0, NULL);
	
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);
}


