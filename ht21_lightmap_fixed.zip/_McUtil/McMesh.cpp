// Implementation of the CMcMesh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcMesh::CMcMesh()
{
	m_pMesh	= NULL;
	m_dMtrl	= 0;
	m_pMtrl	= NULL;
	m_pTex	= NULL;
	
}

CMcMesh::~CMcMesh()
{
	Destroy();
}


INT CMcMesh::Create(LPDIRECT3DDEVICE9 pDev, char* xFileName, char* TexturePath)
{
	HRESULT hr=-1;

	m_pDev = pDev;

	char	sTexPath[MAX_PATH]={0};
	
	if(TexturePath)
	{
		strcpy(sTexPath, TexturePath);

		if('/' == sTexPath[strlen(sTexPath)-1])
			sTexPath[strlen(sTexPath)-1]=0;
	}

	//��Ƽ���� ���۸� �������� ���� �ӽ� ����
	LPD3DXBUFFER pD3DXMtrlBuffer;

	//1. �޽��� ���� �ε��Ѵ�.

	if( FAILED( D3DXLoadMeshFromX( xFileName
		,	D3DXMESH_SYSTEMMEM
		,	m_pDev, NULL
		,	&pD3DXMtrlBuffer, NULL
		,	&m_dMtrl, &m_pMesh ) ) )
	{
		return -1;
	}


	// 2. ��Ƽ����� �ؽ�ó�� �����Ѵ�.
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	m_pMtrl = new D3DMATERIAL9[m_dMtrl];
	m_pTex  = new LPDIRECT3DTEXTURE9[m_dMtrl];

	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		m_pMtrl[i] = d3dxMaterials[i].MatD3D;		// ��Ƽ���� ����
		m_pMtrl[i].Ambient = m_pMtrl[i].Diffuse;	// ��Ƽ������ Ambient ����
		m_pTex[i] = NULL;

		if(NULL == TexturePath)
			continue;


		if( d3dxMaterials[i].pTextureFilename != NULL &&  lstrlen(d3dxMaterials[i].pTextureFilename) > 0 )
		{

			// �ؽ�ó�� �����Ѵ�.
			TCHAR	sFile[512];

			sprintf(sFile, "%s/%s", sTexPath, d3dxMaterials[i].pTextureFilename);

			//�ؽ�ó ����
			hr = D3DXCreateTextureFromFileEx(m_pDev
							, sFile
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, D3DFMT_UNKNOWN
							, D3DPOOL_MANAGED
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0x00FFFFFF
							, NULL
							, NULL
							, &m_pTex[i]);

			if( FAILED( hr ) )
			{
	//			MessageBox( GetActiveWindow(), "Could not find texture map", "Meshes.exe", MB_OK);
			}

		}
	}

	// �ӽ� ���۸� �����Ѵ�.
	pD3DXMtrlBuffer->Release();

	return 0;
}

void CMcMesh::Destroy()
{
	if(m_pMtrl)
	{
		delete[] m_pMtrl;
		m_pMtrl = NULL;
	
		for( DWORD i = 0; i < m_dMtrl; i++ )
		{
			if( m_pTex[i] )
				m_pTex[i]->Release();
		}

		delete[] m_pTex;
		m_pTex = NULL;
	}

	if(m_pMesh)
	{
		m_pMesh->Release();
		m_pMesh = NULL;
	}
}

INT CMcMesh::FrameMove()
{
	return 0;
}

void CMcMesh::Render(BOOL bUseMaterial)
{
	// �ؽ�ó U, V, W�� ��巹�� ��带 Wrap���� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

	// �ؽ�ó�� ���͸��� Linear�� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_ALPHAREF,        156 );
	m_pDev->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATER );


	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		if(bUseMaterial)
		{
			m_pDev->SetMaterial( &m_pMtrl[i] );
			m_pDev->SetTexture( 0, m_pTex[i] );
		}

		m_pMesh->DrawSubset( i );
	}


	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetTexture( 0, NULL);
}
