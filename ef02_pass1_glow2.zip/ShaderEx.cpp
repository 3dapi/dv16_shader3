// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pFVF		= NULL;
	m_pEft		= NULL;
	
	m_pMesh		= new CD3DMesh();
	m_pTex		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT	CShaderEx::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile(m_pDev
							,	"data/shader.fx"
							,	NULL
							,	NULL
							,	dwFlags
							,	NULL
							,	&m_pEft
							,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	//	D3DVERTEXELEMENT9 vertex_decl[] =
	//	{
	//		{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	//		{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,	0},
	//		{0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	//		D3DDECL_END()
	//	};

	DWORD	dFVF = (D3DFVF_XYZ | D3DFVF_NORMAL |D3DFVF_TEX1);
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;
	




	// Read Teapot Mesh
	if(FAILED(hr=m_pMesh  ->Create( m_pDev, _T("texture/teapot.x"))))
		return -1;


	D3DUtil_CreateTexture( m_pDev, "Texture/wood.jpg", &m_pTex);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE( m_pEft );      // Shader
	SAFE_RELEASE( m_pFVF );		// Vertex Declarator

	SAFE_RELEASE( m_pTex );

	// Mesh
	m_pMesh->Destroy();
	SAFE_DELETE( m_pMesh );
}



INT CShaderEx::Restore()
{
	// ID3DXEffect Instance
	if(m_pEft)
		m_pEft->OnResetDevice();

	// Mesh
	m_pMesh->RestoreDeviceObjects( m_pDev );

	// Create Vertex Declarator
	if( m_pMesh && m_pMesh->GetSysMemMesh() )
	{
		LPD3DXMESH pMesh;

		DWORD	dFVF = (D3DFVF_XYZ | D3DFVF_NORMAL |D3DFVF_TEX1);
		D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
		D3DXDeclaratorFromFVF(dFVF, vertex_decl);

		m_pMesh->GetSysMemMesh()->CloneMesh(
			m_pMesh->GetSysMemMesh()->GetOptions(), vertex_decl,
			m_pDev, &pMesh );
		D3DXComputeNormals( pMesh, NULL );

		SAFE_RELEASE(m_pMesh->m_pLocalMesh);
		m_pMesh->m_pLocalMesh = pMesh;
	}

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pMesh->InvalidateDeviceObjects(); // Mesh

	// Shader
	if( m_pEft != NULL )
		m_pEft->OnLostDevice();
}



INT CShaderEx::FrameMove()
{
	static float c=0;

	c=50.f * g_pApp->m_fTime;
//	c=90.f;

	if(c>360.f)
		c -=360.f;

	MATA	mtS;
	MATA	mtY;
	MATA	mtZ;
	
	
	// Update World Matrix
	D3DXMatrixScaling(&mtS, 40, 40, 40);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;
	m_mtWld = mtS * m_mtRot;

	m_mtWld._41 = 10;
	m_mtWld._42 = 30;

	return 0;
}

void CShaderEx::Render()
{
	if(!m_pEft)
		return;

	INT i;

	D3DXMATRIX mtViw;
	D3DXMATRIX mtPrj;
	D3DXMATRIX mtWld = m_mtWld;
	D3DXMATRIX mtRot = m_mtRot;

	D3DXVECTOR4 vcLgt(0,0,0,0);
	D3DXVECTOR4 vcCamZ(0,0,0,0);

	m_pDev->GetTransform( D3DTS_VIEW,  &mtViw );
	m_pDev->GetTransform( D3DTS_PROJECTION,  &mtPrj );


	// Lighting
	vcLgt = D3DXVECTOR4( 1.f, 0.f, 0.f, 0);
	D3DXVec4Normalize( &vcLgt, &vcLgt );

	// Camera Z Direction Vector
	D3DXMATRIX mtViwI;
	D3DXMatrixInverse(&mtViwI, NULL, &mtViw);
	vcCamZ = D3DXVECTOR4(mtViwI._41, mtViwI._42, mtViwI._43, 0);



	m_pDev->SetVertexDeclaration( m_pFVF );		// Vertex Declarator
	
	m_pEft->SetTechnique( "Tech");
	m_pEft->Begin(NULL, 0);
	
	m_pEft->SetMatrix( "m_mtWld", &mtWld);		// World Transform Matrix
	m_pEft->SetMatrix( "m_mtViw", &mtViw);		// View Transform Matrix
	m_pEft->SetMatrix( "m_mtPrj", &mtPrj);		// Projection Transform Matrix
	m_pEft->SetMatrix( "m_mtRot", &mtRot);		// Rotation Matrix
	m_pEft->SetVector( "m_vcLgt", &vcLgt);		// Lighting Direction Vector
	m_pEft->SetVector( "m_vcCamZ", &vcCamZ);	// Camera Z Axis Vector
	m_pEft->SetTexture( "m_TxDif", m_pTex);		// Diffuse Map Texure

	D3DMATERIAL9*	pMtrl = m_pMesh->m_pMaterials;
	for( i=0; i<m_pMesh->m_dwNumMaterials; i++ )
	{
		LPDIRECT3DTEXTURE9	pTx = m_pMesh->m_pTextures[i];

		m_pEft->BeginPass(0);
			m_pMesh->m_pLocalMesh->DrawSubset( i );
		m_pEft->EndPass();

		m_pEft->BeginPass(1);
			m_pMesh->m_pLocalMesh->DrawSubset( i );
		m_pEft->EndPass();

		++pMtrl;
	}

	m_pEft->End();


	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}

