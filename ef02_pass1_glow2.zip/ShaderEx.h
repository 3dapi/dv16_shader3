// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
protected:
	PDEV		m_pDev	;

	PDVD		m_pFVF	;		// Vertex Declarator
	PDEF		m_pEft	;		// ID3DXEffect Instance

	CD3DMesh*	m_pMesh	;		// Teapot
	PDTX		m_pTex	;

	D3DXMATRIX	m_mtWld	;
	D3DXMATRIX	m_mtRot	;

public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	 Render();
};



#endif
