// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_

struct VtxRHWDUV1
{
	D3DXVECTOR4	p;
	DWORD		d;
	FLOAT		u,v;

	VtxRHWDUV1(): p(0,0,0,1), u(0),v(0), d(0xFFFFFFFF){}
	VtxRHWDUV1(FLOAT X, FLOAT Y, FLOAT U, FLOAT V, DWORD D=0xFFFFFFFF)
		: p(X,Y, 0, 1), u(U), v(V), d(D){}

	enum { FVF =(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1 ),};
};


class CMain : public CD3DApplication
{
protected:
	CMcInput*		m_pInput	;
	CMcCam*			m_pCam		;
	CMcGrid*		m_pGrid		;
	ID3DXFont*      m_pD3DXFont	;            // D3DX font

	IrenderTarget*	m_pTrnd		;
	CShaderEx*		m_pShader	;

	CMcField*		m_pField	;
	INT				m_TreeNum	;
	CMcMesh*		m_TreeMsh	;
	D3DXMATRIX*		m_TreeMat	;
	CMcMesh*		m_SkyBox	;


public:
	CMain();

protected:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);

	void	RenderText();
	void	RenderScene();
};


extern CMain*	g_pApp;


#endif

