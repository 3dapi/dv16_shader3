// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pFVF	= NULL;
	m_pEft	= NULL;
	
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	m_pVtx[0] = VtxDUV1( -1.05F, -1.02F,	 0.f, 1.f );
	m_pVtx[1] = VtxDUV1(  1.05F, -1.02F,	 1.f, 1.f );
	m_pVtx[2] = VtxDUV1(  1.05F,  1.02F,	 1.f, 0.f );
	m_pVtx[3] = VtxDUV1( -1.05F,  1.02F,	 0.f, 0.f );


	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pErr	= NULL;
	hr = D3DXCreateEffectFromFile(m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(CShaderEx::VtxDUV1::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);
}

INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();
	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	static float	fDeviation	=0.f;
	static float	fDir = 1.f;

	fDeviation +=fDir*0.2f;

	if(fDeviation>5.f)
		fDir *=-1.f;

	if(fDeviation<0.f)
		fDir *=-1.f;


	m_pDev->SetVertexDeclaration( m_pFVF );
	m_pDev->SetVertexDeclaration(m_pFVF);
	
	m_pEft->SetTechnique("Tech");
	m_pEft->SetTexture("m_Tex", m_pTex);
	m_pEft->SetValue("m_fDeviation", &fDeviation, 4);


	UINT	nPass=0;	
	m_pEft->Begin( &nPass, 0);

	for(UINT n=0; n<nPass; ++n)
	{
		m_pEft->BeginPass(n);
			m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
		m_pEft->EndPass();
	}

	m_pEft->End();

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTex = pTx;
}