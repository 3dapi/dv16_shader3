// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxDUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;




	D3DXCreateTextureFromFile(m_pDev, "texture/dx5_logo.bmp", &m_pTex);


	float	fSize = 30;

	m_pVtx[ 0] = VtxDUV1(-1.f, -1.f, -1.f,   0.f, 1.f, 0XFFFF0000);
	m_pVtx[ 1] = VtxDUV1(-1.f,  1.f, -1.f,   0.f, 0.f, 0XFF00FF00);
	m_pVtx[ 2] = VtxDUV1( 1.f,  1.f, -1.f,   1.f, 0.f, 0XFF0000FF);
	m_pVtx[ 3] = VtxDUV1( 1.f, -1.f, -1.f,   1.f, 1.f, 0XFFFF00FF);

	// the back face vertex data
	m_pVtx[ 4] = VtxDUV1(-1.f, -1.f,  1.f,   0.f, 1.f, 0XFFFFFF00);
	m_pVtx[ 5] = VtxDUV1( 1.f, -1.f,  1.f,   0.f, 0.f, 0XFF00FFFF);
	m_pVtx[ 6] = VtxDUV1( 1.f,  1.f,  1.f,   1.f, 0.f, 0XFFFF00FF);
	m_pVtx[ 7] = VtxDUV1(-1.f,  1.f,  1.f,   1.f, 1.f, 0XFFFFFFFF);

	// the top face vertex data
	m_pVtx[ 8] = VtxDUV1(-1.f,  1.f, -1.f,   0.f, 1.f, 0XFFF0FFF0);
	m_pVtx[ 9] = VtxDUV1(-1.f,  1.f,  1.f,   0.f, 0.f, 0XFF0F0FFF);
	m_pVtx[10] = VtxDUV1( 1.f,  1.f,  1.f,   1.f, 0.f, 0XFFFFF00F);
	m_pVtx[11] = VtxDUV1( 1.f,  1.f, -1.f,   1.f, 1.f, 0XFFFFFFFF);

	// the bottom face vertex data
	m_pVtx[12] = VtxDUV1(-1.f, -1.f, -1.f,   0.f, 1.f, 0XFFFF0FF0);
	m_pVtx[13] = VtxDUV1( 1.f, -1.f, -1.f,   0.f, 0.f, 0XFFF0F0FF);
	m_pVtx[14] = VtxDUV1( 1.f, -1.f,  1.f,   1.f, 0.f, 0XFF0FFF0F);
	m_pVtx[15] = VtxDUV1(-1.f, -1.f,  1.f,   1.f, 1.f, 0XFFFFFFFF);

	// the left face vertex data
	m_pVtx[16] = VtxDUV1(-1.f, -1.f,  1.f,   0.f, 1.f, 0XFFF0FFF0);
	m_pVtx[17] = VtxDUV1(-1.f,  1.f,  1.f,   0.f, 0.f, 0XFF0FF0FF);
	m_pVtx[18] = VtxDUV1(-1.f,  1.f, -1.f,   1.f, 0.f, 0XFFFF0F0F);
	m_pVtx[19] = VtxDUV1(-1.f, -1.f, -1.f,   1.f, 1.f, 0XFFFFFFFF);

	// the right face vertex data
	m_pVtx[20] = VtxDUV1( 1.f, -1.f, -1.f,   0.f, 1.f, 0XFFFFF00F);
	m_pVtx[21] = VtxDUV1( 1.f,  1.f, -1.f,   0.f, 0.f, 0XFF0FFFF0);
	m_pVtx[22] = VtxDUV1( 1.f,  1.f,  1.f,   1.f, 0.f, 0XFFF00FFF);
	m_pVtx[23] = VtxDUV1( 1.f, -1.f,  1.f,   1.f, 1.f, 0XFFFFFFFF);


	for(int i=0; i<24; ++i)
		m_pVtx[i].p *=fSize;


	// the front face index data
	m_pIdx[0] = VtxIdx(0, 1, 2);
	m_pIdx[1] = VtxIdx(0, 2, 3);

	// the back face index data
	m_pIdx[2] = VtxIdx(4, 5, 6);
	m_pIdx[3] = VtxIdx(4, 6, 7);

	// the top face index data
	m_pIdx[4] = VtxIdx( 8,  9, 10);
	m_pIdx[5] = VtxIdx( 8, 10, 11);

	// the bottom face index data
	m_pIdx[6] = VtxIdx(12, 13, 14);
	m_pIdx[7] = VtxIdx(12, 14, 15);

	// the left face index data
	m_pIdx[8] = VtxIdx(16, 17, 18);
	m_pIdx[9] = VtxIdx(16, 18, 19);

	// the right face index data
	m_pIdx[10] = VtxIdx(20, 21, 22);
	m_pIdx[11] = VtxIdx(20, 22, 23);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::FrameMove()
{
	D3DXMATRIX	mtRotX;			// Rotation Matrix X
	D3DXMATRIX	mtRotY;			// Rotation Matrix Y
	D3DXMATRIX	mtRotZ;			// Rotation Matrix Z

	
	// Setup Rotating World Matrix
	FLOAT		fAngle = D3DXToRadian(GetTickCount() * 0.03f);
	D3DXMatrixRotationY(&mtRotY, fAngle*3.f);
	D3DXMatrixRotationZ(&mtRotZ, fAngle*2.f);
	D3DXMatrixRotationX(&mtRotX, fAngle*1.f);

	m_mtWld = mtRotY * mtRotZ * mtRotX;
	m_mtWld._42 = 40.f;
	m_mtWld._43 = -30.f;
	
	return 0;
}


void CShaderEx::Render()
{
	HRESULT	hr=-1;

	MATA	mtWld = m_mtWld;
	MATA	mtViw;
	MATA	mtPrj;
	MATA	mtWVP;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	mtWVP = mtWld * mtViw * mtPrj;

	// Setup Constant
	hr = m_pEft->SetMatrix("m_mtWVP", &mtWVP);
	hr = m_pEft->SetTexture("m_TxDif", m_pTex);
	


	// Rendering
	hr = m_pDev->SetVertexDeclaration(m_pFVF);
	hr = m_pEft->SetTechnique("Tech0");

	UINT nPass=0;	
	hr = m_pEft->Begin(&nPass, 0);

	for(UINT n=0; n < nPass; ++n)
	{
		hr = m_pEft->BeginPass(n);
			hr = m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
										, 0
										, 24
										, 12
										, m_pIdx
										, D3DFMT_INDEX16
										, m_pVtx
										, sizeof(VtxDUV1));
		m_pEft->EndPass();
	}

	m_pEft->End();

	// ����, �ȼ� Shader ����
	hr = m_pDev->SetVertexDeclaration(NULL);
	hr = m_pDev->SetVertexShader(NULL);
	hr = m_pDev->SetPixelShader(NULL);
}