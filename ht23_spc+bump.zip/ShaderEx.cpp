// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pEft		= NULL;
	m_pFVF		= NULL;

	m_pTxD		= NULL;
	m_pTxN		= NULL;
	m_pTxS		= NULL;

	m_pMesh		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxNUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/rock_d.tga", &m_pTxD);
	D3DXCreateTextureFromFile( m_pDev, "data/rock_n.tga", &m_pTxN);
	D3DXCreateTextureFromFile( m_pDev, "data/rock_s.tga", &m_pTxS);


	// ������
	LPD3DXMESH		pMshO = NULL;
	LPD3DXBUFFER	pAdjc = NULL;

    // Load the mesh
    hr = D3DXLoadMeshFromX( "Data/teapot.x"
								, D3DXMESH_SYSTEMMEM
								, m_pDev
								, &pAdjc
								, NULL
								, NULL
								, NULL
								, &pMshO );

	if(FAILED(hr))
		return hr;


    // Optimize the mesh for performance
	hr = pMshO->OptimizeInplace(
                        D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE
						, (DWORD*)pAdjc->GetBufferPointer()
						, NULL
						, NULL
						, NULL );

    if( FAILED(hr))
        return hr;


	pMshO->CloneMeshFVF(D3DXMESH_MANAGED, VtxNUV1::FVF, m_pDev, &m_pMesh );
	D3DXComputeNormals( m_pMesh, NULL );

	SAFE_RELEASE(	pMshO	);
	SAFE_RELEASE(	pAdjc	);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);

	SAFE_RELEASE(	m_pTxN	);
	SAFE_RELEASE(	m_pTxD	);
	SAFE_RELEASE(	m_pTxS	);

	SAFE_RELEASE(	m_pMesh	);
}


INT CShaderEx::FrameMove()
{
	// Setup Lighting Direction with Rotating Matrix
	MATA	mtTM;
	MATA	mtRx;
	MATA	mtRz;

	FLOAT	fAngle = D3DXToRadian(GetTickCount() * 0.1F);
	D3DXMatrixRotationY(&mtTM, fAngle*3.f);
	D3DXMatrixRotationZ(&mtRz, fAngle*2.f);
	D3DXMatrixRotationX(&mtRx, fAngle*1.f);

	mtTM *= mtRz;
	mtTM *= mtRx;

	D3DXVec3TransformCoord(&m_vcLgt, &VEC3(0, 1, 0), &mtTM);

	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	// ��ļ���
	MATA	mtWld;			// World Matrix
	MATA	mtViw;			// View Matrix
	MATA	mtPrj;			// Projection Matrix

	MATA	mtRot;			// Rotation Matrix
	MATA	mtScl;			// Scaling Matrix
	MATA	mtTrs;			// Translation Matrix

	MATA	mtVwI;			// Inverse View Matrix
	VEC4	vcCam;			// Camera Position

	VEC4	vcLgt;			// Lighting Direction
	FLOAT	fShrp= 6.0f;	// Sharpness


	FLOAT	fTime = -D3DXToRadian( GetTickCount()*0.04f );


	m_pDev->GetTransform( D3DTS_VIEW,  &mtViw );
	m_pDev->GetTransform( D3DTS_PROJECTION,  &mtPrj );

	D3DXMatrixInverse(&mtVwI, NULL, &mtViw);			// Get the Camera Position in the View Matrix


	vcCam	= VEC4(mtVwI._41, mtVwI._42, mtVwI._43, 0);
	vcLgt	= VEC4(m_vcLgt.x, m_vcLgt.y, m_vcLgt.z, 0);		// Lighting Direction


	// Debugging
//	fTime	= D3DXToRadian( 90);
//	vcLgt	= VEC4( -1.f, -1.f, 1.f, 0);


	D3DXMatrixRotationY(  &mtRot, fTime );				// Setup Rotation Matrix
	D3DXMatrixScaling(    &mtScl, 50.f, 50.f, 50.f);	// Setup Scaling
	D3DXMatrixTranslation(&mtTrs, 0.f, -10.f, 10.f);	// Setup Translation


	mtWld = mtRot * mtScl * mtTrs;						// Make World matrix


	// Rendering
	m_pDev->SetVertexDeclaration( m_pFVF );

	m_pEft->SetMatrix( "m_mtWld", &mtWld);				// World Matrix
	m_pEft->SetMatrix( "m_mtViw", &mtViw);				// View Matrix
	m_pEft->SetMatrix( "m_mtPrj", &mtPrj);				// Projection Matrix
	m_pEft->SetMatrix( "m_mtRot", &mtRot);				// Rotation Matrix
	
	m_pEft->SetVector( "m_vcCam", &vcCam);				// Camera Position
	m_pEft->SetVector( "m_vcLgt", &vcLgt);				// Lighting Direction
	m_pEft->SetFloat(  "m_fShrp", fShrp);

	m_pEft->SetTexture( "m_TxDif", m_pTxD);				// Diffuse Map
	m_pEft->SetTexture( "m_TxNor", m_pTxN);				// Normal Map
	m_pEft->SetTexture( "m_TxSpc", m_pTxS);				// Specular Map

	m_pEft->SetTechnique( "Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pMesh->DrawSubset( 0 );

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);

	m_pDev->SetTexture(0, NULL);
}



