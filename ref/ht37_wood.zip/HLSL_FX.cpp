// HLSL_FX.cpp
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <commctrl.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <D3DX9.h>

#include "_D3D/DXUtil.h"

#include "_D3D/D3DEnumeration.h"
#include "_D3D/D3DSettings.h"
#include "_D3D/D3DApp.h"
#include "_D3D/D3DFont.h"
#include "_D3D/D3DUtil.h"

#include "resource.h"

#include "model_t.h"
#include "d3dmodel_t.h"
#include "noise.h"
#include "random.h"

#include "Main.h"


INT WINAPI WinMain (HINSTANCE hInst, HINSTANCE, LPSTR, INT)
{
   CMain d3dApp;

   InitCommonControls();
   if (FAILED (d3dApp.Create (hInst)))
     return 0;

   return d3dApp.Run();
}