// Main.cpp: implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////

#define STRICT
#include <Windows.h>
#include <commctrl.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <D3DX9.h>

#include "_D3D/DXUtil.h"

#include "_D3D/D3DEnumeration.h"
#include "_D3D/D3DSettings.h"
#include "_D3D/D3DApp.h"
#include "_D3D/D3DFont.h"
#include "_D3D/D3DUtil.h"

#include "resource.h"

#include "model_t.h"
#include "d3dmodel_t.h"
#include "noise.h"
#include "random.h"

#include "Main.h"



//-----------------------------------------------------------------------------
// Defines, constants, and global variables
//-----------------------------------------------------------------------------

#define NOISE_DIMENSION                128
#define NOISE_MIP_LEVELS               1

#define PARAM_NOISE_AMPLITUDE          0
#define PARAM_RING_FREQUENCY           1
#define PARAM_TRUNK_WOBBLE_FREQUENCY   2
#define PARAM_TRUNK_WOBBLE_AMPLITUDE   3
#define NUM_PARAMETERS                 4

#define PALE_BLUE     D3DXVECTOR3 (0.25f, 0.25f, 0.35f)
#define MEDIUM_BLUE   D3DXVECTOR3 (0.10f, 0.10f, 0.30f)
#define DARK_BLUE     D3DXVECTOR3 (0.05f, 0.05f, 0.26f)
#define DARKER_BLUE   D3DXVECTOR3 (0.03f, 0.03f, 0.20f)


static float g_noise[NOISE_DIMENSION][NOISE_DIMENSION][NOISE_DIMENSION];



CMain::WOOD_PARAMETER_SET  g_WoodParameterSets[NUM_SAMPLE_TEXTURES] =
{
	{206.0f/255.0f, 162.0f/255.0f, 117.0f/255.0f, 0.0f, 154.0f/255.0f, 115.0f/255.0f,  75.0f/255.0f, 0.0f},
	{195.0f/255.0f, 162.0f/255.0f, 122.0f/255.0f, 0.0f, 168.0f/255.0f, 125.0f/255.0f,  82.0f/255.0f, 0.0f},
	{120.0f/255.0f, 100.0f/255.0f,  71.0f/255.0f, 0.0f,  80.0f/255.0f,  70.0f/255.0f,  52.0f/255.0f, 0.0f},
	{196.0f/255.0f, 160.0f/255.0f, 116.0f/255.0f, 0.0f, 154.0f/255.0f, 115.0f/255.0f,  77.0f/255.0f, 0.0f},
	{186.0f/255.0f, 153.0f/255.0f, 112.0f/255.0f, 0.0f, 134.0f/255.0f, 104.0f/255.0f,  72.0f/255.0f, 0.0f},
	{192.0f/255.0f, 157.0f/255.0f, 114.0f/255.0f, 0.0f, 127.0f/255.0f,  88.0f/255.0f,  55.0f/255.0f, 0.0f}
};

// Converts a FLOAT to a DWORD for use in SetRenderState() calls
inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

#define NOISE_ONLY_PIXEL_SHADER           0
#define RINGS_ONLY_PIXEL_SHADER           1
#define NOISY_RINGS_PIXEL_SHADER          2
#define NOISY_WOBBLY_RINGS_PIXEL_SHADER   3
#define FULL_WOOD_PIXEL_SHADER            4
#define IVORY_PIXEL_SHADER                5
#define VELVET_PIXEL_SHADER               6
#define MARBLE_PIXEL_SHADER               7
#define GRANITE_PIXEL_SHADER              8
#define GOOCH_PIXEL_SHADER                9
#define STRATA_PIXEL_SHADER               10
#define SATURN_PIXEL_SHADER               11
#define VEINED_PIXEL_SHADER               12
#define NUM_PIXEL_SHADERS                 13



#define GUMBO_BODY_FILE     _T("data/newbody13000.3DS")
#define GUMBO_TUSKS_FILE    _T("data/newtusk.3DS")
#define HLSL_FX				_T("data/HLSL_FX.fxl")

// Sample wood textures
char g_strWoodTextureFiles[NUM_SAMPLE_TEXTURES][32] = { _T("data/Wood1.tga"),
_T("data/Wood2.tga"),
_T("data/Wood3.tga"),
_T("data/Wood4.tga"),
_T("data/Wood5.tga"),
_T("data/Wood6.tga") };




//-----------------------------------------------------------------------------
// Name: CMain()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMain::CMain()
{
	m_strClassName                 = _T("DirectX9 Procedural Wood");
	m_d3dEnumeration.AppUsesDepthBuffer = TRUE;
	m_bShowCursorWhenFullscreen      = TRUE;
	m_bStartFullscreen               = FALSE;
	
	m_dwCreationWidth    = 1024;
	m_dwCreationHeight   = 768;
	
	m_pVertexDeclaration = NULL;
	
	m_pEffect            = NULL;
	m_bEffectSucceeded   = TRUE;
	m_bUsingHLSL         = TRUE;
	
	m_ObjectParameters.m_bUpdatingTextureMatrices = TRUE;
	
	m_bDrawUI            = TRUE;
	
	m_pVolumeNoiseTexture         = NULL;
	m_pWoodBandTexture            = NULL;
	m_pVariableSpecularTexture    = NULL;
	m_pStrataSplineTexture        = NULL;
	m_pSaturnSplineTexture        = NULL;
	m_pMarbleColorSplineTexture   = NULL;
	m_pLogoTexture                = NULL;
	
	for (int i=0; i< NUM_SAMPLE_TEXTURES; i++)
	{
		m_pSampleWoodTexture[i] = NULL;
	}
	
	m_pFont              = new CD3DFont( _T("Arial"), 8, D3DFONT_BOLD );
	m_pBigFont           = new CD3DFont( _T("Arial"), 24, D3DFONT_BOLD );
	m_pImageVB           = NULL;
	m_pLogoVB            = NULL;
	
	m_vecLight_Eye       = D3DXVECTOR4 (10.0f, 10.0f, -0.1f, 1.0f);
	
	m_CurrentParameter   = PARAM_NOISE_AMPLITUDE;
	m_curWoodParameterSet= 0;
	m_curPixelShader = FULL_WOOD_PIXEL_SHADER;
	
	m_ObjectParameters.m_rgbLightWood.r         = g_WoodParameterSets[0].m_rgbLightWood.r;
	m_ObjectParameters.m_rgbLightWood.g         = g_WoodParameterSets[0].m_rgbLightWood.g;
	m_ObjectParameters.m_rgbLightWood.b         = g_WoodParameterSets[0].m_rgbLightWood.b;
	m_ObjectParameters.m_rgbLightWood.a         = 1.0f;   // Don't Care
	m_ObjectParameters.m_rgbDarkWood.r          = g_WoodParameterSets[0].m_rgbDarkWood.r;
	m_ObjectParameters.m_rgbDarkWood.g          = g_WoodParameterSets[0].m_rgbDarkWood.g;
	m_ObjectParameters.m_rgbDarkWood.b          = g_WoodParameterSets[0].m_rgbDarkWood.b; 
	m_ObjectParameters.m_rgbDarkWood.a          = 0.5f;   // Don't Care
	m_ObjectParameters.m_fTrunkWobbleFreq       = 0.3f;   // Amplitude of noise
	m_ObjectParameters.m_fTrunkWobbleAmplitude  = 0.07f;  // Number of wood rings per world-space unit
	m_ObjectParameters.m_fNoiseAmplitude        = 0.03f;  // Amplitude of noise
	m_ObjectParameters.m_fRingFrequency         = 19.0f;  // Number of wood rings per world-space unit
	
	Load3dsNoTex(GUMBO_BODY_FILE,  &m_GumboBody);
	Load3dsNoTex(GUMBO_TUSKS_FILE, &m_GumboTusks);
}


//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Called during initial app startup, this function performs all the
//       permanent initialization.
//-----------------------------------------------------------------------------
HRESULT CMain::OneTimeSceneInit()
{
	// Set cursor to indicate that user can move the object with the mouse
#ifdef _WIN64
	SetClassLongPtr( m_hWnd, GCLP_HCURSOR, (LONG_PTR)LoadCursor( NULL, IDC_SIZEALL ) );
#else
	SetClassLong( m_hWnd, GCL_HCURSOR, HandleToLong( LoadCursor( NULL, IDC_SIZEALL ) ) );
#endif
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Animates the scene
//-----------------------------------------------------------------------------
HRESULT CMain::FrameMove()
{
	return S_OK;
}



void CMain::SetupEffectConstants(void)
{
	D3DXMATRIX  mat;
	
	D3DXMatrixScaling (&m_matWorld, 0.45f, 0.45f, 0.45f);
	
	D3DXMatrixMultiply (&m_matWorld, &m_matWorld, m_ArcBall.GetRotationMatrix());
	D3DXMatrixMultiply (&m_matWorld, &m_matWorld, m_ArcBall.GetTranslationMatrix());
	
	D3DXMatrixMultiply (&m_matWorldView, &m_matWorld, &m_matView);
	D3DXMatrixMultiply (&m_matWorldViewProj, &m_matWorldView, &m_matProj);
	
	D3DXMatrixInverse (&m_matITWorldView, NULL, &m_matWorldView);   
	D3DXMatrixTranspose (&m_matITWorldView, &m_matITWorldView);
	
	if (m_ObjectParameters.m_bUpdatingTextureMatrices)
	{
		D3DXMatrixScaling (&m_ObjectParameters.m_matTex0, 1.1f, 1.0f, 1.08f);
		D3DXMatrixMultiply (&m_ObjectParameters.m_matTex0, &m_ObjectParameters.m_matTex0, &m_matWorld);
		D3DXMatrixScaling (&m_ObjectParameters.m_matTex1, -1.0f, 1.0f, 1.0f);
		D3DXMatrixMultiply (&m_ObjectParameters.m_matTex1, &m_ObjectParameters.m_matTex1, &m_matWorld);
		D3DXMatrixScaling (&m_ObjectParameters.m_matTex2, 1.0f, -1.0f, -0.9f);
		D3DXMatrixMultiply (&m_ObjectParameters.m_matTex2, &m_ObjectParameters.m_matTex2, &m_matWorld);
	}
	
	// Set all the matrices
	m_pEffect->SetMatrix ("matWorldViewProj", &m_matWorldViewProj);
	m_pEffect->SetMatrix ("matWorldView", &m_matWorldView);
	m_pEffect->SetMatrix ("matITWorldView", &m_matITWorldView);
	m_pEffect->SetMatrix ("matWorld", &m_matWorld);
	m_pEffect->SetMatrix ("matTex0", &m_ObjectParameters.m_matTex0);
	m_pEffect->SetMatrix ("matTex1", &m_ObjectParameters.m_matTex1);
	m_pEffect->SetMatrix ("matTex2", &m_ObjectParameters.m_matTex2);
	
	D3DXVECTOR4 woodVertexConstants = D3DXVECTOR4(m_ObjectParameters.m_fTrunkWobbleFreq, 0.5f, 0.0f, 0.0f); // freq, half, X, X
	m_pEffect->SetVector ("vWoodVertexConstants", &woodVertexConstants);
	
	
	//
	// Set up pixel shader constant store
	//
	D3DXVECTOR4 lightWood, darkWood, g_Leye;
	
	lightWood.x = m_ObjectParameters.m_rgbLightWood.r;
	lightWood.y = m_ObjectParameters.m_rgbLightWood.g;
	lightWood.z = m_ObjectParameters.m_rgbLightWood.b;
	lightWood.w = m_ObjectParameters.m_fRingFrequency;
	
	darkWood.x = m_ObjectParameters.m_rgbDarkWood.r;
	darkWood.y = m_ObjectParameters.m_rgbDarkWood.g;
	darkWood.z = m_ObjectParameters.m_rgbDarkWood.b;
	darkWood.w = m_ObjectParameters.m_fNoiseAmplitude;
	
	g_Leye.x = m_vecLight_Eye.x;
	g_Leye.y = m_vecLight_Eye.y;
	g_Leye.z = m_vecLight_Eye.z;
	g_Leye.w = m_ObjectParameters.m_fTrunkWobbleAmplitude;
	
	m_pEffect->SetVector("lightWood", &lightWood);
	m_pEffect->SetVector("darkWood", &darkWood);
	m_pEffect->SetVector("g_Leye", &g_Leye);
}

char *CMain::GetTechniqueName(BOOL bHLSL, DWORD dwShader)
{
	
	// If using High Level Shading Language
	if (bHLSL)
	{
		switch (dwShader)
		{
		default:
		case NOISE_ONLY_PIXEL_SHADER:
			return "technique_hlsl_noise";
		case RINGS_ONLY_PIXEL_SHADER:
			return "technique_hlsl_rings";
		case NOISY_RINGS_PIXEL_SHADER:
			return "technique_hlsl_noisy_rings";
		case NOISY_WOBBLY_RINGS_PIXEL_SHADER:
			return "technique_hlsl_noisy_wobble_rings";
		case FULL_WOOD_PIXEL_SHADER:
			return "technique_hlsl_wood";
		case IVORY_PIXEL_SHADER:
			return "technique_hlsl_ivory";
		case VELVET_PIXEL_SHADER:
			return "technique_hlsl_velvet";
		case MARBLE_PIXEL_SHADER:
			return "technique_hlsl_bluemarble";
		case GRANITE_PIXEL_SHADER:
			return "technique_hlsl_granite";
		case GOOCH_PIXEL_SHADER:
			return "technique_hlsl_gooch";
		case STRATA_PIXEL_SHADER:
			return "technique_hlsl_strata";
		case SATURN_PIXEL_SHADER:
			return "technique_hlsl_saturn";
		case VEINED_PIXEL_SHADER:
			return "technique_hlsl_veinedmarble";
		}
	}
	else // using asm
	{
		switch (dwShader)
		{
		default:
		case NOISE_ONLY_PIXEL_SHADER:
			return "technique_asm_noise";
		case RINGS_ONLY_PIXEL_SHADER:
			return "technique_asm_rings";
		case NOISY_RINGS_PIXEL_SHADER:
			return "technique_asm_noisy_rings";
		case NOISY_WOBBLY_RINGS_PIXEL_SHADER:
			return "technique_asm_noisy_wobble_rings";
		case FULL_WOOD_PIXEL_SHADER:
			return "technique_asm_wood";
		case IVORY_PIXEL_SHADER:
			return "technique_asm_ivory";
		case VELVET_PIXEL_SHADER:
			return "technique_hlsl_velvet";
		case MARBLE_PIXEL_SHADER:
			return "technique_hlsl_bluemarble";
		case GRANITE_PIXEL_SHADER:
			return "technique_hlsl_granite";
		case GOOCH_PIXEL_SHADER:
			return "technique_hlsl_gooch";
		case STRATA_PIXEL_SHADER:
			return "technique_hlsl_strata";
		case SATURN_PIXEL_SHADER:
			return "technique_hlsl_saturn";
		case VEINED_PIXEL_SHADER:
			return "technique_hlsl_veinedmarble";
		}   
	}
}


//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMain::Render()
{
	UINT iPass, cPasses;
	
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFFE0E0E0, 1.0f, 0L );
	
	if (FAILED (m_pd3dDevice->BeginScene()))
	{
		return S_OK; // Don't return a "fatal" error
	}
	
	m_pd3dDevice->SetVertexDeclaration (m_pVertexDeclaration);
	
	SetupEffectConstants();
	
	m_pEffect->SetTechnique(m_pEffect->GetTechniqueByName(GetTechniqueName(m_bUsingHLSL, m_curPixelShader)));
	
	m_pEffect->SetTexture("tVolumeNoise",      m_pVolumeNoiseTexture);
	m_pEffect->SetTexture("tWoodPulseTrain",   m_pWoodBandTexture);
	m_pEffect->SetTexture("tVariableSpecular", m_pVariableSpecularTexture);
	m_pEffect->SetTexture("tMarbleSpline",     m_pMarbleColorSplineTexture);
	m_pEffect->SetTexture("tStrataSpline",     m_pStrataSplineTexture);
	m_pEffect->SetTexture("tSaturnSpline",     m_pSaturnSplineTexture);
	
	m_pEffect->Begin(&cPasses, 0);
	for (iPass = 0; iPass < cPasses; iPass++)
	{
		m_pEffect->Pass(iPass);
		d3dRenderModelNoMat (&m_GumboBody,  m_pd3dDevice);
		d3dRenderModelNoMat (&m_GumboTusks,  m_pd3dDevice);
	}
	m_pEffect->End();
	
	if (m_bDrawUI)
	{
		if (m_curPixelShader <= FULL_WOOD_PIXEL_SHADER)
		{
			//
			// Draw wood sample overlay quad
			//
			m_pd3dDevice->SetTexture (0, m_pSampleWoodTexture[m_curWoodParameterSet]);
			m_pd3dDevice->SetTexture (1, NULL);
			m_pd3dDevice->SetTexture (2, NULL);
			m_pd3dDevice->SetTexture (3, NULL);
			m_pd3dDevice->SetTexture (4, NULL);
			m_pd3dDevice->SetTexture (5, NULL);
			
			m_pd3dDevice->SetVertexShader (NULL);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_TEXCOORDINDEX, 0);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
			
			
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
			m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1);
			
			// Disable later stages to be safe
			for (int i=1; i<8; i++)
			{
				m_pd3dDevice->SetTextureStageState (i, D3DTSS_COLOROP,   D3DTOP_DISABLE);
				m_pd3dDevice->SetTextureStageState (i, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);
			}
			
			m_pd3dDevice->SetRenderState (D3DRS_ZENABLE, FALSE);
			
			// Draw overlay texture
			m_pd3dDevice->SetStreamSource (0, m_pImageVB, 0, sizeof(OVERLAY_VERTEX));
			m_pd3dDevice->SetFVF (OVERLAY_VERTEX::FVF);
			m_pd3dDevice->DrawPrimitive (D3DPT_TRIANGLESTRIP, 0, 2);
			
			m_pd3dDevice->SetRenderState (D3DRS_ZENABLE, TRUE);
		}
		
		//
		// Output statistics and UI
		//
		char strBuff[128];
		float lineNum = 0;
		m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), m_strFrameStats);
		lineNum+=11.0f;
		m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), m_strDeviceStats);
		lineNum+=11.0f;
		
		sprintf (strBuff, "Left Drag to rotate object");
		m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		lineNum+=11.0f;
		sprintf (strBuff, "Right Drag to translate object in plane of screen");
		m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		lineNum+=11.0f;
		sprintf (strBuff, "Middle Drag to translate object perpendicular to screen");
		m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		lineNum+=11.0f;
		
		sprintf (strBuff, "Noise Amplitude %f", m_ObjectParameters.m_fNoiseAmplitude);
		if (m_CurrentParameter == PARAM_NOISE_AMPLITUDE)
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,255,0,0), strBuff);
		}
		else
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		}
		lineNum+=11.0f;
		
		sprintf (strBuff, "Ring Frequency %f", m_ObjectParameters.m_fRingFrequency);
		if (m_CurrentParameter == PARAM_RING_FREQUENCY)
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,255,0,0), strBuff);
		}
		else
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		}
		lineNum+=11.0f;
		
		
		sprintf (strBuff, "Trunk Wobble Frequency %f", m_ObjectParameters.m_fTrunkWobbleFreq);
		if (m_CurrentParameter == PARAM_TRUNK_WOBBLE_FREQUENCY)
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,255,0,0), strBuff);
		}
		else
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		}
		lineNum+=11.0f;
		
		sprintf (strBuff, "Trunk Wobble Amplitude %f", m_ObjectParameters.m_fTrunkWobbleAmplitude);
		if (m_CurrentParameter == PARAM_TRUNK_WOBBLE_AMPLITUDE)
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,255,0,0), strBuff);
		}
		else
		{
			m_pFont->DrawText (2, lineNum, D3DCOLOR_ARGB (255,0,0,0), strBuff);
		}
		lineNum+=11.0f;
		
		if (m_curPixelShader <= FULL_WOOD_PIXEL_SHADER)
		{
			// UI Text on wood overlay
			sprintf (strBuff, "Wood %d", m_curWoodParameterSet+1);
			m_pFont->DrawText (m_d3dpp.BackBufferWidth-132.0f, 25.0f, D3DCOLOR_ARGB (255,255,255,255), strBuff);
		}
		
} // m_bDrawUI
else
{
	if (m_bUsingHLSL)
	{
		m_pBigFont->DrawText (2, 2, D3DCOLOR_ARGB (255,0,0,150), _T("High Level Shading Language"));
	}
	else
	{
		m_pBigFont->DrawText (2, 2, D3DCOLOR_ARGB (255,0,0,150), _T("Assembly"));
	}
}

//
// Draw Logo overlay quad
//
m_pd3dDevice->SetTexture (0, m_pLogoTexture);
m_pd3dDevice->SetTexture (1, NULL);
m_pd3dDevice->SetTexture (2, NULL);
m_pd3dDevice->SetTexture (3, NULL);
m_pd3dDevice->SetTexture (4, NULL);
m_pd3dDevice->SetTexture (5, NULL);

m_pd3dDevice->SetVertexShader (NULL);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_TEXCOORDINDEX, 0);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);

m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
m_pd3dDevice->SetTextureStageState (0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1);

// Disable later stages to be safe
for (int i=1; i<8; i++)
{
	m_pd3dDevice->SetTextureStageState (i, D3DTSS_COLOROP,   D3DTOP_DISABLE);
	m_pd3dDevice->SetTextureStageState (i, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);
}

m_pd3dDevice->SetRenderState (D3DRS_ZENABLE, FALSE);
m_pd3dDevice->SetRenderState (D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
m_pd3dDevice->SetRenderState (D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
m_pd3dDevice->SetRenderState (D3DRS_ALPHABLENDENABLE, TRUE);

// Draw logo
m_pd3dDevice->SetStreamSource (0, m_pLogoVB, 0, sizeof(OVERLAY_VERTEX));
m_pd3dDevice->SetFVF (OVERLAY_VERTEX::FVF);
m_pd3dDevice->DrawPrimitive (D3DPT_TRIANGLESTRIP, 0, 2);

m_pd3dDevice->SetRenderState (D3DRS_ALPHABLENDENABLE, FALSE);
m_pd3dDevice->SetRenderState (D3DRS_ZENABLE, TRUE);

m_pd3dDevice->EndScene();

return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitWhiteNoiseArray()
// Desc: Initializes a user memory array of white noise which will be used
//       during noise texture generation
//-----------------------------------------------------------------------------
void InitWhiteNoiseArray (void)
{
	int i,j,k;
	
	for (i=0; i<NOISE_DIMENSION; i++)
	{
		for (j=0; j<NOISE_DIMENSION; j++)
		{
			for (k=0; k<NOISE_DIMENSION; k++)
			{
				g_noise[i][j][k] = (float) drand48();
			}
		}
	}
}

//-----------------------------------------------------------------------------
// Name: lerpNoise()
// Desc: Helper function which does wrapped interpolation of noise.  This is
//       necessary for generating tilable noise
//-----------------------------------------------------------------------------
float lerpNoise(float x, float y,float z, int wrapX, int wrapY, int wrapZ)
{
	int ix,iy,iz,ixd,iyd,izd;  // integer parts of index into texture array
	float rx,ry,rz; 		      // fractional part of xyz  
	float accum;			      // value returned
	
	ix=((int)x);
	iy=((int)y);
	iz=((int)z);
	
	rx=x-(float)ix;
	ry=y-(float)iy;
	rz=z-(float)iz;
	ix=ix&(wrapX-1);
	iy=iy&(wrapY-1);
	iz=iz&(wrapZ-1);
	ixd=(ix+1)&(wrapX-1);
	iyd=(iy+1)&(wrapY-1);
	izd=(iz+1)&(wrapZ-1);
	
	accum=0;
	accum+=rx*ry*rz*g_noise[izd][iyd][ixd];
	accum+=(1-rx)*ry*rz*g_noise[izd][iyd][ix];
	accum+=rx*(1-ry)*rz*g_noise[izd][iy][ixd];
	accum+=(1-rx)*(1-ry)*rz*g_noise[izd][iy][ix];
	
	accum+=rx*ry*(1-rz)*g_noise[iz][iyd][ixd];
	accum+=(1-rx)*ry*(1-rz)*g_noise[iz][iyd][ix];
	accum+=rx*(1-ry)*(1-rz)*g_noise[iz][iy][ixd];
	accum+=(1-rx)*(1-ry)*(1-rz)*g_noise[iz][iy][ix];
	
	return accum;
}


//-----------------------------------------------------------------------------
// Name: turbulence()
// Desc: 
//-----------------------------------------------------------------------------
float turbulence(float x, float y, float z, int wrapX, int wrapY, int wrapZ, float maxScale)
{
	float t=0;
	float scale=maxScale;
	
	
	while(scale>=1)
	{
		t+=lerpNoise(x/scale, y/scale, z/scale, wrapX/(int)scale, wrapY/(int)scale, wrapZ/(int)scale) * 128*(scale/maxScale);
		scale/=2.0f;
	}
	
	return(t);
}

// return 0 if x < edge, otherwise 1
//
//      +------
//      |
//      |
// -----+
//     edge
//
float step (float edge, float x)
{
	if (x < edge)
	{
		return 0.0f;
	}
	else
	{
		return 1.0f;
	}
}

//             *******
//            *
//           *  <-- Hermite spline interpolation between e0 and e1
//          *
// ********+---+------
//         e0  e1
//
float smoothstep (float edge0, float edge1, float x)
{
	if (x < edge0)
	{
		return 0.0f;
	}
	
	if (x > edge1)
	{
		return 1.0f;
	}
	
	float fX = (x-edge0) / (edge1-edge0);
	
	return (-2.0f*fX*fX*fX + 3*fX*fX);
}


// A 1-D pulse pattern:  return 1 if edge0 <= x <= edge1, otherwise 0
float pulse (float edge0, float edge1, float x)
{
	return step(edge0, x) - step(edge1, x);
}

float smoothpulse (float e0, float e1, float e2, float e3, float x)
{
	return smoothstep(e0, e1, x) - smoothstep(e2, e3, x);
}


//-----------------------------------------------------------------------------
// Name: turbulanceFill()
// Desc: Passed to D3DXFillVolumeTexture to fill in noise volume texture
//-----------------------------------------------------------------------------
void WINAPI turbulanceFill (D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData)
{
	float turb = turbulence(pTexCoord->x*NOISE_DIMENSION, pTexCoord->y*NOISE_DIMENSION, pTexCoord->z*NOISE_DIMENSION, NOISE_DIMENSION, NOISE_DIMENSION, NOISE_DIMENSION, NOISE_DIMENSION/4) / 256.0f; // Get turbulence from tilable noise
	
	turb = max(0.0f, min(1.0f, turb));    // Clamp
	
	*pOut = D3DXVECTOR4(turb, turb, turb, turb);
}


//-----------------------------------------------------------------------------
// Name: vfBm()
// Desc: Vector fractional Brownian motion, based upon routine on page 253
//       in Advanced RenderMan by Apodaca and Gritz.  As noted in that text,
//       this is a relative of turbulence, except it is signed.
//       The amplitude of the noise is 1 as it is stored in the texture.
//       If a lower amplitude is desired, samples from the noise map should
//       be scaled down in the shader to preserve precision.
//-----------------------------------------------------------------------------
float vfBm (const D3DXVECTOR3* p, int octaves, FLOAT lacunarity, FLOAT gain)
{
	float sum = 0;
	float amp = 1.0f;
	D3DXVECTOR3 pp = *p;
	float temp[3];
	
	// Accumulate some number of octaves of fractional Brownian motion
	for (int i=0; i<octaves; i++)
	{
		temp[0] = pp.x;
		temp[1] = pp.y;
		temp[2] = pp.z;
		sum += amp * noise3(temp);
		amp *= gain;
		pp  *= lacunarity;
	}
	
	return sum;
}

//-----------------------------------------------------------------------------
// Name: vfBmFill()
// Desc: Passed to D3DXFillVolumeTexture to fill in noise volume texture
//-----------------------------------------------------------------------------
void WINAPI vfBmFill (D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData)
{
	float vfBmNoise = vfBm (pTexCoord, 2, 4.0f, 0.5f)/2.0f + 0.5f;
	
	*pOut = D3DXVECTOR4(vfBmNoise, vfBmNoise, vfBmNoise, vfBmNoise);
}

//-----------------------------------------------------------------------------
// Name: ColorCubeFill()
// Desc: Can be passed to D3DXFillVolumeTexture.  Useful for debugging
//-----------------------------------------------------------------------------

void WINAPI ColorCubeFill (D3DXVECTOR4* pOut, const D3DXVECTOR3* pTexCoord, const D3DXVECTOR3* pTexelSize, LPVOID pData)
{
	*pOut = D3DXVECTOR4(pTexCoord->x, pTexCoord->y, pTexCoord->z, 0.0f);
}

//-----------------------------------------------------------------------------
// Name: WoodBandPulseFill()
// Desc: Passed to D3DXFillTexture to fill in function texture
//-----------------------------------------------------------------------------
void WINAPI WoodBandPulseFill (D3DXVECTOR4 *pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	float fWoodBlendScalar  = smoothpulse (0.1f, 0.55f, 0.7f, 0.95f, pTexCoord->y);
	float fGloss            = 0.25f*(1.0f-smoothpulse (0.1f, 0.55f, 0.7f, 0.95f, pTexCoord->y))+0.5f;
	float fSpecularExponent = 1-smoothpulse (0.1f, 0.55f, 0.7f, 0.95f, pTexCoord->y);
	
	*pOut = D3DXVECTOR4(fWoodBlendScalar, fGloss, fSpecularExponent, 0.0f);
}


//-----------------------------------------------------------------------------
// Name: VariableSpecularFill()
// Desc: Passed to D3DXFillTexture to fill in function texture
//-----------------------------------------------------------------------------
void WINAPI VariableSpecularFill (D3DXVECTOR4 *pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	float result = powf(pTexCoord->x, pTexCoord->y*50.0f + 50.f);
	
	*pOut = D3DXVECTOR4(result, result, result, result);
}

#define NUM_STRATA_KNOTS 34

D3DXVECTOR4 g_StrataKnots[NUM_STRATA_KNOTS] = { D3DXVECTOR4( 166.0f/255.0f, 131.0f/255.0f,  70.0f/255.0f, 1.0f),
D3DXVECTOR4( 166.0f/255.0f, 131.0f/255.0f,  70.0f/255.0f, 1.0f),
D3DXVECTOR4( 204.0f/255.0f, 178.0f/255.0f, 127.0f/255.0f, 1.0f),
D3DXVECTOR4( 184.0f/255.0f, 153.0f/255.0f,  97.0f/255.0f, 1.0f), 
D3DXVECTOR4( 140.0f/255.0f, 114.0f/255.0f,  51.0f/255.0f, 1.0f),  
D3DXVECTOR4( 159.0f/255.0f, 123.0f/255.0f,  60.0f/255.0f, 1.0f), 
D3DXVECTOR4( 204.0f/255.0f, 178.0f/255.0f, 127.0f/255.0f, 1.0f), 
D3DXVECTOR4( 230.0f/255.0f, 180.0f/255.0f,  80.0f/255.0f, 1.0f), 
D3DXVECTOR4( 192.0f/255.0f, 164.0f/255.0f, 110.0f/255.0f, 1.0f), 
D3DXVECTOR4( 172.0f/255.0f, 139.0f/255.0f,  80.0f/255.0f, 1.0f), 
D3DXVECTOR4( 102.0f/255.0f,  76.0f/255.0f,  25.0f/255.0f, 1.0f),   
D3DXVECTOR4( 166.0f/255.0f, 131.0f/255.0f,  70.0f/255.0f, 1.0f), 
D3DXVECTOR4( 201.0f/255.0f, 175.0f/255.0f, 124.0f/255.0f, 1.0f), 
D3DXVECTOR4( 181.0f/255.0f, 150.0f/255.0f,  94.0f/255.0f, 1.0f), 
D3DXVECTOR4( 161.0f/255.0f, 125.0f/255.0f,  64.0f/255.0f, 1.0f),  
D3DXVECTOR4( 177.0f/255.0f, 145.0f/255.0f,  87.0f/255.0f, 1.0f), 
D3DXVECTOR4( 170.0f/255.0f, 136.0f/255.0f,  77.0f/255.0f, 1.0f),  
D3DXVECTOR4( 197.0f/255.0f, 170.0f/255.0f, 117.0f/255.0f, 1.0f), 
D3DXVECTOR4( 180.0f/255.0f, 100.0f/255.0f,  50.0f/255.0f, 1.0f),  
D3DXVECTOR4( 175.0f/255.0f, 142.0f/255.0f,  84.0f/255.0f, 1.0f), 
D3DXVECTOR4( 197.0f/255.0f, 170.0f/255.0f, 117.0f/255.0f, 1.0f), 
D3DXVECTOR4( 177.0f/255.0f, 145.0f/255.0f,  87.0f/255.0f, 1.0f), 
D3DXVECTOR4( 170.0f/255.0f, 136.0f/255.0f,  77.0f/255.0f, 1.0f),  
D3DXVECTOR4( 186.0f/255.0f, 156.0f/255.0f, 100.0f/255.0f, 1.0f), 
D3DXVECTOR4( 166.0f/255.0f, 131.0f/255.0f,  70.0f/255.0f, 1.0f),  
D3DXVECTOR4( 188.0f/255.0f, 159.0f/255.0f, 104.0f/255.0f, 1.0f), 
D3DXVECTOR4( 168.0f/255.0f, 134.0f/255.0f,  74.0f/255.0f, 1.0f),  
D3DXVECTOR4( 159.0f/255.0f, 123.0f/255.0f,  60.0f/255.0f, 1.0f), 
D3DXVECTOR4( 195.0f/255.0f, 167.0f/255.0f, 114.0f/255.0f, 1.0f), 
D3DXVECTOR4( 175.0f/255.0f, 142.0f/255.0f,  84.0f/255.0f, 1.0f), 
D3DXVECTOR4( 161.0f/255.0f, 125.0f/255.0f,  64.0f/255.0f, 1.0f),  
D3DXVECTOR4( 197.0f/255.0f, 170.0f/255.0f, 117.0f/255.0f, 1.0f), 
D3DXVECTOR4( 177.0f/255.0f, 145.0f/255.0f,  87.0f/255.0f, 1.0f),  
D3DXVECTOR4( 177.0f/255.0f, 145.0f/255.0f,  87.0f/255.0f, 1.0f)};


//-------------------------------------------------------------------------------
// Name: StrataSplineFill()
// Desc: Passed to D3DXFillTexture to fill in function texture for strata shader
//-------------------------------------------------------------------------------
void WINAPI StrataSplineFill (D3DXVECTOR4 *pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	
	float bin = floorf (pTexCoord->x * (NUM_STRATA_KNOTS-1));
	float blendFactor = (pTexCoord->x * (NUM_STRATA_KNOTS-1)) - bin;
	
	D3DXVECTOR4 lowColor  = g_StrataKnots[(int)bin];
	D3DXVECTOR4 highColor = g_StrataKnots[((int)bin)+1];
	
	*pOut = blendFactor * lowColor + (1-blendFactor) * highColor;
}

#define NUM_SATURN_KNOTS 11

D3DXVECTOR4 g_SaturnKnots[NUM_SATURN_KNOTS] = { D3DXVECTOR4 (0.730f, 0.598f, 0.266f, 0.0f),
D3DXVECTOR4 (0.730f, 0.598f, 0.266f, 0.0f),
D3DXVECTOR4 (1.000f, 0.630f, 0.332f, 0.0f),
D3DXVECTOR4 (0.598f, 0.531f, 0.266f, 0.0f),
D3DXVECTOR4 (0.863f, 0.664f, 0.332f, 0.0f),
D3DXVECTOR4 (0.797f, 0.598f, 0.332f, 0.0f),
D3DXVECTOR4 (0.730f, 0.598f, 0.266f, 0.0f),
D3DXVECTOR4 (0.461f, 0.461f, 0.461f, 0.0f),
D3DXVECTOR4 (0.332f, 0.199f, 0.266f, 0.0f),
D3DXVECTOR4 (0.332f, 0.199f, 0.266f, 0.0f),
D3DXVECTOR4 (0.332f, 0.199f, 0.266f, 0.0f)};

//-------------------------------------------------------------------------------
// Name: SaturnSplineFill()
// Desc: Passed to D3DXFillTexture to fill in function texture for Saturn shader
//-------------------------------------------------------------------------------
void WINAPI SaturnSplineFill (D3DXVECTOR4 *pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	float bin = floorf (pTexCoord->x * (NUM_SATURN_KNOTS-1));
	float blendFactor = (pTexCoord->x * (NUM_SATURN_KNOTS-1)) - bin;
	
	D3DXVECTOR4 lowColor  = g_SaturnKnots[(int)bin];
	D3DXVECTOR4 highColor = g_SaturnKnots[((int)bin)+1];
	
	*pOut = blendFactor * lowColor + (1-blendFactor) * highColor;
}


//-----------------------------------------------------------------------------
// Name: InitOverlayImages()
// Desc: 
//-----------------------------------------------------------------------------
HRESULT CMain::InitOverlayImages()
{
	if( FAILED( m_pd3dDevice->CreateVertexBuffer (4*sizeof(OVERLAY_VERTEX), D3DUSAGE_WRITEONLY, OVERLAY_VERTEX::FVF, D3DPOOL_MANAGED, &m_pImageVB, NULL)))
	{
		return E_FAIL;
	}
	
	if( FAILED( m_pd3dDevice->CreateVertexBuffer (4*sizeof(OVERLAY_VERTEX), D3DUSAGE_WRITEONLY, OVERLAY_VERTEX::FVF, D3DPOOL_MANAGED, &m_pLogoVB, NULL)))
	{
		return E_FAIL;
	}
	
	ComputeOverlayPlacement(m_d3dpp.BackBufferWidth, m_d3dpp.BackBufferHeight);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitVariableSpecularTexture()
// Desc: Creates 1D variable specular texture
//-----------------------------------------------------------------------------
HRESULT CMain::InitVariableSpecularTexture()
{
	HRESULT hr;
	
	SAFE_RELEASE (m_pVariableSpecularTexture);
	
	if (FAILED (hr = D3DXCreateTexture (m_pd3dDevice, 128, 128, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_pVariableSpecularTexture)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFillTexture (m_pVariableSpecularTexture, VariableSpecularFill, NULL)))
	{
		return hr;
	}
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitSplineTextures()
// Desc: Creates 1D color spline texture
//-----------------------------------------------------------------------------
HRESULT CMain::InitSplineTextures()
{
	HRESULT hr;
	
	D3DXVECTOR3 splineColors[5] = {PALE_BLUE, MEDIUM_BLUE, DARK_BLUE, PALE_BLUE, DARKER_BLUE}; 
	
	SAFE_RELEASE (m_pMarbleColorSplineTexture);
	
	if( FAILED( hr = D3DXCreateTextureFromFileEx (m_pd3dDevice, _T("data/BlueSpline.tga"), D3DX_DEFAULT, D3DX_DEFAULT,
		1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT,
		0xFF000000, NULL, NULL, &m_pMarbleColorSplineTexture)))
	{
		return hr;
	}
	
	SAFE_RELEASE (m_pStrataSplineTexture);
	
	if (FAILED (hr = D3DXCreateTexture (m_pd3dDevice, 512, 1, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_pStrataSplineTexture)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFillTexture (m_pStrataSplineTexture, StrataSplineFill, NULL)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFilterTexture (m_pStrataSplineTexture, NULL, 0, D3DX_DEFAULT)))
	{
		return hr;
	}
	
	
	SAFE_RELEASE (m_pSaturnSplineTexture);
	
	if (FAILED (hr = D3DXCreateTexture (m_pd3dDevice, 512, 1, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_pSaturnSplineTexture)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFillTexture (m_pSaturnSplineTexture, SaturnSplineFill, NULL)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFilterTexture (m_pSaturnSplineTexture, NULL, 0, D3DX_DEFAULT)))
	{
		return hr;
	}
	
	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitLogoTexture()
// Desc: Creates 2D logo texture
//-----------------------------------------------------------------------------
HRESULT CMain::InitLogoTexture()
{
	SAFE_RELEASE (m_pLogoTexture);
	
	if( FAILED( D3DXCreateTextureFromFileEx (m_pd3dDevice, _T("data/9700.tga"), D3DX_DEFAULT, D3DX_DEFAULT,
		1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT,
		0xFF000000, NULL, NULL, &m_pLogoTexture)))
	{
		return E_FAIL;
	}
	
	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: Init1DWoodBandTexture()
// Desc: Creates 1D wood band blend texture
//-----------------------------------------------------------------------------
HRESULT CMain::Init1DWoodBandTexture()
{
	HRESULT hr;
	
	SAFE_RELEASE (m_pWoodBandTexture);
	
	if (FAILED (hr = D3DXCreateTexture (m_pd3dDevice, 1, 128, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED , &m_pWoodBandTexture)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFillTexture (m_pWoodBandTexture, WoodBandPulseFill, NULL)))
	{
		return hr;
	}
	
	return S_OK;
}




void CMain::ComputeOverlayPlacement (int width, int height)
{
	float left   = width  - 138.0f;
	float bottom = 20.0f;
	
	OVERLAY_VERTEX* v;
	m_pImageVB->Lock (0, 0, (void**)&v, 0);
	
	v[0].x = left;
	v[0].y = bottom + 128.0f;
	v[0].z = 0.5f;
	v[0].rhw = 1.0f;
	
	v[1].x = left;
	v[1].y = bottom;
	v[1].z = 0.5f;
	v[1].rhw = 1.0f;
	
	v[2].x = left + 128.0f;
	v[2].y = bottom + 128.0f;
	v[2].z = 0.5f;
	v[2].rhw = 1.0f;
	
	v[3].x = left + 128.0f;
	v[3].y = bottom;
	v[3].z = 0.5f;
	v[3].rhw = 1.0f;
	
	float epsilonWidth  = 0.5f/128.0f;
	float epsilonHeight = 0.5f/128.0f;
	
	v[0].tu = 0.0f+epsilonWidth;  v[0].tv = 1.0f+epsilonHeight;
	v[1].tu = 0.0f+epsilonWidth;  v[1].tv = 0.0f+epsilonHeight;
	v[2].tu = 1.0f+epsilonWidth;  v[2].tv = 1.0f+epsilonHeight;
	v[3].tu = 1.0f+epsilonWidth;  v[3].tv = 0.0f+epsilonHeight;
	
	m_pImageVB->Unlock();
	
	
	
	left   = 6.0f;
	bottom = height - 70.0f;
	
	m_pLogoVB->Lock (0, 0, (void**)&v, 0);
	
	v[0].x = left;
	v[0].y = bottom + 64.0f;
	v[0].z = 0.5f;
	v[0].rhw = 1.0f;
	
	v[1].x = left;
	v[1].y = bottom;
	v[1].z = 0.5f;
	v[1].rhw = 1.0f;
	
	v[2].x = left + 512.0f;
	v[2].y = bottom + 64.0f;
	v[2].z = 0.5f;
	v[2].rhw = 1.0f;
	
	v[3].x = left + 512.0f;
	v[3].y = bottom;
	v[3].z = 0.5f;
	v[3].rhw = 1.0f;
	
	epsilonWidth  = 0.5f/512.0f;
	epsilonHeight = 0.5f/64.0f;
	
	v[0].tu = 0.0f+epsilonWidth;    v[0].tv = 1.0f+epsilonHeight;
	v[1].tu = 0.0f+epsilonWidth;    v[1].tv = 0.0f+epsilonHeight;
	v[2].tu = 1.0f+epsilonWidth;    v[2].tv = 1.0f+epsilonHeight;
	v[3].tu = 1.0f+epsilonWidth;    v[3].tv = 0.0f+epsilonHeight;
	
	m_pLogoVB->Unlock();
	
	
}

//-----------------------------------------------------------------------------
// Name: InitSampleWoodTextures()
// Desc: Loads wood textures from disk
//-----------------------------------------------------------------------------
HRESULT CMain::InitSampleWoodTextures()
{
	HRESULT hr;
	int i;
	
	for (i=0; i< NUM_SAMPLE_TEXTURES; i++)
	{
		SAFE_RELEASE (m_pSampleWoodTexture[i]);
		
		if (FAILED (hr = D3DXCreateTextureFromFile(m_pd3dDevice, g_strWoodTextureFiles[i], &m_pSampleWoodTexture[i])))
		{
			return hr;
		}
	}
	
	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InitNoiseTexture()
// Desc: Creates Noise texture using Perlin noise
//-----------------------------------------------------------------------------
HRESULT CMain::InitNoiseTexture()
{
	HRESULT hr;
	
	InitWhiteNoiseArray();
	
	SAFE_RELEASE (m_pVolumeNoiseTexture);
	
	if (FAILED (hr = D3DXCreateVolumeTexture (m_pd3dDevice, NOISE_DIMENSION, NOISE_DIMENSION,
		NOISE_DIMENSION, NOISE_MIP_LEVELS, 0,
		D3DFMT_L8, D3DPOOL_MANAGED , &m_pVolumeNoiseTexture)))
	{
		return hr;
	}
	
	if (FAILED (hr = D3DXFillVolumeTexture (m_pVolumeNoiseTexture, turbulanceFill, NULL)))
	{
		return hr;
	}
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMain::InitDeviceObjects()
{
	m_pFont->InitDeviceObjects( m_pd3dDevice );
	m_pBigFont->InitDeviceObjects( m_pd3dDevice );
	
	SetMenuStates();
	
	D3DVERTEXELEMENT9 decl[] =
	{
		{ 0,  0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
		{ 0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0 },
		D3DDECL_END()
	};
	
	// Initialize vertex declaration
	if (FAILED (m_pd3dDevice->CreateVertexDeclaration (decl, &m_pVertexDeclaration)))
	{
		return E_FAIL;
	}
	
	// Create and fill the volume noise texture
	if (FAILED (InitNoiseTexture()))
	{
		return E_FAIL;
	}
	
	// Create and fill the variable specular
	if (FAILED (InitVariableSpecularTexture()))
	{
		return E_FAIL;
	}
	
	// Create and fill the variable specular
	if (FAILED (InitSplineTextures()))
	{
		return E_FAIL;
	}
	
	// Create and fill the logo specular
	if (FAILED( InitLogoTexture()))
	{
		return E_FAIL;
	}
	
	// Create and fill the pulse train texture
	if (FAILED( Init1DWoodBandTexture()))
	{
		return E_FAIL;
	}
	
	// Create and fill the various example wood scans
	if (FAILED( InitSampleWoodTextures()))
	{
		return E_FAIL;
	}
	
	// Create and fill the volume noise texture
	if (FAILED( InitOverlayImages()))
	{
		return E_FAIL;
	}
	
	d3dInitializeModel(&m_GumboBody, m_pd3dDevice);
	d3dInitializeModel(&m_GumboTusks, m_pd3dDevice);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Initialize scene objects
//-----------------------------------------------------------------------------
HRESULT CMain::RestoreDeviceObjects()
{
	HRESULT hr;
	
	m_pFont->RestoreDeviceObjects();
	m_pBigFont->RestoreDeviceObjects();
	
	m_pd3dDevice->SetRenderState (D3DRS_ZENABLE, TRUE);
	
	// Get the aspect ratio
	FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
	
	// Set projection matrix
	D3DXMatrixPerspectiveFovLH (&m_matProj, D3DX_PI/4, fAspect, 0.1f, 25.0f);
	m_pd3dDevice->SetTransform (D3DTS_PROJECTION, &m_matProj);
	
	D3DXVECTOR3 vEyePt    = D3DXVECTOR3 (0.0f, 0.0f, -3.0f);
	D3DXVECTOR3 vLookatPt = D3DXVECTOR3 (0.0f, 0.0f, 0.0f);
	D3DXVECTOR3 vUpVec    = D3DXVECTOR3 (0.0f, 1.0f, 0.0f);
	D3DXMatrixLookAtLH (&m_matView, &vEyePt, &vLookatPt, &vUpVec);
	m_pd3dDevice->SetTransform (D3DTS_VIEW, &m_matView);
	
	FLOAT det;
	D3DXMatrixInverse (&m_matInvView, &det, &m_matView);
	
	// Set the ArcBall parameters
	m_ArcBall.SetWindow (m_d3dsdBackBuffer.Width, m_d3dsdBackBuffer.Height, 1.0f);
	m_ArcBall.SetRadius (1.0f);
	
	LPD3DXBUFFER pBufferErrors = NULL;
	hr = D3DXCreateEffectFromFile(m_pd3dDevice, HLSL_FX, NULL, NULL, 0, NULL, &m_pEffect, &pBufferErrors );
	if (FAILED (hr))
		return hr;
	
	ComputeOverlayPlacement(m_d3dpp.BackBufferWidth, m_d3dpp.BackBufferHeight);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc:
//-----------------------------------------------------------------------------
HRESULT CMain::InvalidateDeviceObjects()
{
	m_pFont->InvalidateDeviceObjects();
	m_pBigFont->InvalidateDeviceObjects();
	
	SAFE_RELEASE(m_pEffect);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMain::DeleteDeviceObjects()
{
	SAFE_RELEASE (m_pVolumeNoiseTexture);
	SAFE_RELEASE (m_pWoodBandTexture);
	SAFE_RELEASE (m_pVariableSpecularTexture);
	SAFE_RELEASE (m_pStrataSplineTexture);
	SAFE_RELEASE (m_pSaturnSplineTexture);
	SAFE_RELEASE (m_pMarbleColorSplineTexture);
	SAFE_RELEASE (m_pLogoTexture);
	
	for (int i=0; i< NUM_SAMPLE_TEXTURES; i++)
	{
		SAFE_RELEASE (m_pSampleWoodTexture[i]);
	}
	
	m_pFont->DeleteDeviceObjects();
	m_pBigFont->DeleteDeviceObjects();
	
	SAFE_RELEASE (m_pImageVB);
	SAFE_RELEASE (m_pLogoVB);
	
	d3dFreeModel (&m_GumboBody);
	d3dFreeModel (&m_GumboTusks);
	
	SAFE_RELEASE (m_pVertexDeclaration);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMain::FinalCleanup()
{
	SAFE_DELETE (m_pFont);
	SAFE_DELETE (m_pBigFont);
	
	FreeModel (&m_GumboBody);
	FreeModel (&m_GumboTusks);
	
	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device intialization, this code checks the device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMain::ConfirmDevice (D3DCAPS9* pCaps, DWORD dwBehavior, D3DFORMAT Format)
{
	
	// Device must support ps_2_0...
	if( pCaps->PixelShaderVersion >= D3DPS_VERSION(2,0) )
	{
		// Device must support volume texture of sufficient resolution...
		if (pCaps->MaxVolumeExtent >= 128)
		{
			return S_OK;
		}
	}
	
	return E_FAIL;
}


//-----------------------------------------------------------------------------
// Name: SetMenuStates()
// Desc:
//-----------------------------------------------------------------------------
void CMain::SetMenuStates()
{
	HMENU hMenu = GetMenu( m_hWnd );
	
	CheckMenuItem (hMenu, ID_SHADER_NOISE, (m_curPixelShader == NOISE_ONLY_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_RINGS, (m_curPixelShader == RINGS_ONLY_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_NOISYRINGS, (m_curPixelShader == NOISY_RINGS_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_NOISYWOBBLYRINGS, (m_curPixelShader == NOISY_WOBBLY_RINGS_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_WOOD, (m_curPixelShader == FULL_WOOD_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_IVORY, (m_curPixelShader == IVORY_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_VELVET, (m_curPixelShader == VELVET_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_MARBLE, (m_curPixelShader == MARBLE_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_GRANITE, (m_curPixelShader == GRANITE_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_GOOCH, (m_curPixelShader == GOOCH_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_STRATA, (m_curPixelShader == STRATA_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_SATURN, (m_curPixelShader == SATURN_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem (hMenu, ID_SHADER_VEINED, (m_curPixelShader == VEINED_PIXEL_SHADER) ? MF_CHECKED : MF_UNCHECKED);
	
	CheckMenuItem (hMenu, IDM_TOGGLE_HLSL, m_bUsingHLSL ? MF_CHECKED : MF_UNCHECKED);
}


//-----------------------------------------------------------------------------
// Name: ColorPick()
// Desc:
//-----------------------------------------------------------------------------
void CMain::ColorPick(D3DCOLORVALUE *rgbColor)
{
	CHOOSECOLOR cc;
	COLORREF    crCustColors[16];
	COLORREF    rgb;
	BYTE        red, green, blue;
	
	red   = (BYTE) ((rgbColor->r) * 255.0f);
	green = (BYTE) ((rgbColor->g) * 255.0f);
	blue  = (BYTE) ((rgbColor->b) * 255.0f);
	
	rgb = RGB((BYTE)((red>>16)&0xff), (BYTE)((green>>8)&0xff), (BYTE)(blue&0xff));
	
	cc.lStructSize		= sizeof(CHOOSECOLOR);
	cc.hwndOwner		= m_hWnd;
	cc.hInstance		= m_hWnd;
	cc.rgbResult		= rgb;
	cc.lpCustColors	= crCustColors;
	cc.Flags			   = CC_RGBINIT | CC_FULLOPEN;
	cc.lCustData		= 0l;
	cc.lpfnHook			= NULL;
	cc.lpTemplateName	= NULL;
	
	if (ChooseColor(&cc))
	{
		rgbColor->r = (FLOAT) (GetRValue(cc.rgbResult) / 255.0f);
		rgbColor->g = (FLOAT) (GetGValue(cc.rgbResult) / 255.0f);
		rgbColor->b = (FLOAT) (GetBValue(cc.rgbResult) / 255.0f);
	}
	
}


//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CMain::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	
	LPD3DXBUFFER pBufferErrors = NULL;
	LPD3DXEFFECT pDummyEffect  = NULL;
	
	m_ArcBall.HandleMouseMessages( hWnd, uMsg, wParam, lParam );
	
	// Trap context menu
	if( WM_CONTEXTMENU == uMsg )
	{
		return 0;
	}
	
	// Handle menu commands
	if( WM_COMMAND == uMsg )
	{
		switch( LOWORD(wParam) )
		{
		case IDM_REFRESH_EFFECT:
			
			HRESULT hr;
			
			hr = D3DXCreateEffectFromFile(m_pd3dDevice, TEXT("HLSL_FX.fxl"), NULL, NULL, 0, NULL, &pDummyEffect, &pBufferErrors );
			
			if (FAILED (hr))
			{
				m_bEffectSucceeded = FALSE;
				OutputDebugString ( (char *) pBufferErrors->GetBufferPointer());
			}
			else
			{
				m_bEffectSucceeded = TRUE;
				SAFE_RELEASE(m_pEffect);
				
				m_pEffect = pDummyEffect;
			}
			
			break;
			
		case IDM_TOGGLE_HLSL:
			
			if ((m_curPixelShader != MARBLE_PIXEL_SHADER) && (m_curPixelShader != GRANITE_PIXEL_SHADER) && (m_curPixelShader != GOOCH_PIXEL_SHADER) && (m_curPixelShader != STRATA_PIXEL_SHADER) && (m_curPixelShader != SATURN_PIXEL_SHADER) && (m_curPixelShader != VEINED_PIXEL_SHADER))
			{
				m_bUsingHLSL = !m_bUsingHLSL;
			}
			else
			{
				m_bUsingHLSL = TRUE;
			}
			break;
			
		case ID_SHADER_NOISE:
			m_curPixelShader = NOISE_ONLY_PIXEL_SHADER;
			break;
			
		case ID_SHADER_RINGS:
			m_curPixelShader = RINGS_ONLY_PIXEL_SHADER;
			break;
			
		case ID_SHADER_NOISYRINGS:
			m_curPixelShader = NOISY_RINGS_PIXEL_SHADER;
			break;
			
		case ID_SHADER_NOISYWOBBLYRINGS:
			m_curPixelShader = NOISY_WOBBLY_RINGS_PIXEL_SHADER;
			break;
			
		case ID_SHADER_WOOD:
			m_curPixelShader = FULL_WOOD_PIXEL_SHADER;
			break;
			
		case ID_SHADER_IVORY:
			m_curPixelShader = IVORY_PIXEL_SHADER;
			break;
			
		case ID_SHADER_VELVET:
			m_curPixelShader = VELVET_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_MARBLE:
			m_curPixelShader = MARBLE_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_GRANITE:
			m_curPixelShader = GRANITE_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_GOOCH:
			m_curPixelShader = GOOCH_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_STRATA:
			m_curPixelShader = STRATA_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_SATURN:
			m_curPixelShader = SATURN_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case ID_SHADER_VEINED:
			m_curPixelShader = VEINED_PIXEL_SHADER;
			m_bUsingHLSL = TRUE;
			break;
			
		case IDM_TOGGLE_TEXTURE_MATRIX_UPDATE:
			m_ObjectParameters.m_bUpdatingTextureMatrices = !m_ObjectParameters.m_bUpdatingTextureMatrices;
			break;
			
		case IDM_TOGGLE_UI:
			m_bDrawUI = !m_bDrawUI;
			break;
			
		case IDM_CHOOSE_LIGHT_WOOD_COLOR:
			ColorPick(&m_ObjectParameters.m_rgbLightWood);
			break;
			
		case IDM_CHOOSE_DARK_WOOD_COLOR:
			ColorPick(&m_ObjectParameters.m_rgbDarkWood);
			break;
			
		case IDM_INCREASE_CURRENT_PARAMETER:
			
			switch (m_CurrentParameter)
			{
			case PARAM_NOISE_AMPLITUDE:
				m_ObjectParameters.m_fNoiseAmplitude += 0.01f;
				break;
				
			case PARAM_RING_FREQUENCY:
				m_ObjectParameters.m_fRingFrequency += 0.1f;
				break;
				
			case PARAM_TRUNK_WOBBLE_AMPLITUDE:
				m_ObjectParameters.m_fTrunkWobbleAmplitude += 0.01f;
				break;
				
			case PARAM_TRUNK_WOBBLE_FREQUENCY:
				m_ObjectParameters.m_fTrunkWobbleFreq += 0.02f;
				break;
			}
			
			break;
			case IDM_DECREASE_CURRENT_PARAMETER:
				
				switch (m_CurrentParameter)
				{
				case PARAM_NOISE_AMPLITUDE:
					m_ObjectParameters.m_fNoiseAmplitude -= 0.01f;
					break;
					
				case PARAM_RING_FREQUENCY:
					m_ObjectParameters.m_fRingFrequency -= 0.1f;
					break;
					
				case PARAM_TRUNK_WOBBLE_AMPLITUDE:
					m_ObjectParameters.m_fTrunkWobbleAmplitude -= 0.01f;
					break;
					
				case PARAM_TRUNK_WOBBLE_FREQUENCY:
					m_ObjectParameters.m_fTrunkWobbleFreq -= 0.02f;
					break;
				}
				
				break;
				case IDM_NEXT_PARAMETER:
					m_CurrentParameter = (m_CurrentParameter + 1) % NUM_PARAMETERS;
					break;
				case IDM_PREVIOUS_PARAMETER:
					m_CurrentParameter = (m_CurrentParameter - 1 + NUM_PARAMETERS) % NUM_PARAMETERS;
					break;
					
				case IDM_NEXT_PARAMETER_SET:
					m_curWoodParameterSet = (m_curWoodParameterSet + 1) % NUM_SAMPLE_TEXTURES;
					
					m_ObjectParameters.m_rgbLightWood.r = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.r;
					m_ObjectParameters.m_rgbLightWood.g = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.g;
					m_ObjectParameters.m_rgbLightWood.b = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.b;
					
					m_ObjectParameters.m_rgbDarkWood.r  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.r;
					m_ObjectParameters.m_rgbDarkWood.g  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.g;
					m_ObjectParameters.m_rgbDarkWood.b  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.b; 
					break;
				case IDM_PREVIOUS_PARAMETER_SET:
					m_curWoodParameterSet = (m_curWoodParameterSet - 1 + NUM_SAMPLE_TEXTURES) % NUM_SAMPLE_TEXTURES;
					
					m_ObjectParameters.m_rgbLightWood.r = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.r;
					m_ObjectParameters.m_rgbLightWood.g = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.g;
					m_ObjectParameters.m_rgbLightWood.b = g_WoodParameterSets[m_curWoodParameterSet].m_rgbLightWood.b;
					
					m_ObjectParameters.m_rgbDarkWood.r  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.r;
					m_ObjectParameters.m_rgbDarkWood.g  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.g;
					m_ObjectParameters.m_rgbDarkWood.b  = g_WoodParameterSets[m_curWoodParameterSet].m_rgbDarkWood.b; 
					break;
					
}

// Update the menus, in case any state changes occurred
SetMenuStates();
}

// Pass remaining messages to default handler
return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}

