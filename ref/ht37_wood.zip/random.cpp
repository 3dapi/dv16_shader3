#include "random.h"
static int rand48init=0;

#ifdef WIN32  //hack to get this working on systems which dont have drand48
 void srand48(int seed)
   {
   srand(seed);
   }

 double drand48(void)
   {
   double dVal;
   dVal=(double)rand()/(double)RAND_MAX;
   
   return dVal;
   }

#endif //drand48


/*adopted from numerical recipies in C p217*/
double gauss_rv(void)
   {
   time_t timer;
   static int iset=0;
   double fac,r,v1,v2;
   static double gset;

   if(!rand48init)
      {
      srand48((int)time(&timer)); //randomize seed using timer 
      drand48();                  //iterate a few times for truer randomness
      drand48();
      rand48init=1;
      }
   if(iset==0)
      {
      do
	{
	v1=2.0*drand48()-1.0;
  	v2=2.0*drand48()-1.0;
	r=v1*v1+v2*v2;
	}
      while(r>=1.0);
      fac=sqrt(-2.0*log(r)/r);
      gset=v1*fac;
      iset=1;
      return v2*fac;
      }
   else
      {
      iset=0;
      return gset;
      }

   }
