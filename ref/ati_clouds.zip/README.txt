//-----------------------------------------------------------------------------
// Name: Clouds
// 
// Copyright (c) 2002 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========
   The procedural clouds sample demonstrates the use of vertex and pixel shaders 
   to generate realistic, moving cloud layers. The sample uses dependant texture 
   reads to perturb a cloud texture map.

   Rendering clouds is an excellent candidate for vertex and pixel shaders 
   because they are extremely complex and dynamic, and can be achieved entirely 
   by modifying texture coordinates.


Path
====
   Source:        source\DirectX\Clouds


User's Guide
============
   The following keys are implemented. The dropdown menus can be used for some 
   of the same controls.
      <V>         Toggles the vertex shader
      <P>         Toggles the pixel shader
      <Enter>     Starts and stops the scene
      <Space>     Advances the scene by a small increment
      <F2>        Prompts user to select a new rendering device or display mode
      <Alt+Enter> Toggles between fullscreen and windowed modes
      <Esc>       Exits the app.


Programming Notes
=================
   The clouds sample creates multiple cloud layers by rendering a single quad and 
   blending several layers of clouds with a background gradient. For each layer, 
   the idea is to scroll two tileable textures past each other in opposite 
   directions. The first texture is the perturbation texture, which has u and v 
   perturbations stored in the red and green channels of the texture. The second 
   texture is the cloud texture, which has its texture coordinates perturbed by 
   the perturbation map.  For this example, we use a grayscale cloud texture and 
   pack it into the alpha channel of the perturbation map. This texture is fetched 
   twice in the pixel shader, first to obtain the perturbation values, then to 
   read the perturbed texture.

   The vertex shader generates the texture coordinates which are used in the pixel 
   shader. There are two cloud layers being simulated in this example; for each 
   layer there are two sets of texture coordinates moving in opposite directions. 

   The pixel shader renders two cloud layers and linearly interpolates between 
   them. In order to give the clouds a color gradient from a grayscale texture map, 
   a multiply operation is used which scales by two, and then saturates.  In the 
   example, the color to be modulated with the clouds is orange (RGB values: 1.0, 
   0.7, 0.5). The gradient that results from the scale and modulation ranges 
   between brown, orange, yellow and white. Finally, the shader blends the result 
   with a static purple to blue gradient background.