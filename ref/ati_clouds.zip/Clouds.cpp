#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <math.h>
#include <tchar.h>
#include <stdio.h>
#include <D3DX8.h>
#include "D3DApp.h"
#include "D3DFile.h"
#include "D3DFont.h"
#include "D3DUtil.h"
#include "DXUtil.h"
#include "resource.h"



/*
 regular vert with tex coord
*/
typedef struct
{
    FLOAT x, y, z;
    FLOAT tu1, tv1;
 } VERTEX;

DWORD dwVertexDecl[] =
{
	D3DVSD_STREAM( 0 ),
	D3DVSD_REG( 0, D3DVSDT_FLOAT3 ), // Position
	D3DVSD_REG( 7, D3DVSDT_FLOAT2 ), // Tex coord
	D3DVSD_END()
};
#define D3DFVF_VERTEX (D3DFVF_XYZ|D3DFVF_TEX1) 

static VERTEX g_Vertices[]=
{
    //  x       y      z     tu1   tv1    
    { -30.0f, -10.0f, 0.0f, 1.0f, 0.0f },
    { +30.0f, -10.0f, 0.0f, 0.0f, 0.0f },
    { +30.0f, +10.0f, 0.0f, 0.0f, 1.0f },
    { -30.0f, +10.0f, 0.0f, 1.0f, 1.0f },
};



//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    CD3DFont*	m_pStatsFont;
    CD3DFont*	m_pSmallFont;


	LPDIRECT3DVERTEXBUFFER8 m_pQuadVB;
 	LPDIRECT3DTEXTURE8 m_pTex;
 	LPDIRECT3DTEXTURE8 m_pGroundTex;

	DWORD        m_dwVShader;
	DWORD        m_dwPShader;

	D3DXMATRIX  m_matWorld, m_matView, m_matProj;
	D3DXMATRIX  m_matInitial, m_matGroundInitial;

	BOOL        m_bShowHelp;
	BOOL        m_bVertexShader;
	BOOL        m_bPixelShader;
	BOOL        m_bZBuffer;

 
protected:
	HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();

public:
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
};

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}

//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_strWindowTitle    = _T("Clouds");
    m_bUseDepthBuffer   = TRUE;

    m_pStatsFont  = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_pSmallFont  = new CD3DFont( _T("Arial"), 9, D3DFONT_BOLD );

	m_pQuadVB = NULL;
	m_pTex = NULL;
	m_pGroundTex = NULL;
	m_dwVShader = 0;
	m_dwPShader = 0;

	m_bShowHelp        = FALSE;
	m_bVertexShader    = TRUE;
	m_bPixelShader     = TRUE;
	m_bZBuffer         = TRUE;
	D3DXMatrixIdentity( &m_matInitial );
	D3DXMatrixIdentity( &m_matGroundInitial );

}


//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{

    m_matWorld = m_matInitial;
  
	// Set up the vertex/pixel shader constants
    {
    
	
		D3DXVECTOR4 c0( (float)m_fTime*0.02585f,(float)m_fTime*0.00515f, 0.0f, 0.0f);		
		m_pd3dDevice->SetVertexShaderConstant(  0, c0,  1 );

	
		D3DXMATRIX mat;
        D3DXMatrixMultiply( &mat, &m_matView, &m_matProj );
        D3DXMatrixMultiply( &mat, &m_matWorld, &mat );
        D3DXMatrixTranspose( &mat, &mat );
       	m_pd3dDevice->SetVertexShaderConstant(  4, &mat,  4 );
    
    
        
		//c0 -  Common Const (0, 0.5, 1, 0.75)
		//c1 -  Cloud 0 perterbation factor (.07, .07, 0, 0)
		//c2 -  Cloud 0 color (1, 0, 0, 1.0)
		//c3 -  Cloud 1 perterbation factor (.2, .2, 0, 0)
		//c4 -  Cloud 1 color (0, 1, 0, 1.0)
		//c5 -  Background 0 Color
		//c6 -  Background 1 Color

		D3DXVECTOR4 c0p( 0.0f, 0.5f, 1.0f, 0.75f);
		D3DXVECTOR4 c1p( 0.07f, 0.07f, 0.0f, 0.0f);
		D3DXVECTOR4 c2p( 1.0f, 0.7f, 0.5f, 1.0f);
		D3DXVECTOR4 c3p( 0.2f, 0.2f, 0.0f, 0.0f);
		D3DXVECTOR4 c4p( 1.0f, 0.7f, 0.5f, 1.0f);
		D3DXVECTOR4 c5p( 0.7f, 0.0f, 0.7f, 1.0f);
		D3DXVECTOR4 c6p( 0.0f, 0.0f, 0.7f, 1.0f);
	
		m_pd3dDevice->SetPixelShaderConstant(  0, c0p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  1, c1p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  2, c2p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  3, c3p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  4, c4p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  5, c5p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  6, c6p,  1 );
	
    }
    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    // Clear the viewport
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00402000, 1.0f, 0L );
  
    // Begin the scene 
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {	
        
		m_pd3dDevice->SetStreamSource( 0, m_pQuadVB, sizeof(VERTEX) );
      
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matGroundInitial );
		m_pd3dDevice->SetTexture(0, m_pGroundTex);

		m_pd3dDevice->SetVertexShader( D3DFVF_VERTEX );
	  
	   	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, 0, 2 );

		
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matWorld );
		m_pd3dDevice->SetTexture(0, m_pTex);

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, m_bZBuffer );
		if (m_bVertexShader) 
		    m_pd3dDevice->SetVertexShader( m_dwVShader );
		else	
  			m_pd3dDevice->SetVertexShader( D3DFVF_VERTEX );

        if (m_bPixelShader) 
			m_pd3dDevice->SetPixelShader( m_dwPShader );

	    m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, 0, 2 );

	
        // Show frame rate
        m_pStatsFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), m_strFrameStats );
        m_pStatsFont->DrawText( 2, 20, D3DCOLOR_ARGB(255,255,255,0), m_strDeviceStats );


		 if( m_bShowHelp )
        {
            m_pSmallFont->DrawText(  2, 40, D3DCOLOR_ARGB(255,255,255,255),
                                    _T("Keyboard controls:") );
            m_pSmallFont->DrawText( 20, 60, D3DCOLOR_ARGB(255,255,255,255),
                                    _T("Toggle Vertex Shader\n")
                                    _T("Toggle Pixel Shader\n")
                                    _T("Help\nChange device\nExit") );
            m_pSmallFont->DrawText( 210, 60, D3DCOLOR_ARGB(255,255,255,255),
                                    _T("V\n")
                                    _T("P\n")
                                    _T("F1\nF2\nEsc") );
        }
        else
        {
            m_pSmallFont->DrawText(  2, 40, D3DCOLOR_ARGB(255,255,255,255), 
                               _T("Press F1 for help") );
        }


        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
	
	HRESULT hr;

	hr = D3DXCreateTextureFromFile(m_pd3dDevice, "media\\cloudsTurb256.tga", &m_pTex);
	hr = D3DXCreateTextureFromFile(m_pd3dDevice, "media\\rockdark.bmp", &m_pGroundTex);

    m_pStatsFont->InitDeviceObjects( m_pd3dDevice );
    m_pSmallFont->InitDeviceObjects( m_pd3dDevice );



    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    m_pStatsFont->RestoreDeviceObjects();
    m_pSmallFont->RestoreDeviceObjects();

	
 	m_pd3dDevice->SetTexture(0, m_pTex);
 	m_pd3dDevice->SetTexture(1, m_pTex);
 
 	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
 	m_pd3dDevice->SetTextureStageState( 1, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
 

	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
 
    m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


    // Set the transform matrices
	D3DXVECTOR3 vEyePt    = D3DXVECTOR3( 0.0f, 0.0f, -20.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f,  0.0f );
    

    D3DXMatrixIdentity( &m_matWorld );
    D3DXMatrixLookAtLH( &m_matView, &vEyePt, &vLookatPt, &vUpVec );
    FLOAT fAspect = m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_matProj, D3DX_PI/2, fAspect, 1.0f, 1000.0f );

    m_pd3dDevice->SetTransform( D3DTS_WORLD,      &m_matWorld );
    m_pd3dDevice->SetTransform( D3DTS_VIEW,       &m_matView );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_matProj );

		
	D3DXMATRIX mat;
	D3DXMatrixIdentity( &m_matInitial);
    D3DXMatrixRotationX( &mat, D3DX_PI * 0.7f);
    D3DXMatrixMultiply( &m_matInitial, &m_matInitial, &mat );
    D3DXMatrixTranslation( &mat, 0.0f, -1.9f, -8.0f);
    D3DXMatrixMultiply( &m_matInitial, &m_matInitial, &mat );

	D3DXMatrixIdentity( &m_matGroundInitial);
    D3DXMatrixRotationX( &mat, D3DX_PI * -0.5f);
    D3DXMatrixMultiply( &m_matGroundInitial, &m_matGroundInitial, &mat );
    D3DXMatrixTranslation( &mat, 0.0f, -8.5f, -8.0f);
    D3DXMatrixMultiply( &m_matGroundInitial, &m_matGroundInitial, &mat );


	  // Create quad VB
     HRESULT  hr;
	 hr = m_pd3dDevice->CreateVertexBuffer( 4*sizeof(VERTEX),
                                           D3DUSAGE_WRITEONLY, D3DFVF_VERTEX,
                                           D3DPOOL_MANAGED, &m_pQuadVB );
    if( FAILED(hr) )
        return hr;

	VERTEX* pVertices = NULL;
	hr = m_pQuadVB->Lock( 0, 4*sizeof(VERTEX), (BYTE**)&pVertices, 0 );
    if( FAILED(hr) )
        return hr;

    for( DWORD i=0; i<4; i++ )
        pVertices[i] = g_Vertices[i];

    m_pQuadVB->Unlock();


	// Create vertex shader
    {
        LPD3DXBUFFER pCode;

        // Assemble the vertex shader from the file
        if( FAILED( hr = D3DXAssembleShaderFromFile( "shaders\\clouds.vsh", 
                                                     0, NULL, &pCode, NULL ) ) )
            return hr;

        // Create the vertex shader
        hr = m_pd3dDevice->CreateVertexShader( dwVertexDecl, (DWORD*)pCode->GetBufferPointer(),
                                               &m_dwVShader, 0 );
        pCode->Release();
        if( FAILED(hr) )
            return hr;
    }

	// Create pixel shader
    {
        LPD3DXBUFFER pCode;

        // Assemble the pixel shader from the file
         if( FAILED( hr = D3DXAssembleShaderFromFile( "shaders\\clouds.psh", 
                                                     0, NULL, &pCode, NULL ) ) )
            return hr;

        // Create the pixel shader
        hr = m_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(),
                                              &m_dwPShader);
        pCode->Release();
        if( FAILED(hr) )
            return hr;
    }

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
 	SAFE_RELEASE( m_pQuadVB );

	m_pd3dDevice->DeleteVertexShader( m_dwVShader );
	m_pd3dDevice->DeletePixelShader( m_dwPShader );
	m_pStatsFont->InvalidateDeviceObjects();
	m_pSmallFont->InvalidateDeviceObjects();

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	SAFE_RELEASE( m_pQuadVB );

	m_pd3dDevice->SetTexture(0, NULL);
	m_pd3dDevice->SetTexture(1, NULL);
	SAFE_RELEASE( m_pTex );
	SAFE_RELEASE( m_pGroundTex );

    m_pStatsFont->DeleteDeviceObjects();
    m_pSmallFont->DeleteDeviceObjects();
 

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pStatsFont );
	SAFE_DELETE( m_pSmallFont );


    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam,
                                    LPARAM lParam )
{
	// Trap context menu
    if( WM_CONTEXTMENU == uMsg )
        return 0;


    // Perform commands when keys are released
    if( WM_KEYUP == uMsg )
    {
        switch( wParam )
        {
        case 'V': 
			 m_bVertexShader = !m_bVertexShader;
            break;
         case 'P': 
			 m_bPixelShader = !m_bPixelShader;
            break;
       case VK_F1:
            m_bShowHelp = !m_bShowHelp;
            break;
        }
    }

    return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}

