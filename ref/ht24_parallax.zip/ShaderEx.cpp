// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pEft		= NULL;
	m_pFVF		= NULL;

	m_pTxDif	= NULL;
	m_pTxNor	= NULL;

	m_pMesh		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
								, "data/shader.fx"
								, NULL
								, NULL
								, dwFlags
								, NULL
								, &m_pEft
								, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	DWORD	dFVF = VtxNUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/newdarkrock_d.tga", &m_pTxDif);
	D3DXCreateTextureFromFile( m_pDev, "data/newdarkrock_n.tga", &m_pTxNor);

	// ������
	LPD3DXMESH		pMshO = NULL;
	LPD3DXBUFFER	pAdjc = NULL;

    // Load the mesh
    hr = D3DXLoadMeshFromX( "Data/t-pot.x"
								, D3DXMESH_SYSTEMMEM
								, m_pDev
								, &pAdjc
								, NULL
								, NULL
								, NULL
								, &pMshO );

	if(FAILED(hr))
		return hr;


    // Optimize the mesh for performance
	hr = pMshO->OptimizeInplace(
                        D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE
						, (DWORD*)pAdjc->GetBufferPointer()
						, NULL
						, NULL
						, NULL );

    if( FAILED(hr))
        return hr;


	pMshO->CloneMeshFVF(D3DXMESH_MANAGED, VtxNUV1::FVF, m_pDev, &m_pMesh );
	D3DXComputeNormals( m_pMesh, NULL );

	SAFE_RELEASE(	pMshO	);
	SAFE_RELEASE(	pAdjc	);


	m_fPxScale	= .3f;
	m_fPxBias	= .1f;

	char	sMsg[64];
	sprintf(sMsg, "Try to Press Left or Right or Up or Down Key");
	SetWindowText(GetActiveWindow(), sMsg);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);

	SAFE_RELEASE(	m_pTxNor	);
	SAFE_RELEASE(	m_pTxDif	);

	SAFE_RELEASE(	m_pMesh		);
}


INT CShaderEx::FrameMove()
{
	if(::GetAsyncKeyState(VK_LEFT) && 0x8000)
		m_fPxScale +=0.001f;
	if(::GetAsyncKeyState(VK_RIGHT) && 0x8000)
		m_fPxScale -=0.001f;

	if(::GetAsyncKeyState(VK_UP) && 0x8000)
		m_fPxBias +=0.001f;
	if(::GetAsyncKeyState(VK_DOWN) && 0x8000)
		m_fPxBias -=0.001f;


	char	sMsg[64];
	sprintf(sMsg, "%f %f", m_fPxScale, m_fPxBias);
	SetWindowText(GetActiveWindow(), sMsg);

	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	}


	// ��ļ���
	MATA	mtWVP;			// World * View * Projection Matrix
	MATA	mtViw;			// View Matrix
	MATA	mtPrj;			// Projection Matrix
	MATA	mtTM1;

	MATA	mtRot;
	MATA	mtScl;
	MATA	mtTrs;

	MATA	mtVwI;
	VEC4	vcCam;

	VEC4	vcLgt;

	FLOAT	fPaxScale	= .3f;
	FLOAT	fPaxBias	= .1f;

	FLOAT	fTime = 10;
	
	//fTime = g_pApp->GetTime()*0.8f;

	m_pDev->GetTransform( D3DTS_VIEW,  &mtViw );
	m_pDev->GetTransform( D3DTS_PROJECTION,  &mtPrj );

	D3DXMatrixInverse(&mtVwI, NULL, &mtViw);			// ����Ŀ��� ī�޶��� ��ġ�� ��´�.

	vcCam	= VEC4(mtVwI._41, mtVwI._42, mtVwI._43, 0);
	vcLgt	= VEC4( 1.f, 0.f, 0.f, 0);					// ������ ����

	D3DXVec4Normalize( &vcLgt, &vcLgt );

	D3DXMatrixRotationY(  &mtRot, fTime );				// �������(ȸ��)
	D3DXMatrixScaling(    &mtScl, 10.f, 10.f, 10.f );	// ũ�����
	D3DXMatrixTranslation(&mtTrs, 0.f, 20.f ,-2.f );	// �̵� ���


	mtWVP = mtRot * mtScl * mtTrs * mtViw * mtPrj;		// ������ ���� ���
	mtTM1 = mtRot * mtTrs;								// ������ ���� ���͸� ���� ���



	// Render
	m_pDev->SetVertexDeclaration( m_pFVF );				// ���� ����

	m_pEft->SetMatrix( "m_mtWVP", &mtWVP);				// ����*��*�������� ��ȯ ���
	m_pEft->SetMatrix( "m_mtRot", &mtRot);				// ȸ�� ��ȯ ���
	m_pEft->SetMatrix( "m_mtTM1", &mtTM1);				// ȸ�� �̵� ��ȯ ���

	m_pEft->SetVector( "m_vcCam", &vcCam);				// ī�޶� ��ġ
	m_pEft->SetVector( "m_vcLgt", &vcLgt );				// ������ ����

	m_pEft->SetFloat(  "m_fPxScale", m_fPxScale);		// Parallax Scale
	m_pEft->SetFloat(  "m_fPxBias", m_fPxBias);			// Parallax Bias

	m_pEft->SetTexture( "m_TxDif", m_pTxDif);			// �����
	m_pEft->SetTexture( "m_TxNor", m_pTxNor);			// ���� ��

	m_pEft->SetTechnique( "Tech0");

	m_pEft->Begin( NULL, 0 );
	m_pEft->Pass( 0 );

	m_pMesh->DrawSubset( 0 );

	m_pEft->End();

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);

	m_pDev->SetTexture(0, NULL);
}



