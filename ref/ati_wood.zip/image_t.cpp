//==================================//
// image.cpp                        //
//                                  //
// Drew Card                        //
// ATI Research                     //
// Software Engineer                //
// 3D Application Research Group    //
// dcard@ati.com                    //
//==================================//

//==========//
// includes //
//==========//
#include "image_t.h"
#include <stdio.h>

//===============================//
// single byte structure packing //
//===============================//
#pragma pack (push)
#pragma pack (1)

//=========================//
// targa image file header //
//=========================//
typedef struct targa_s
{
	unsigned char	idLength;
	unsigned char	colorMapType;
	unsigned char	imageType;
	unsigned short	colorMapIndex;
	unsigned short	colorMapLength;
	unsigned char	colorMapSize;
	unsigned short	xOrigin;
	unsigned short	yOrigin;
	unsigned short	width;
	unsigned short	height;
	unsigned char	pixelDepth;
	unsigned char	imageDescriptor;
} targa_t;

typedef struct bmp_s
{
	unsigned char	id[2];
	unsigned long	fileLength;
	unsigned long	reserved;
	unsigned long	bitmapDataOffset;
	unsigned long	bitmapHeaderSize;
	unsigned long	width;
	unsigned long	height;
	unsigned short	planes;
	unsigned short	pixelDepth;
	unsigned long	compression;
	unsigned long	bitmapDataSize;
	unsigned long	horizRes;
	unsigned long	vertRes;
	unsigned long	colors;
	unsigned long	importantColors;
} bmp_t;

typedef struct texture_s
{
   char     name[32];
   GLuint   handle;
   int      refCount;
} texture_t;

#pragma pack (pop)

static texture_t     g_textures[1000];
static int           g_nTextureCount = 0;

//==============================================//
// imgConvertBGRToRGB                           //
// swaps the blue and red fields for the image  //
//==============================================//
static void imgConvertBGRToRGB(image_t* img)
{
   int redIndex;
   int blueIndex;
   char blue;
	for (int i = 0; i < img->height; i++)
	{
		for (int j = 0; j < img->width; j++)
		{
			blueIndex = (i * img->width + j) * img->depth;
			redIndex = blueIndex + 2;
			blue = img->data[blueIndex];
			img->data[blueIndex] = img->data[redIndex];
			img->data[redIndex] = blue;
		}
	}
}

//================//
// CheckTextures  //
//================//
GLuint CheckTextures(char* name)
{
   int i;

   for (i = 0; i < g_nTextureCount; i++)
   {
      if (!strcmp(name, g_textures[i].name))
      {
         g_textures[i].refCount++;
         return g_textures[i].handle;
      }
   }

   strcpy(g_textures[g_nTextureCount].name, name);
   g_textures[g_nTextureCount].refCount++;
   g_nTextureCount++;
   return 0;
}

//=====================================================//
// imgBuildTexture                                     //
// creates a mip-mapped texture using the passed image //
//=====================================================//
GLuint imgBuildTexture(image_t* img)
{
   GLuint   tex = 0;

   tex = CheckTextures(img->name);
	if (tex != 0)
   {
      return tex;
   }
   
   glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glGenTextures(1, &tex);
   g_textures[g_nTextureCount-1].handle = tex;
   glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

	if (img->depth == 3)
	{
		gluBuild2DMipmaps(
			GL_TEXTURE_2D, 3, 
			img->width, 
			img->height,
			GL_RGB, GL_UNSIGNED_BYTE, 
			img->data);
	}
	else if (img->depth == 4)
	{
		gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 
			img->width, 
			img->height,
			GL_RGBA, GL_UNSIGNED_BYTE, 
			img->data);
	}

   return tex;
}

//=====================================================//
// imgBuildTextureNoMip                                //
// creates a standard texture using the passed image   //
//=====================================================//
GLuint imgBuildTextureNoMip(image_t* img)
{
   GLuint   tex = 0;
   
   tex = CheckTextures(img->name);
	if (tex != 0)
   {
      return tex;
   }

  	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glGenTextures(1, &tex);
   g_textures[g_nTextureCount-1].handle = tex;
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	if (img->depth == 3)
	{
		glTexImage2D(GL_TEXTURE_2D, 
         0, 
         3, 
			img->width, 
			img->height,
         0,
         GL_RGB, GL_UNSIGNED_BYTE, 
			img->data);
	}
	else if (img->depth == 4)
	{
		glTexImage2D(GL_TEXTURE_2D, 
         0, 
         4, 
			img->width, 
			img->height,
         0,
         GL_RGBA, GL_UNSIGNED_BYTE, 
			img->data);
	}

   return tex;
}

//======================//
// imgReleaseTexture    //
// releases the texture //
//======================//
void imgReleaseTexture(GLuint tex)
{
   int i;

   for (i = 0; i < g_nTextureCount; i++)
   {
      if (g_textures[i].handle == tex)
      {
         g_textures[i].refCount--;
         if (g_textures[i].refCount == 0)
         {
            glDeleteTextures(1, &g_textures[i].handle);
            if (i < g_nTextureCount - 1)
            {
               memmove(&g_textures[i], &g_textures[i + 1], sizeof(texture_t) * (g_nTextureCount - i - 1));
               g_nTextureCount--;
            }
         }
      }
   }
}

//======================//
// imgFree              //
// frees the image data //
//======================//
void imgFree(image_t* img)
{
   if (img->data != NULL)
   {
      free(img->data);
      img->data = NULL;
   }
   memset(img, 0, sizeof(image_t));
}

//================================================================//
// imgLoadTexture                                                 //
// loads a targa image file creates an opengl texture             //
//================================================================//
GLuint imgLoadTexture(const char* filename)
{
   GLuint   tex = 0;
   image_t  img;

   memset(&img, 0, sizeof(image_t));

   if (imgLoad(filename, &img) == IMAGE_OK)
   {
      tex = imgBuildTexture(&img);
   }

   imgFree(&img);

   return tex;
}

//=================================================================//
// imgLoad                                                         //
// loads the image file and stores it in the image_t structue      //
//=================================================================//
int imgLoad(const char* filename, image_t* img)
{
	char*		ext;

   //================================================//
   // get pointer to the last period in the filename //
   //================================================//
	ext = strrchr(filename, '.');
   if (ext)
   {
      if (!stricmp(ext, ".bmp"))
		{
         return imgLoadBmp(filename, img);
		}
		else if ((!stricmp(ext, ".tga")) || (!stricmp(ext, ".targa")))
		{
         return imgLoadTarga(filename, img);
		}
	}

	return IMAGE_ERROR;   
}



//=================================================================//
// imgLoadBmp                                                      //
// loads a bitmap image file and stores it in the image_t structue //
//=================================================================//
int imgLoadBmp(const char* filename, image_t* img)
{
   FILE*    file;
   bmp_t    header;

   if ((filename == NULL) || (filename[0] == '\0'))
   {
      return IMAGE_ERROR;
   }

   //===============//
   // open the file //
   //===============//
   file = fopen(filename, "rb");
   if (file)
   {
      strcpy(img->name, filename);

      //===================================//
      // fseek to the begining of the file //
      //===================================//
      fseek(file, 0, SEEK_SET);
      
      //=========================//
      // read in the file header //
      //=========================//
      fread(&header, sizeof(char), sizeof(bmp_t), file);

      //=====================================================//
      // make sure that the file is an uncompressed RGB file //
      //=====================================================//
 	   if (header.compression == 0)
      {
         //====================//
         // get the image size //
         //====================//
         img->depth = (long)header.pixelDepth / 8;
         img->width = (long)header.width;
         img->height = (long)header.height;
         img->size = img->depth * img->width * img->height;

         //====================//
         // allocate the image //
         //====================//
         img->data = (char*)malloc(sizeof(char) * img->size);
         if (img->data == NULL)
         {
            fclose(file);
            return IMAGE_ERROR;
         }

         //=====================================//
         // seek to the start of the image data //
         //=====================================//
         fseek(file, header.bitmapDataOffset, SEEK_SET);
         
         //========================//
         // read in the image data //
         //========================//
         fread(img->data, sizeof(char), img->size, file);
	   }
      else
      {
         fclose(file);
         return IMAGE_ERROR;
      }

      //================//
      // close the file //
      //================//
      fclose(file);

      //===================================//
      // convert the image from BGR to RGB //
      //===================================//
      imgConvertBGRToRGB(img);
   }
   else
   {
      return IMAGE_ERROR;
   }
   
   return IMAGE_OK;
}

//================================================================//
// imgLoadTarga                                                   //
// loads a targa image file and stores it in the image_t structue //
//================================================================//
int imgLoadTarga(const char* filename, image_t* img)
{
   FILE*    file;
   targa_t  header;

   if ((filename == NULL) || (filename[0] == '\0'))
   {
      return IMAGE_ERROR;
   }

   //===============//
   // open the file //
   //===============//
   file = fopen(filename, "rb");
   if (file)
   {
      strcpy(img->name, filename);

      //===================================//
      // fseek to the begining of the file //
      //===================================//
      fseek(file, 0, SEEK_SET);
      
      //=========================//
      // read in the file header //
      //=========================//
      fread(&header, sizeof(char), sizeof(targa_t), file);

      //=====================================================//
      // make sure that the file is an uncompressed RGB file //
      //=====================================================//
 	   if (header.imageType == 2)
      {
         //====================//
         // get the image size //
         //====================//
         img->depth = (long)header.pixelDepth / 8;
         img->width = (long)header.width;
         img->height = (long)header.height;
         img->size = img->depth * img->width * img->height;

         //====================//
         // allocate the image //
         //====================//
         img->data = (char*)malloc(sizeof(char) * img->size);
         if (img->data == NULL)
         {
            fclose(file);
            return IMAGE_ERROR;
         }

         //=====================================//
         // seek to the start of the image data //
         //=====================================//
         fseek(file, sizeof(targa_t) + header.idLength, SEEK_SET); 
         
         //========================//
         // read in the image data //
         //========================//
         fread(img->data, sizeof(char), img->size, file);
	   }
      else
      {
         fclose(file);
         return IMAGE_ERROR;
      }

      //================//
      // close the file //
      //================//
      fclose(file);

      //===================================//
      // convert the image from BGR to RGB //
      //===================================//
      imgConvertBGRToRGB(img);
   }
   else
   {
      return IMAGE_ERROR;
   }
   
   return IMAGE_OK;
}

//===================//
// imgLoadTargaRaw   //
//===================//
int imgLoadTargaRaw(const char* data, image_t* img)
{
   targa_t* header = (targa_t*)data;
  
   img->depth = (long)header->pixelDepth / 8;
   img->width = (long)header->width;
   img->height = (long)header->height;
   img->size = img->depth * img->width * img->height;

   img->data = (char*)malloc(sizeof(char) * img->size);
   if (img->data == NULL)
   {
      return IMAGE_ERROR;
   }
   
	if (header->imageType == 2) // No Compression
	{
      memcpy(img->data, data + sizeof(targa_t) + header->idLength, img->size);
	}
   else
   {
      return IMAGE_ERROR;
   }
	
   imgConvertBGRToRGB(img);
   
   return IMAGE_OK;
}
