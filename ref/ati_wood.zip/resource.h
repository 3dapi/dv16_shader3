//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winmain.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDD_SELECTDEVICE                144
#define IDC_CURSOR_EYE_DROPPER          147
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_TOGGLESTART                 40004
#define IDM_SINGLESTEP                  40005
#define IDM_EXIT                        40006
#define IDM_U8V8L8                      40011
#define IDM_U5V5L6                      40012
#define IDM_U8V8                        40013
#define IDM_TEXTURETOGGLE               40014
#define IDM_BUMPMAPTOGGLE               40015
#define IDM_ENVMAPTOGGLE                40016
#define IDM_LOW_TESSELATION             40017
#define IDM_HIGH_TESSELATION            40018
#define IDM_TOGGLE_ADJUST_CLIP_PLANE    40018
#define IDM_CHOOSE_LIGHT_WOOD_COLOR     40019
#define IDM_CHOOSE_DARK_WOOD_COLOR      40020
#define IDM_INCREASE_CURRENT_PARAMETER  40021
#define IDM_DECREASE_CURRENT_PARAMETER  40022
#define IDM_NEXT_PARAMETER              40023
#define IDM_PREVIOUS_PARAMETER          40024
#define IDM_TOGGLE_USE_CLIP_PLANE       40025
#define IDM_TOGGLE_TEXTURE_MATRIX_UPDATE 40026
#define IDM_NEXT_PARAMETER_SET          40027
#define IDM_PREVIOUS_PARAMETER_SET      40028
#define IDM_NEXT_OBJECT                 40029
#define IDM_PREVIOUS_OBJECT             40030
#define IDM_TOGGLE_UI                   40031
#define IDM_TOGGLE_SCENE                40032
#define IDM_CHOOSE_GUMBO1               40033
#define IDM_CHOOSE_GUMBO2               40034
#define IDM_CHOOSE_BOARD                40035
#define IDM_CHOOSE_NOISE_ONLY_PIXEL_SHADER 40036
#define IDM_CHOOSE_RINGS_ONLY_PIXEL_SHADER 40037
#define IDM_CHOOSE_NOISY_RINGS_PIXEL_SHADER 40038
#define IDM_CHOOSE_NOISY_WOBBLE_RINGS_PIXEL_SHADER 40039
#define IDM_CHOOSE_FULL_WOOD_PIXEL_SHADER 40040
#define IDM_TOGGLE_HLSL                 40042
#define ID_SHADER_WOOD                  40044
#define ID_SHADER_RINGS                 40045
#define ID_SHADER_NOISE                 40046
#define ID_SHADER_NOISYRINGS            40047
#define ID_SHADER_NOISYWOBBLYRINGS      40048
#define ID_SHADER_IVORY                 40049
#define IDM_REFRESH_EFFECT              40050
#define ID_SHADER_MARBLE                40051
#define ID_SHADER_GOOCH                 40052
#define ID_SHADER_GRANITE               40053
#define ID_SHADER_VELVET                40054
#define ID_SHADER_STRATA                40055
#define ID_SHADER_VEINED                40056
#define ID_SHADER_SATURN                40057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         40058
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
