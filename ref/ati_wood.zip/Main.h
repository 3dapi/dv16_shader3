// Main.h: interface for the CMain class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


#define NUM_SAMPLE_TEXTURES            6


class CMain : public CD3DApplication
{
public:
	struct POS_NORM_VERTEX
	{
		D3DXVECTOR3 p;
		D3DXVECTOR3 n;
		
		enum {FVF=(D3DFVF_XYZ | D3DFVF_NORMAL), };
	};


	struct POS_VERTEX
	{
		D3DXVECTOR3 p;

		enum {FVF=(D3DFVF_XYZ), };
	};


	struct OVERLAY_VERTEX
	{
		FLOAT       x;
		FLOAT       y;
		FLOAT       z;
		FLOAT       rhw;
		FLOAT       tu, tv;

		enum {FVF=(D3DFVF_XYZRHW | D3DFVF_TEX1), };
	};



	struct WOOD_PARAMETER_SET
	{
		D3DCOLORVALUE    m_rgbLightWood;  // Color of light bands in wood
		D3DCOLORVALUE    m_rgbDarkWood;   // Color of dark bands in wood
	};

	struct OBJECT_PARAMETER_SET
	{
		D3DCOLORVALUE    m_rgbLightWood;               // Color of light bands in wood
		D3DCOLORVALUE    m_rgbDarkWood;                // Color of dark bands in wood
		float            m_fTrunkWobbleFreq;           // Trunk wobble frequency
		float            m_fTrunkWobbleAmplitude;      // Trunk wobble amplitude
		float            m_fNoiseAmplitude;            // Amplitude of noise
		float            m_fRingFrequency;             // Number of wood rings per world-space unit
		BOOL             m_bUpdatingTextureMatrices;   // Indicates whether texture matrix is currently being updated by motion
		D3DXMATRIX    m_matTex0;                    // Texture Matrix 0
		D3DXMATRIX    m_matTex1;                    // Texture Matrix 1
		D3DXMATRIX    m_matTex2;                    // Texture Matrix 2
	};


protected:
	CD3DFont*                     m_pFont;                    // A font to output text
	CD3DFont*                     m_pBigFont;                 // A big font to output text
	
	CD3DArcBall                   m_ArcBall;                  // ArcBall used for mouse input
	
	model_t                       m_GumboBody;                // Body of Gumbo
	model_t                       m_GumboTusks;               // Gumbo's Tusks
	
	D3DXMATRIX                 m_matProj;                  // Projection Matrix
	D3DXMATRIX                 m_matView;                  // View Matrix
	D3DXMATRIX                 m_matInvView;               // Inverse of View Matrix
	D3DXMATRIX                 m_matWorld;                 // World Matrix
	
	D3DXMATRIX                 m_matWorldViewProj;         // World-View-Projection Matrix
	D3DXMATRIX                 m_matWorldView;             // World-View Matrix
	D3DXMATRIX                 m_matITWorldView;           // Inverse Transpose World Matrix                                                         
	D3DXVECTOR4                   m_vecLight_Eye;             // Eye space light vector
	
	LPDIRECT3DVOLUMETEXTURE9      m_pVolumeNoiseTexture;      // 3D Luminance Noise texture
	LPDIRECT3DTEXTURE9            m_pWoodBandTexture;         // 1D smooth pulse train for color blend, specular exponent etc
	LPDIRECT3DTEXTURE9            m_pVariableSpecularTexture; // 2D variable specular function texture
	LPDIRECT3DTEXTURE9            m_pStrataSplineTexture;     // 1D strata spline texture
	LPDIRECT3DTEXTURE9            m_pSaturnSplineTexture;     // 1D Saturn spline texture
	LPDIRECT3DTEXTURE9            m_pMarbleColorSplineTexture;// 1D marble spline texture
	LPDIRECT3DTEXTURE9            m_pLogoTexture;             // 2D Logo texture
	
	LPDIRECT3DTEXTURE9            m_pSampleWoodTexture[NUM_SAMPLE_TEXTURES]; // Photographs of real wood
	
	LPDIRECT3DVERTEXDECLARATION9  m_pVertexDeclaration;      // Vertex declaration
	
	// Effect holds all of our techniques including asm and HLSL
	LPD3DXEFFECT                  m_pEffect;
	BOOL                          m_bEffectSucceeded;
	BOOL                          m_bUsingHLSL;
	
	LPDIRECT3DVERTEXBUFFER9       m_pImageVB;                 // Geometry for overlay image
	LPDIRECT3DVERTEXBUFFER9       m_pLogoVB;                  // Geometry for overlay logo
	
	BOOL                          m_bDrawUI;
	DWORD                         m_dwNumSphereVertices;
	
	DWORD                         m_CurrentParameter;        // For controlling parameter modification UI
	DWORD                         m_curWoodParameterSet;     // For controlling loaded parameter sets and wood photographs
	DWORD                         m_curPixelShader;          // Current pixel shader used on object
	
	OBJECT_PARAMETER_SET          m_ObjectParameters;
	
	
	// Internal functions
	void    SetMenuStates();
	void    ComputeOverlayPlacement (int width, int height);
	HRESULT InitNoiseTexture();
	HRESULT Init1DWoodBandTexture();
	HRESULT InitVariableSpecularTexture();
	HRESULT InitSplineTextures();
	HRESULT InitLogoTexture();
	HRESULT InitSampleWoodTextures();
	HRESULT InitOverlayImages();
	void    ColorPick(D3DCOLORVALUE *rgbColor);
	void    SetupEffectConstants(void);
	char   *GetTechniqueName(BOOL bHLSL, DWORD dwShader);
	
protected:
	HRESULT OneTimeSceneInit();
	HRESULT InitDeviceObjects();
	HRESULT RestoreDeviceObjects();
	HRESULT InvalidateDeviceObjects();
	HRESULT DeleteDeviceObjects();
	HRESULT Render();
	HRESULT FrameMove();
	HRESULT FinalCleanup();
	HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );
	
public:
	CMain();
	LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};


#endif

