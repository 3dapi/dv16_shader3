#ifndef RANDOM_H
#define RANDOM_H

#include <stdlib.h>
#include <time.h>
#include <math.h>

#ifdef WIN32  //hack to get this working on systems which dont have drand48
 void srand48(int seed);  
 double drand48(void);  
#endif //drand48

double gauss_rv(void);

#endif
