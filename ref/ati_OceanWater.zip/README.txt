//-----------------------------------------------------------------------------
// Name: OceanWater Sample
// 
// Copyright (c) 2002 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------


Description
===========

   The OceanWater sample demonstrates the use of vertex and pixel shaders to 
   create the effect of a shiny oscillating ocean surface with multiple waves 
   moving in different directions. Rendering realistic ocean water is particularly 
   difficult due to the shape of the surface of the water and combination of 
   multiple waves, and the reflection of the clouds, and the sun in the sky.
 
   The vertex and pixel shaders are used to implement a cubic environment map 
   to provide the reflection of the sky and clouds, a deforming grid that 
   simulates the larger waves, two bump maps for smaller waves, and an indexed 
   Fresnel map to provide the surface color.


Path
====
   Source:        source\DirectX\OceanWater


User's Guide
============
   The following keys are implemented. The dropdown menus can be used for the 
   same controls.
      <Enter>     Starts and stops the scene
      <Space>     Advances the scene by a small increment
      <F2>        Prompts user to select a new rendering device or display mode
      <Alt+Enter> Toggles between fullscreen and windowed modes
      <Esc>       Exits the app.


Programming Notes
=================
   The input geometry is a grid of quads with 1 set of texture coordinates, normals 
   and tangents. A prerendered sky and clouds texture is used for the cubic 
   environment map.

   The vertex shader is responsible for generating the combination of sine waves 
   that perturb the position, and cosine waves that perturb the tangent space 
   vectors for the vertex.   A Taylor series approximation is used to generate sine 
   and cosine functions within the shader. Each sine wave has fully adjustable 
   direction, frequency, speed, and offset, that is configured in the constant 
   store.

   The pixel shader is responsible for producing the bump-mapped reflective ocean 
   surface. First, the pixel shader averages the two scrolling normal bump maps to
   generate a composite normal. Next, it transforms the tangent space composite 
   normal into world space and calculates a per-pixel reflection vector.  The 
   reflection vector is used to sample a skybox cubic environment map. The shader 
   also calculates 2*N.V, and uses it to sample a Fresnel 1-D texture.  This 
   Fresnel map gives the water a more greenish appearance when looking straight 
   down into it, and a more bluish appearance when looking edge on. 

   The second phase of the pixel shader composites the water color, from the Fresnel 
   map, the environment map, and other specular highlights extracted from the 
   environment map.  One trick we use is to square the environment map color values 
   to make the colors brighter, and to enhance the contrast for compositing. To get 
   the specular light sparkles in the water, a specular component is derived from 
   the green channel of the environment map.  The desired effect is to have the 
   highlights in the water correspond to bright spots in the sky.  To make sure 
   the specular peaks were only generated from the brightest areas of the 
   environment map, the specular value extracted from the green channel was raised 
   to the eighth power.  This has the effect of darkening all but the brightest 
   areas of the image.
 
