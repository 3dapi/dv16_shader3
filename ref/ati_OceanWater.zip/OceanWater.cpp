#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <math.h>
#include <tchar.h>
#include <stdio.h>
#include <D3DX8.h>
#include "D3DApp.h"
#include "D3DFile.h"
#include "D3DFont.h"
#include "D3DUtil.h"
#include "DXUtil.h"
#include "resource.h"

/*
regular vert with tangent
*/
typedef struct
{
    D3DXVECTOR3 p;
    D3DXVECTOR3 n;
    D3DXVECTOR3 p2;  // Wave Height Scale
    FLOAT       tu1, tv1, tw1;
    D3DXVECTOR3 t;
 } VERTEX;

DWORD dwVertexDecl[] =
{
	D3DVSD_STREAM( 0 ),
	D3DVSD_REG( 0, D3DVSDT_FLOAT3 ), // Position
	D3DVSD_REG( 3, D3DVSDT_FLOAT3 ), // Normal
	D3DVSD_REG( 5, D3DVSDT_FLOAT3 ), // Wave Height Scale
	D3DVSD_REG( 7, D3DVSDT_FLOAT3 ), // Tex coords
	D3DVSD_REG( 8, D3DVSDT_FLOAT3 ), // Tangent
	D3DVSD_END()
};
#define D3DFVF_VERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1| D3DFVF_TEXCOORDSIZE3(0))


//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    CD3DFont*	m_pStatsFont;
    CD3DFont*	m_pSmallFont;

	DWORD m_dwVertSize;
	DWORD m_dwNumVerts;
	DWORD m_dwNumFaces;
	LPDIRECT3DVERTEXBUFFER8 m_pVertBuff;
	LPDIRECT3DINDEXBUFFER8 m_pIndxBuff;
	LPDIRECT3DVERTEXBUFFER8 m_pSkyBoxVertBuff;
	LPDIRECT3DINDEXBUFFER8 m_pSkyBoxIndxBuff;
	LPDIRECT3DTEXTURE8 m_pTex;
	LPDIRECT3DTEXTURE8 m_pHeightTex;
	LPDIRECT3DTEXTURE8 m_psBumpMap;         // The actual bumpmap
	LPDIRECT3DCUBETEXTURE8 m_pCubeTex;

	DWORD        m_dwVShader;
	DWORD        m_dwPShader;

	D3DXMATRIX  m_matWorld, m_matView, m_matProj, m_matInitial;

	BOOL        m_bShowHelp;
	BOOL        m_bVertexShader;
	BOOL        m_bPixelShader;
	BOOL        m_bZBuffer;

	float       m_fXCenter;
	float       m_fYCenter;
	float       m_fZCenter;
	float       m_fCamXPos;
	float       m_fCamYPos;
	float       m_fCamZPos;

    HRESULT InitBumpMap();

protected:
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();

public:
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
};

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}

//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_strWindowTitle    = _T("Ocean Water");
    m_bUseDepthBuffer   = TRUE;

    m_pStatsFont  = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_pSmallFont  = new CD3DFont( _T("Arial"), 9, D3DFONT_BOLD );

	m_pVertBuff = NULL;
	m_pIndxBuff = NULL;
	m_pSkyBoxVertBuff = NULL;
	m_pSkyBoxIndxBuff = NULL;
	m_pTex = NULL;
	m_pHeightTex = NULL;
	m_psBumpMap = NULL;
	m_pCubeTex = NULL;
	m_dwVShader = 0;
	m_dwPShader = 0;

	m_dwNumVerts = 0;
	m_dwNumFaces = 0;

	m_bShowHelp        = FALSE;
	m_bVertexShader    = TRUE;
	m_bPixelShader     = TRUE;
	m_bZBuffer         = TRUE;
	D3DXMatrixIdentity( &m_matInitial );

}


//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{

	m_matWorld = m_matInitial;
    m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matWorld );


	// Set up the vertex/pixel shader constants
    {
    
		// c0    - { 0.0,  0.5, 1.0, 2.0}
        // c1    - { 4.0, .5pi, pi, 2pi}  
		// c2    - {1, -1/3!, 1/5!, -1/7!  }  //for sin
		// c3    - {1/2!, -1/4!, 1/6!, -1/8!  }  //for cos
		// c4-7 - Composite World-View-Projection Matrix
		// c8     - ModelSpace Camera Position
		// c9     - ModelSpace Light Position
		// c10   - {fixup factor for taylor series imprecision, }(1.02, 0.1, 0, 0)
		// c11   - {waveHeight0, waveHeight1, waveHeight2, waveHeight3}  (0.4, 0.5, 0.025, 0.025)
		// c12   - {waveOffset0, waveOffset1, waveOffset2, waveOffset3}  (0.0, 0.2, 0.0, 0.0) 
		// c13   - {waveSpeed0, waveSpeed1, waveSpeed2, waveSpeed3}   (0.2, 0.15, 0.4, 0.4)
		// c14   - {waveDirX0, waveDirX1, waveDirX2, waveDirX3}   (0.25, 0.0, -0.7, -0.8)
		// c15   - {waveDirY0, waveDirY1, waveDirY2, waveDirY3}   (0.0, 0.15, -0.7, 0.1)
		// c16    - { time, sin(time)}
		// c17    - {basetexcoord distortion x0, y0, x1, y1} (0.031, 0.04, -0.03, 0.02)
     	// c18   - World Martix

		D3DXVECTOR4 c0( 0.0f,  0.5f, 1.0f, 2.0f );
		D3DXVECTOR4 c1( 4.0f, 0.5f*D3DX_PI, D3DX_PI, 2.0f*D3DX_PI);
		D3DXVECTOR4 c2( 1.0f,      -1.0f/6.0f,  1.0f/120.0f, -1.0f/5040.0f);
		D3DXVECTOR4 c3( 1.0f/2.0f, -1.0f/24.0f, 1.0f/720.0f, -1.0f/40320.0f );
		D3DXVECTOR4 c8( m_fCamXPos, m_fCamYPos, m_fCamZPos, 1.0);	
		D3DXVECTOR4 c10( 1.02f, 0.1f, 0.0f, 0.0f );
		D3DXVECTOR4 c11( 0.4f, 0.5f, 0.025f, 0.025f);
		D3DXVECTOR4 c12( 0.0f, 0.2f, 0.0f, 0.0f );
		D3DXVECTOR4 c13( 0.2f, 0.15f, 0.4f, 0.4f);
		D3DXVECTOR4 c14( 02.5f, 0.0f, -7.0f, -8.0f);
		D3DXVECTOR4 c15( 0.0f, 1.5f, -7.0f, 1.0f);

		D3DXVECTOR4 c16( (float)m_fTime*0.75f, sinf(m_fTime), 0.0f, 0.0f);
		D3DXVECTOR4 c17( 0.031f, 0.04f, -0.03f, 0.02f);
		
		m_pd3dDevice->SetVertexShaderConstant(  0, c0,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  1, c1,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  2, c2,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  3, c3,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  8, c8,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  10, c10,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  11, c11,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  12, c12,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  13, c13,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  14, c14,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  15, c15,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  16, c16,  1 );
		m_pd3dDevice->SetVertexShaderConstant(  17, c17,  1 );

	
		D3DXMATRIX mat;
        D3DXMatrixMultiply( &mat, &m_matView, &m_matProj );
        D3DXMatrixMultiply( &mat, &m_matWorld, &mat );
        D3DXMatrixTranspose( &mat, &mat );
       	m_pd3dDevice->SetVertexShaderConstant(  4, &mat,  4 );
    
        D3DXMatrixTranspose( &mat, &m_matWorld );
       	m_pd3dDevice->SetVertexShaderConstant(  18, &mat,  4 );

        
		//c0 -  Common Const (0, 0.5, 1, 0.25)
		//c1 - highlightColor (0.8, 0.76, 0.62, 1)

		D3DXVECTOR4 c0p( 0.0f, 0.5f, 1.0f, 0.25f);
		D3DXVECTOR4 c1p( 0.8f, 0.76f, 0.62f, 1.0f);
	
		m_pd3dDevice->SetPixelShaderConstant(  0, c0p,  1 );
		m_pd3dDevice->SetPixelShaderConstant(  1, c1p,  1 );
	
    }
    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    // Clear the viewport
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000080, 1.0f, 0L );

    // Begin the scene 
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {	
        
		// Draw the Sky Box
		D3DXMATRIX mat;
		D3DXMatrixIdentity( &mat);
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &mat );
		m_pd3dDevice->SetTexture(0, m_pCubeTex);

		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,
                                   D3DTSS_TCI_CAMERASPACENORMAL | 1); 

		m_pd3dDevice->SetVertexShader( D3DFVF_VERTEX );
	   	m_pd3dDevice->SetStreamSource( 0, m_pSkyBoxVertBuff, sizeof(VERTEX) );
        m_pd3dDevice->SetIndices( m_pSkyBoxIndxBuff, 0 );		
		m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 8,
                                            0, 12 );

		// Restore state to draw ocean
		m_pd3dDevice->SetTexture(2, m_pCubeTex);
		m_pd3dDevice->SetTexture(0, m_psBumpMap);
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matWorld );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0); 
                               

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, m_bZBuffer );
		if (m_bVertexShader) 
		    m_pd3dDevice->SetVertexShader( m_dwVShader );
		else	
  			m_pd3dDevice->SetVertexShader( D3DFVF_VERTEX );

        if (m_bPixelShader) 
			m_pd3dDevice->SetPixelShader( m_dwPShader );

		
		m_pd3dDevice->SetStreamSource( 0, m_pVertBuff, sizeof(VERTEX) );
        m_pd3dDevice->SetIndices( m_pIndxBuff, 0 );		
		m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, m_dwNumVerts,
                                            0, m_dwNumFaces );


        // Show frame rate
        m_pStatsFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), m_strFrameStats );
        m_pStatsFont->DrawText( 2, 20, D3DCOLOR_ARGB(255,255,255,0), m_strDeviceStats );


		 if( m_bShowHelp )
        {
            m_pSmallFont->DrawText(  2, 40, D3DCOLOR_ARGB(255,255,255,255),
                                    _T("Keyboard controls:") );
            m_pSmallFont->DrawText( 20, 60, D3DCOLOR_ARGB(255,255,255,255),
                                    _T("Help\nChange device\nExit") );
            m_pSmallFont->DrawText( 210, 60, D3DCOLOR_ARGB(255,255,255,255),
                                     _T("F1\nF2\nEsc") );
        }
        else
        {
            m_pSmallFont->DrawText(  2, 40, D3DCOLOR_ARGB(255,255,255,255), 
                               _T("Press F1 for help") );
        }


        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitBumpMap()
// Desc: Converts data from m_pHeightTex into m_psBumpMap.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitBumpMap()
{
    LPDIRECT3DTEXTURE8 psBumpSrc = m_pHeightTex;
    D3DSURFACE_DESC    d3dsd;
    D3DLOCKED_RECT     d3dlr;

    psBumpSrc->GetLevelDesc( 0, &d3dsd );
    // Create the bumpmap's surface and texture objects
    if( FAILED( m_pd3dDevice->CreateTexture( d3dsd.Width, d3dsd.Height, 1, 0, 
        D3DFMT_V8U8, D3DPOOL_MANAGED, &m_psBumpMap ) ) )
    {
        return E_FAIL;
    }

    // Fill the bits of the new texture surface with bits from
    // a private format.
    psBumpSrc->LockRect( 0, &d3dlr, 0, 0 );
    DWORD dwSrcPitch = (DWORD)d3dlr.Pitch;
    BYTE* pSrcTopRow = (BYTE*)d3dlr.pBits;
    BYTE* pSrcCurRow = pSrcTopRow;
    BYTE* pSrcBotRow = pSrcTopRow + (dwSrcPitch * (d3dsd.Height - 1) );

    m_psBumpMap->LockRect( 0, &d3dlr, 0, 0 );
    DWORD dwDstPitch = (DWORD)d3dlr.Pitch;
    BYTE* pDstTopRow = (BYTE*)d3dlr.pBits;
    BYTE* pDstCurRow = pDstTopRow;
    BYTE* pDstBotRow = pDstTopRow + (dwDstPitch * (d3dsd.Height - 1) );

    for( DWORD y=0; y<d3dsd.Height; y++ )
    {
        BYTE* pSrcB0; // addr of current pixel
        BYTE* pSrcB1; // addr of pixel below current pixel, wrapping to top if necessary
        BYTE* pSrcB2; // addr of pixel above current pixel, wrapping to bottom if necessary
        BYTE* pDstT;  // addr of dest pixel;

        pSrcB0 = pSrcCurRow;

        if( y == d3dsd.Height - 1)
            pSrcB1 = pSrcTopRow;
        else
            pSrcB1 = pSrcCurRow + dwSrcPitch;

        if( y == 0 )
            pSrcB2 = pSrcBotRow;
        else
            pSrcB2 = pSrcCurRow - dwSrcPitch;

        pDstT = pDstCurRow;

        for( DWORD x=0; x<d3dsd.Width; x++ )
        {
            LONG v00; // Current pixel
            LONG v01; // Pixel to the right of current pixel, wrapping to left edge if necessary
            LONG vM1; // Pixel to the left of current pixel, wrapping to right edge if necessary
            LONG v10; // Pixel one line below.
            LONG v1M; // Pixel one line above.

            v00 = *(pSrcB0+0);
            
            if( x == d3dsd.Width - 1 )
                v01 = *(pSrcCurRow);
            else
                v01 = *(pSrcB0+4);
            
            if( x == 0 )
                vM1 = *(pSrcCurRow + (4 * (d3dsd.Width - 1)));
            else
                vM1 = *(pSrcB0-4);
            v10 = *(pSrcB1+0);
            v1M = *(pSrcB2+0);

            LONG iDu = (vM1-v01); // The delta-u bump value
            LONG iDv = (v1M-v10); // The delta-v bump value
 
       
            *pDstT++ = (BYTE)(iDu / 2);
            *pDstT++ = (BYTE)(iDv / 2);
                   

            // Move one pixel to the right (src is 32-bpp)
            pSrcB0+=4;
            pSrcB1+=4;
            pSrcB2+=4;
        }

        // Move to the next line
        pSrcCurRow += dwSrcPitch;
        pDstCurRow += dwDstPitch;
    }

    m_psBumpMap->UnlockRect(0);
    psBumpSrc->UnlockRect(0);

    return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
	
	HRESULT hr;

	hr = D3DXCreateTextureFromFile(m_pd3dDevice, "media\\oceangradient.bmp", &m_pTex);
	if (FAILED(hr))
		return hr;
    
	hr = D3DXCreateTextureFromFile(m_pd3dDevice, "media\\Waterbump3.bmp", &m_pHeightTex);
	if (FAILED(hr))
		return hr;
    
	hr = D3DXCreateCubeTextureFromFile(m_pd3dDevice,"media\\ocean6.dds", &m_pCubeTex);
	if (FAILED(hr))
		return hr;
    

    m_pStatsFont->InitDeviceObjects( m_pd3dDevice );
    m_pSmallFont->InitDeviceObjects( m_pd3dDevice );


	// Create and fill the bumpmap
    if( FAILED( InitBumpMap() ) )
        return E_FAIL;


    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Initialize scene objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    m_pStatsFont->RestoreDeviceObjects();
    m_pSmallFont->RestoreDeviceObjects();

	
 	m_pd3dDevice->SetTexture(0, m_psBumpMap);
 	m_pd3dDevice->SetTexture(1, m_psBumpMap);
 
	m_pd3dDevice->SetTexture(2, m_pCubeTex);
	m_pd3dDevice->SetTexture(3, m_pTex);

 	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
 	m_pd3dDevice->SetTextureStageState( 1, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
 	m_pd3dDevice->SetTextureStageState( 2, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 2, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
 	m_pd3dDevice->SetTextureStageState( 3, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetTextureStageState( 3, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );


	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );


	m_fCamXPos = 0.0f;
	m_fCamYPos = 0.0f;
	m_fCamZPos = -20.0f;
	m_fXCenter = 0.0f;
	m_fYCenter = 0.0f;
	m_fZCenter = 0.0f;

    // Set the transform matrices
    D3DXVECTOR3 vEyePt    = D3DXVECTOR3( m_fCamXPos, m_fCamYPos, m_fCamZPos );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( m_fXCenter, m_fYCenter, m_fZCenter );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f,  0.0f );
    

    D3DXMatrixIdentity( &m_matWorld );
    D3DXMatrixLookAtLH( &m_matView, &vEyePt, &vLookatPt, &vUpVec );
    FLOAT fAspect = m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_matProj, D3DX_PI/2, fAspect, 1.0f, 1000.0f );

    m_pd3dDevice->SetTransform( D3DTS_WORLD,      &m_matWorld );
    m_pd3dDevice->SetTransform( D3DTS_VIEW,       &m_matView );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_matProj );

		
	D3DXMATRIX mat;
	D3DXMatrixIdentity( &m_matInitial);
    D3DXMatrixRotationX( &mat, D3DX_PI * 1.5f);
    D3DXMatrixMultiply( &m_matInitial, &m_matInitial, &mat );
    D3DXMatrixTranslation( &mat, 0.0f, -1.5f, -10.0f);
    D3DXMatrixMultiply( &m_matInitial, &m_matInitial, &mat );

	float radius = 20;
	int hres = 120;
	int vres = 40;

	m_dwNumFaces = hres * vres * 2;
	m_dwNumVerts = (hres + 1) * (vres + 1);


	HRESULT hr;
	// Create index buffer
    {
        WORD* pIndices;

        if( FAILED( hr = m_pd3dDevice->CreateIndexBuffer( m_dwNumFaces*sizeof(WORD)*3,
                                                          D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                                          D3DPOOL_DEFAULT, &m_pIndxBuff ) ) )
            return hr;

        if( FAILED( hr = m_pIndxBuff->Lock( 0, m_dwNumFaces*sizeof(WORD)*3, (BYTE**)&pIndices, 0 ) ) )
            return hr;

		
	
		int i;
		for (i = 0; i < hres; i++)
			for (int j = 0; j < vres; j++)
			{
				*pIndices++ = (WORD) (i      * (vres + 1) + j    );
				*pIndices++ = (WORD) ((i + 1)* (vres + 1) + j + 1);
	            *pIndices++ = (WORD) (i      * (vres + 1) + j + 1);
			
				*pIndices++ = (WORD) (i      * (vres + 1) + j    );
				*pIndices++ = (WORD) ((i + 1)* (vres + 1) + j    );
                *pIndices++ = (WORD) ((i + 1)* (vres + 1) + j + 1);
				
			}
    
	
		
        if( FAILED( hr = m_pIndxBuff->Unlock() ) )
            return hr;
    }

	float xmin = -30.0f;
	float xmax =  30.0f;
	float ymin = -10.0f;
	float ymax =  10.0f;

    // Create vertex buffer
    {
        VERTEX *pVertices;

        if( FAILED( hr = m_pd3dDevice->CreateVertexBuffer( m_dwNumVerts*sizeof(VERTEX),
                                                           D3DUSAGE_WRITEONLY, 0,
                                                           D3DPOOL_DEFAULT, &m_pVertBuff ) ) )
            return hr;

        if( FAILED( hr = m_pVertBuff->Lock( 0, m_dwNumVerts*sizeof(VERTEX), (BYTE**)&pVertices, 0 ) ) )
            return hr;

      
	
		for (int i = 0; i <= hres; i++)
			for (int j = 0; j <= vres; j++)
			{
				float ii = i/(float)hres;
				float jj = j/(float)vres;

				pVertices->n[0] = 0.0f;
				pVertices->n[1] = 0.0f;
				pVertices->n[2] = -1.0f;
				pVertices->t[0] = 0.0f;
				pVertices->t[1] = 1.0f;
				pVertices->t[2] = 0.0f;
				pVertices->p[0] = xmin + ii * (xmax - xmin);
				pVertices->p[1] = ymin + jj * (ymax - ymin);;
				pVertices->p[2] = 0.0f;
				pVertices->tu1 = ii;
				pVertices->tv1 = jj;

				pVertices->p2[0] = (float)(2.0f * max(fabs(ii - 0.5f), fabs(jj - 0.5f)));
			
				pVertices++;	
			}

        if( FAILED( hr = m_pVertBuff->Unlock() ) )
            return hr;
    }

	// Create SkyBox index buffer
    {
        WORD* pIndices;

        if( FAILED( hr = m_pd3dDevice->CreateIndexBuffer( 12*sizeof(WORD)*3,
                                                          D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                                          D3DPOOL_DEFAULT, &m_pSkyBoxIndxBuff ) ) )
            return hr;

        if( FAILED( hr = m_pSkyBoxIndxBuff->Lock( 0, 12*sizeof(WORD)*3, (BYTE**)&pIndices, 0 ) ) )
            return hr;

		
	
		*pIndices++ = 0; *pIndices++ = 6; *pIndices++ = 2; 
		*pIndices++ = 0; *pIndices++ = 4; *pIndices++ = 6; 
		*pIndices++ = 1; *pIndices++ = 3; *pIndices++ = 7; 
		*pIndices++ = 1; *pIndices++ = 7; *pIndices++ = 5; 
		*pIndices++ = 0; *pIndices++ = 2; *pIndices++ = 3; 
		*pIndices++ = 0; *pIndices++ = 3; *pIndices++ = 1; 
		*pIndices++ = 4; *pIndices++ = 7; *pIndices++ = 6; 
		*pIndices++ = 4; *pIndices++ = 5; *pIndices++ = 7; 
		*pIndices++ = 2; *pIndices++ = 7; *pIndices++ = 3; 
		*pIndices++ = 2; *pIndices++ = 6; *pIndices++ = 7; 
		*pIndices++ = 0; *pIndices++ = 1; *pIndices++ = 4; 
		*pIndices++ = 4; *pIndices++ = 1; *pIndices++ = 5; 
	
		
        if( FAILED( hr = m_pSkyBoxIndxBuff->Unlock() ) )
            return hr;
    }


    // Create SkyBox vertex buffer
    {
        VERTEX *pVertices;

        if( FAILED( hr = m_pd3dDevice->CreateVertexBuffer( 8*sizeof(VERTEX),
                                                           D3DUSAGE_WRITEONLY, 0,
                                                           D3DPOOL_DEFAULT, &m_pSkyBoxVertBuff ) ) )
            return hr;

        if( FAILED( hr = m_pSkyBoxVertBuff->Lock( 0, 8*sizeof(VERTEX), (BYTE**)&pVertices, 0 ) ) )
            return hr;

      
		radius = 80;
		for (int i = 0; i <= 1; i++)
			for (int j = 0; j <= 1; j++)
				for (int k = 0; k <= 1; k++)
				{
					float x = (float)(i * 2 - 1);
					float y = (float)(j * 2 - 1);
					float z = (float)(k * 2 - 1);
			
					pVertices->n[0] = x;
					pVertices->n[1] = y;
					pVertices->n[2] = z;
					pVertices->p[0] = x * radius;
					pVertices->p[1] = y * radius;
					pVertices->p[2] = z * radius - 40.0f;
			
				pVertices++;	
			}

        if( FAILED( hr = m_pSkyBoxVertBuff->Unlock() ) )
            return hr;
    }

	// Create vertex shader
    {
        LPD3DXBUFFER pCode;

        // Assemble the vertex shader from the file
        if( FAILED( hr = D3DXAssembleShaderFromFile( "shaders\\OceanWater.vsh", 
                                                     0, NULL, &pCode, NULL ) ) )
            return hr;

        // Create the vertex shader
        hr = m_pd3dDevice->CreateVertexShader( dwVertexDecl, (DWORD*)pCode->GetBufferPointer(),
                                               &m_dwVShader, 0 );
        pCode->Release();
        if( FAILED(hr) )
            return hr;
    }

	// Create pixel shader
    {
        LPD3DXBUFFER pCode;

        // Assemble the pixel shader from the file
        if( FAILED( hr = D3DXAssembleShaderFromFile( "shaders\\OceanWater.psh", 
                                                     0, NULL, &pCode, NULL ) ) )
            return hr;

        // Create the pixel shader
        hr = m_pd3dDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(),
                                              &m_dwPShader);
        pCode->Release();
        if( FAILED(hr) )
            return hr;
    }

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
 	SAFE_RELEASE( m_pVertBuff );
	SAFE_RELEASE( m_pIndxBuff );
 	SAFE_RELEASE( m_pSkyBoxVertBuff );
	SAFE_RELEASE( m_pSkyBoxIndxBuff );
	m_pd3dDevice->DeleteVertexShader( m_dwVShader );
	m_pd3dDevice->DeletePixelShader( m_dwPShader );
	m_pStatsFont->InvalidateDeviceObjects();
	m_pSmallFont->InvalidateDeviceObjects();

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	SAFE_RELEASE( m_pVertBuff );
	SAFE_RELEASE( m_pIndxBuff );
	SAFE_RELEASE( m_pSkyBoxVertBuff );
	SAFE_RELEASE( m_pSkyBoxIndxBuff );
	m_pd3dDevice->SetTexture(0, NULL);
	m_pd3dDevice->SetTexture(1, NULL);
	SAFE_RELEASE( m_pTex );
	SAFE_RELEASE( m_pHeightTex );
	SAFE_RELEASE( m_psBumpMap );
	SAFE_RELEASE( m_pCubeTex );

    m_pStatsFont->DeleteDeviceObjects();
    m_pSmallFont->DeleteDeviceObjects();
 
   return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pStatsFont );
	SAFE_DELETE( m_pSmallFont );


    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam,
                                    LPARAM lParam )
{
  	// Trap context menu
    if( WM_CONTEXTMENU == uMsg )
        return 0;

	// Perform commands when keys are released
    if( WM_KEYUP == uMsg )
    {
        switch( wParam )
        {
        case VK_F1:
            m_bShowHelp = !m_bShowHelp;
            break;
        }
    }

    return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}

