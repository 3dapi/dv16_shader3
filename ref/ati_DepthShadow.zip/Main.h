// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DVERTEXSHADER9				PDVS;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	LPD3DXEFFECT						PDEF;



#define SHADOW_MAP_SIZE   1024


#define DEPTH_RANGE 5.0f

struct VtxRHWUV
{
    D3DXVECTOR4 p;
    FLOAT       u, v;

	VtxRHWUV() :p(0,0,0,1), u(0), v(0){}
	VtxRHWUV(FLOAT X,FLOAT Y,FLOAT U,FLOAT V) :p(X,Y,0,1), u(U), v(V){}
	enum { FVF = (D3DFVF_XYZRHW | D3DFVF_TEX1),};
};


struct VtxNUV
{
    D3DXVECTOR3 p;
    D3DXVECTOR3 n;
    FLOAT       tu, tv;

	enum { FVF = (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1),};
};


class CMain : public CD3DApplication
{
protected:
	ID3DXFont*				m_pD3DXFont;            // D3DX font

	
	CD3DArcBall				m_ArcBall;

    D3DXMATRIX              m_matModelMVP;
    D3DXMATRIX              m_matShadowModelMVP;
    D3DXMATRIX              m_matShadowModelTex;

    D3DXMATRIX              m_matFloorMVP;
    D3DXMATRIX              m_matShadowFloorMVP;
    D3DXMATRIX              m_matShadowFloorTex;

	D3DXVECTOR4				m_vecLightDirModel;
	D3DXVECTOR4				m_vecLightDirFloor;

	// Model
    LPDIRECT3DVERTEXBUFFER9	m_pModelVB;
    LPDIRECT3DINDEXBUFFER9  m_pModelIB;
    DWORD                   m_dwModelNumVerts;
    DWORD                   m_dwModelNumFaces;
    LPDIRECT3DVERTEXBUFFER9	m_pFloorVB;
	FLOAT					m_fModelSize;


	D3DVIEWPORT9	m_vpShadow;
	IrenderTarget*	m_pTrnd;	// Shadow map

	// Shaders
	PDVD			m_pFVF;
	PDEF			m_pEft;
	


public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

    HRESULT RenderText();

public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);


protected:
	HRESULT RenderShadowMap();
	HRESULT RenderScene();
	HRESULT RenderOverlay();
};


extern CMain* g_pApp;

#endif



