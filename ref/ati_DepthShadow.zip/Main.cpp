// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth			= 800;
	m_dwCreationHeight			=  (m_dwCreationWidth*3) /4;
	strcpy(m_strClassName, TEXT( "McShd"));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pD3DXFont	= NULL;

	m_pModelVB	= NULL;
	m_pModelIB	= NULL;
	m_pFloorVB	= NULL;
	
	m_pTrnd		= NULL;
	m_pEft		= NULL;
	m_pFVF		= NULL;
}



HRESULT CMain::Init()
{
	HRESULT hr=-1;

	// Create a D3D font using D3DX
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;



	LPDIRECT3DVERTEXBUFFER9 pMeshSrcVB;
	LPDIRECT3DINDEXBUFFER9  pMeshSrcIB;
	VtxNUV*					pSrc;
	VtxNUV*					pDst;
	CD3DMesh                Mesh;
	FLOAT					fModelRad;
	
	
	// Load model
	if (FAILED(Mesh.Create(m_pd3dDevice, _T("xFile/star.x"))))
		return -1;
	
	// Fix vertex contents
	Mesh.SetFVF(m_pd3dDevice, D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1);
	
	// Create model VB
	m_dwModelNumVerts = Mesh.GetSysMemMesh()->GetNumVertices();
	m_pd3dDevice->CreateVertexBuffer(m_dwModelNumVerts * sizeof(VtxNUV), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &m_pModelVB, NULL);
	
	// Copy vertices and compute bounding sphere
	Mesh.GetSysMemMesh()->GetVertexBuffer(&pMeshSrcVB);
	pMeshSrcVB->Lock(0, 0, (void**)&pSrc, 0);
	m_pModelVB->Lock(0, 0, (void**)&pDst, 0);
	memcpy(pDst, pSrc, m_dwModelNumVerts * sizeof(VtxNUV));
	D3DXVECTOR3 vecModelCenter;
	D3DXComputeBoundingSphere(&pSrc->p, m_dwModelNumVerts, sizeof(VtxNUV), &vecModelCenter, &fModelRad);
	m_pModelVB->Unlock();
	pMeshSrcVB->Unlock();
	pMeshSrcVB->Release();
	
	m_fModelSize = fModelRad * 2.2f;
	
	// Create model IB
	m_dwModelNumFaces = Mesh.GetSysMemMesh()->GetNumFaces();
	m_pd3dDevice->CreateIndexBuffer(m_dwModelNumFaces * 3 * sizeof(WORD), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pModelIB, NULL);
	
	// Copy indices
	Mesh.GetSysMemMesh()->GetIndexBuffer(&pMeshSrcIB);
	pMeshSrcIB->Lock(0, 0, (void**)&pSrc, 0);
	m_pModelIB->Lock(0, 0, (void**)&pDst, 0);
	memcpy(pDst, pSrc, 3 * m_dwModelNumFaces * sizeof(WORD));
	m_pModelIB->Unlock();
	pMeshSrcIB->Unlock();
	pMeshSrcIB->Release();
	
	// Create floor VB
	m_pd3dDevice->CreateVertexBuffer(4 * sizeof(VtxNUV), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &m_pFloorVB, NULL);
	m_pFloorVB->Lock(0, 0, (void**)&pDst, 0);

	float	fWidth = 10;
	pDst[0].p = D3DXVECTOR3(-fWidth, 0.0f, fWidth);
	pDst[0].n = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	pDst[0].tu = 0.0f;
	pDst[0].tv = 1.0f;
	pDst[1].p = D3DXVECTOR3(fWidth, 0.0f, fWidth);
	pDst[1].n = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	pDst[1].tu = 1.0f;
	pDst[1].tv = 1.0f;
	pDst[2].p = D3DXVECTOR3(-fWidth, 0.0f, -fWidth);
	pDst[2].n = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	pDst[2].tu = 0.0f;
	pDst[2].tv = 0.0f;
	pDst[3].p = D3DXVECTOR3(fWidth, 0.0f, -fWidth);
	pDst[3].n = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	pDst[3].tu = 1.0f;
	pDst[3].tv = 0.0f;
	m_pFloorVB->Unlock();
	
	
	D3DVERTEXELEMENT9 decl[MAX_FVF_DECL_SIZE] ={0};
	D3DXDeclaratorFromFVF(VtxNUV::FVF, decl);
	
	// Create shader declaration
	if (FAILED(m_pd3dDevice->CreateVertexDeclaration(decl, &m_pFVF)))
		return E_FAIL;
	
	
	LPD3DXBUFFER pErr= NULL;

	
	hr = D3DXCreateEffectFromFile(	m_pd3dDevice
		,	"data/shader.fx"
		,	NULL
		,	NULL
		,	0
		,	NULL
		,	&m_pEft, &pErr);
	if (FAILED(hr))
	{
		char* sErr = (char*)pErr->GetBufferPointer();
		MessageBox(m_hWnd, sErr, "Err", MB_ICONWARNING);
		pErr->Release();
	}
	
	
	
	// Setup shadow map viewport
	m_vpShadow.X = 0;
	m_vpShadow.Y = 0;
	m_vpShadow.Width  = SHADOW_MAP_SIZE;
	m_vpShadow.Height = SHADOW_MAP_SIZE;
	m_vpShadow.MinZ = 0.0f;
	m_vpShadow.MaxZ = 1.0f;
	
	if(FAILED(LcD3D_CreateRenderTarget("R32", &m_pTrnd, m_pd3dDevice, SHADOW_MAP_SIZE, SHADOW_MAP_SIZE)))
		return -1;
	
	return S_OK;
}



HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);

	SAFE_DELETE(	m_pTrnd	);
	
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF		);
	
	SAFE_RELEASE(	m_pModelVB	);
	SAFE_RELEASE(	m_pModelIB	);
	SAFE_RELEASE(	m_pFloorVB	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();
	
	m_pEft->OnResetDevice();
	
	m_pEft->OnResetDevice();
	
	m_pTrnd->OnResetDevice();
	
	
	m_ArcBall.SetWindow(m_d3dsdBackBuffer.Width, m_d3dsdBackBuffer.Height, 1.0f);
	m_ArcBall.SetRadius(3.0f);
	m_ArcBall.SetRightHanded(TRUE);

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	m_pEft->OnLostDevice();
	
	m_pTrnd->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	HRESULT hr = 0;
	// UpdateTransform
	
	// Model offset
	D3DXVECTOR3 vModelOffs = D3DXVECTOR3(0.0f, 2.0f, 0.0f);
	
	// Set the transform matrices
	D3DXVECTOR3 vEyePt      = D3DXVECTOR3(0.0f, 3.0f, -4.0f);
	D3DXVECTOR3 vLookatPt   = D3DXVECTOR3(0.0f, 2.0f,  0.0f);
	D3DXVECTOR3 vUpVec      = D3DXVECTOR3(0.0f, 1.0f,  0.0f);
	FLOAT       fAspect = (FLOAT)m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
	
	D3DXMATRIX matWorldModel, matWorldFloor, matView, matProj, mat;
	D3DXMATRIX matShadowView, matShadowProj, mat2;
	
	D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
	D3DXMatrixPerspectiveFovLH(&matProj, D3DX_PI / 3, fAspect, 1.0f, 5000.0f);
	
	
	mat = matView * matProj;
	
	
	D3DXMATRIX matTranslate;
	D3DXMatrixTranslation(&matTranslate, vModelOffs.x, vModelOffs.y, vModelOffs.z);
	
	matWorldModel = *(m_ArcBall.GetRotationMatrix()) * matTranslate;
	m_matModelMVP = matWorldModel * mat;
	
	D3DXMatrixIdentity(&matWorldFloor);
	
	m_matFloorMVP = matWorldFloor * mat;
	
	
	// Light direction
	D3DXVECTOR3 vLightDir = D3DXVECTOR3(2.0f, 1.0f, -1.0f);
	D3DXVec3Normalize(&vLightDir, &vLightDir);
	
	// Setup shadow map transform
	vLookatPt = vModelOffs;
	vEyePt = vLookatPt + vLightDir * (m_fModelSize / 2.0f);
	D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
	
	// Projection for directional light
	D3DXMatrixOrthoLH(&matProj, 5.0f, 5.0f, 0.0f, DEPTH_RANGE);
	
	mat = matView * matProj;
	
	m_matShadowModelMVP = matWorldModel * mat;
	m_matShadowFloorMVP = matWorldFloor * mat;
	
	
	// Texture adjustment matrix
	FLOAT fTexelOffs = (0.5f / SHADOW_MAP_SIZE);

	D3DXMATRIX matTexAdj =D3DXMATRIX(
		0.5f,      0.0f,        0.0f,        0.0f,
		0.0f,     -0.5f,        0.0f,        0.0f,
		0.0f,      0.0f,        0.0f,        0.0f,
		0.5f + fTexelOffs,	0.5f + fTexelOffs,		1.0f,        1.0f);
	
	
	
	m_matShadowModelTex = m_matShadowModelMVP * matTexAdj;
	m_matShadowFloorTex = m_matShadowFloorMVP * matTexAdj;
	
	// Setup lighting -- transform into model space
	D3DXVECTOR3 v;
	D3DXMatrixInverse(&mat, NULL, &matWorldModel);
	D3DXVec3TransformNormal(&v, &vLightDir, &mat);
	D3DXVec3Normalize(&v, &v);
	m_vecLightDirModel = D3DXVECTOR4(v.x, v.y, v.z, 0.0f);
	
	D3DXMatrixInverse(&mat, NULL, &matWorldFloor);
	D3DXVec3TransformNormal(&v, &vLightDir, &mat);
	D3DXVec3Normalize(&v, &v);
	m_vecLightDirFloor = D3DXVECTOR4(v.x, v.y, v.z, 0.0f);
	
	
	
	
	// Setup Shadow Map
	RenderShadowMap();
	

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	// Begin the scene
	if (FAILED(m_pd3dDevice->BeginScene()))
		return -1;
	
	
	RenderScene();
	RenderOverlay();



	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}




HRESULT CMain::RenderShadowMap()
{
	D3DVIEWPORT9 oldViewport;
	m_pd3dDevice->GetViewport(&oldViewport);
	
	
	m_pd3dDevice->SetViewport(&m_vpShadow);
	
	m_pTrnd->BeginScene();
	// Clear viewport
	m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0L);
	
	// Set shadow map shader
	m_pd3dDevice->SetVertexDeclaration(m_pFVF);
	m_pEft->SetTechnique("Tech");
	m_pEft->Begin(NULL, 0);
	m_pEft->Pass(1);
	
	
	D3DXVECTOR4	vRange = D3DXVECTOR4(1.0f / DEPTH_RANGE, 0.0f, 0.0f, 0.0f);
	m_pEft->SetVector("m_vcRange", &vRange);
	
	// Render model
	m_pEft->SetMatrix("m_mtWVP", &m_matShadowModelMVP);
	
	m_pd3dDevice->SetStreamSource(0, m_pModelVB, 0, sizeof(VtxNUV));
	m_pd3dDevice->SetIndices(m_pModelIB);
	m_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_dwModelNumVerts, 0, m_dwModelNumFaces);
	
	//Render floor
	m_pEft->SetMatrix("m_mtWVP", &m_matShadowFloorMVP);
	
	m_pd3dDevice->SetStreamSource(0, m_pFloorVB, 0, sizeof(VtxNUV));
	m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
	
	m_pEft->End();
	
	m_pd3dDevice->SetVertexDeclaration(NULL);
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(NULL);
	
	// Restore old render target
	m_pTrnd->EndScene();
	
	m_pd3dDevice->SetViewport(&oldViewport);
	
	return S_OK;
}


HRESULT CMain::RenderScene()
{
	D3DXVECTOR4 vDiffuseFloor(0.75f, 0.75f, 0.75f, 1.0f);
	D3DXVECTOR4 vDiffuseModel(1.0f, 1.0f, 1.0f, 1.0f);
	
	LPDIRECT3DTEXTURE9	pTx = (LPDIRECT3DTEXTURE9)m_pTrnd->GetTexture();
	m_pd3dDevice->SetTexture(0, pTx);
	
	
	m_pd3dDevice->SetVertexDeclaration(m_pFVF);
	m_pEft->SetTechnique("Tech");
	m_pEft->Begin(NULL, 0);
	m_pEft->Pass(0);
	
	
	m_pEft->SetVector("m_vcColor", &vDiffuseModel);
	
	D3DXVECTOR4	vZBias = D3DXVECTOR4(0.1f, -0.01f, 1.0f, 0.0f);
	m_pEft->SetVector("m_vcZbias", &vZBias);
	
	float	fRange = 1.0f / DEPTH_RANGE;
	m_pEft->SetFloat("m_fRange", fRange);
		
	// Render floor
	m_pEft->SetMatrix("m_mtWVP"		, &m_matFloorMVP);
	m_pEft->SetMatrix("m_mtWLP"		, &m_matShadowFloorMVP);
	m_pEft->SetMatrix("m_mtSPX"		, &m_matShadowFloorTex);
	m_pEft->SetVector("m_vcLight"	, &m_vecLightDirFloor);
	m_pEft->SetVector("m_vcColor"	, &vDiffuseFloor);
	
	m_pd3dDevice->SetStreamSource(0, m_pFloorVB, 0, sizeof(VtxNUV));
	m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
	
	// Render model
	m_pEft->SetMatrix("m_mtWVP"		, &m_matModelMVP);
	m_pEft->SetMatrix("m_mtWLP"		, &m_matShadowModelMVP);
	m_pEft->SetMatrix("m_mtSPX"		, &m_matShadowModelTex);
	m_pEft->SetVector("m_vcLight"	, &m_vecLightDirModel);
	m_pEft->SetVector("m_vcColor"	, &vDiffuseModel);
	
	
	m_pd3dDevice->SetStreamSource(0, m_pModelVB, 0, sizeof(VtxNUV));
	m_pd3dDevice->SetIndices(m_pModelIB);
	m_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_dwModelNumVerts, 0, m_dwModelNumFaces);
	
	m_pd3dDevice->SetTexture(0, NULL);
	
	m_pEft->End();
	
	m_pd3dDevice->SetVertexDeclaration(NULL);
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(NULL);
	
	return S_OK;
}


HRESULT CMain::RenderOverlay()
{
	LPDIRECT3DTEXTURE9	pTx = (LPDIRECT3DTEXTURE9)m_pTrnd->GetTexture();

	// Shadow Map ȭ�� ���
	VtxRHWUV	pVtx[4];
	float		fOVERLAY_SIZE	= 256;

	pVtx[0] = VtxRHWUV(4.5f               ,                4.5f,  0, 0);
	pVtx[1] = VtxRHWUV(4.5f +fOVERLAY_SIZE,                4.5f,  1, 0);
	pVtx[2] = VtxRHWUV(4.5f +fOVERLAY_SIZE, 4.5f +fOVERLAY_SIZE,  1, 1);
	pVtx[3] = VtxRHWUV(4.5f               , 4.5f +fOVERLAY_SIZE,  0, 1);

	m_pd3dDevice->SetFVF(VtxRHWUV::FVF);
	
	m_pEft->SetTechnique("Tech");
	m_pEft->Begin(NULL, 0);
	m_pEft->Pass(2);
	
	m_pd3dDevice->SetTexture(0, pTx);
	m_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxRHWUV));
	m_pd3dDevice->SetTexture(0, NULL);
	
	m_pEft->End();

	
	m_pd3dDevice->SetVertexDeclaration(NULL);
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(NULL);
	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	RECT rct={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );

	

	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	m_ArcBall.HandleMouseMessages(hWnd, uMsg, wParam, lParam);

	
	switch( uMsg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rct;
				GetClientRect( hWnd, &rct );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}





