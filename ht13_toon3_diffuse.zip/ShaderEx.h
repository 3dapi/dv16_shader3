// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxNUV1
	{
		VEC3	p;
		VEC3	n;
		FLOAT	u, v;

		VtxNUV1()						: p(0,0,0),n(0,0,0),u(0),v(0){}
		VtxNUV1(	FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT NX, FLOAT NY, FLOAT NZ
				, FLOAT U, FLOAT V)	: p(X,Y,Z),n(NX,NY,NZ),u(U),v(V){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)	};
	};

public:
	PDEV		m_pDev;				// Device

	PDEF		m_pEft;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator

	MATA		m_mtWld;			// World Matrix
	MATA		m_mtRot;			// Rotation Matrix

	CMcMesh*	m_pMsh;
	PDTX		m_pTdf;				// Diffuse Texture
	PDTX		m_pTtn;				// Toon Texture


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

