// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef	D3DXVECTOR3											VEC3;
typedef D3DXVECTOR4											VEC4;
typedef D3DXMATRIX											MATA;

typedef LPDIRECT3DDEVICE9									PDEV;
typedef	LPD3DXEFFECT										PDEF;


class CShaderEx
{
public:
	PDEV		m_pDev;
	PDEF		m_pEft;				// ID3DXEffect Instance
	
	CMcMesh*	m_pMdl;
	CMcField*	m_pField;
	VEC3		m_vcMdl;			// Position of Mdl
	MATA		m_mtMdl;			// World Matrix of Mdl

	VEC4		m_vcLgt;			// Lighting Position
	MATA		m_mtLgV;			// View Matrix of Lighting
	MATA		m_mtLgP;			// Orthogonal Projection Matrix of Lighting

	IrenderTarget*	m_pTrnd;


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();

protected:
	void	RenderToShadowMap();
	void	RenderShadowTexture();
};

#endif


