// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


const int	SHADOW_MAP_SIZE = 1024;


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;

	m_pMdl		= NULL;
	m_pField	= NULL;
	m_pTrnd		= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_DELETE(	m_pField	);
	SAFE_DELETE(	m_pMdl		);
	SAFE_DELETE(	m_pTrnd		);
}



INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile(m_pDev
							,	"data/shader.fx"
							,	NULL
							,	NULL
							,	dwFlags
							,	NULL
							,	&m_pEft
							,	&pErr);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}




	// Load Model
	SAFE_NEWCREATE2(m_pMdl, CMcMesh, m_pDev, "data/EvilDrone-low.x");
	m_pMdl->SetFVF(D3DFVF_XYZ|D3DFVF_NORMAL);


	// Load Field Mesh
	SAFE_NEWCREATE1(m_pField,	CMcField, m_pDev	);


	// Create Rendering Target Texture
	if(FAILED(LcD3D_CreateRenderTarget("Shadow", &m_pTrnd, m_pDev, SHADOW_MAP_SIZE, SHADOW_MAP_SIZE)))
		return -1;

	return 0;
}


INT CShaderEx::FrameMove()
{
	// Setting World Matrix of Model
	FLOAT fTime = GetTickCount() *0.05F;

	MATA	mtScl;
	MATA	mtRot;

//	fTime = 35;
	fTime = D3DXToRadian(fTime);
	
	D3DXMatrixScaling(&mtScl, 6, 6, 6);
	D3DXMatrixRotationY(&mtRot, fTime * 2.1F);

	m_vcMdl.x = 2.5f*(FLOAT)cos(1.0f*fTime)+ .5f;
	m_vcMdl.z = 2.5f*(FLOAT)sin(1.0f*fTime)+ .5f;
	m_vcMdl.y = 2.5f;
	m_vcMdl *= 15;

	m_mtMdl = mtScl * mtRot;	
	m_mtMdl._41 = m_vcMdl.x;
	m_mtMdl._42 = m_vcMdl.y;
	m_mtMdl._43 = m_vcMdl.z;


	// Setting View and Projection Matrix with Lighting Position and Direction
	VEC3 vLook	= VEC3( 0.0F, 0.0F, 0.0F);
	VEC3 vUp	= VEC3( 0.0F, 1.0F, 0.0F);
	m_vcLgt		= VEC4( 60.0f, 50.0f, 60.0f, 0);
	D3DXMatrixLookAtLH(&m_mtLgV, (VEC3*)&m_vcLgt, &vLook, &vUp );
	D3DXMatrixOrthoLH(&m_mtLgP, 150, 150, 1, 180.0f );
	D3DXVec4Normalize(&m_vcLgt, &m_vcLgt);



	RenderToShadowMap();


	return 0;
}


void CShaderEx::Render()
{
	MATA	mtWld;
	MATA	mtViw;
	MATA	mtPrj;

	PDTX	pTex = (PDTX)m_pTrnd->GetTexture();

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pEft->SetTechnique( "Tech0" );

	m_pEft->SetMatrix( "m_mtViw", &mtViw );
	m_pEft->SetMatrix( "m_mtPrj", &mtPrj );
	m_pEft->SetMatrix( "m_mtSdV", &m_mtLgV);
	m_pEft->SetMatrix( "m_mtSdP", &m_mtLgP);
	
	m_pEft->SetVector( "m_vLght", &m_vcLgt);	// Lighting Vector
	
	m_pEft->SetTexture("m_TxShd", pTex);
	m_pEft->SetVector( "m_dDiff", &VEC4(1,1,1,1) );
	

	m_pEft->Begin(NULL, 0);
	
	// Map
	m_pEft->BeginPass(1);
		D3DXMatrixIdentity(&mtWld);
		m_pEft->SetMatrix( "m_mtWld", &mtWld );
		m_pField->Render();
	m_pEft->EndPass();


	// Mdl
	m_pEft->BeginPass(2);
		mtWld = m_mtMdl;
		m_pEft->SetMatrix( "m_mtWld", &mtWld);
		m_pMdl->Render();
	m_pEft->EndPass();

	m_pEft->End();


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);


	RenderShadowTexture();
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();
	m_pTrnd->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
	m_pTrnd->OnLostDevice();
}


void CShaderEx::RenderToShadowMap()
{
	MATA	mtWld;

	// Change Rendering Target and Draw Depth of Map and Model
	if(SUCCEEDED(m_pTrnd->BeginScene(D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF)))
	{
		m_pEft->SetTechnique("Tech0");

		m_pEft->SetMatrix("m_mtSdV", &m_mtLgV);
		m_pEft->SetMatrix("m_mtSdP", &m_mtLgP);

		
		m_pEft->Begin(NULL, 0);
		m_pEft->BeginPass(0);

			// Rendering Model
			mtWld = m_mtMdl;
			m_pEft->SetMatrix("m_mtWld", &mtWld);
			m_pMdl->Render();

			// Map
			D3DXMatrixIdentity(&mtWld);
			m_pEft->SetMatrix("m_mtWld",&mtWld);
			m_pField->Render();

		m_pEft->EndPass();
		m_pEft->End();

		
		m_pDev->SetVertexShader(NULL);
		m_pDev->SetPixelShader(NULL);


		// Restore Rendering Target of Device
		m_pTrnd->EndScene();
	}
}


void CShaderEx::RenderShadowTexture()
{
	// Depth Saved Texture
	PDTX pTex = (PDTX)m_pTrnd->GetTexture();

	float width = 240.0F;

	struct TvtxRhw
	{
		float x,y,z,w;
		float u,v;
	} Vertex[4]=
	{
		{    0,    0, 0, 1, 0, 0},
		{width,    0, 0, 1, 1, 0},
		{width,width, 0, 1, 1, 1},
		{    0,width, 0, 1, 0, 1},
	};

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTexture( 0, pTex );
	m_pDev->SetFVF(D3DFVF_XYZRHW|D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TvtxRhw) );
}


