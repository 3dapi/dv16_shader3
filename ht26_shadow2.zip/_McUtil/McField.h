// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

typedef	D3DXVECTOR3				VEC3;

typedef LPDIRECT3DDEVICE9		PDEV;
typedef LPDIRECT3DTEXTURE9		PDTX;

class CMcField
{
public:
	struct VtxNUV1
	{
		VEC3	p;
		VEC3	n;
		FLOAT	u0, v0;
		FLOAT	u1, v1;
		
		VtxNUV1() : p(0,0,0),n(0,0,0),u0(0),v0(0),u1(0),v1(0){}
		VtxNUV1(	FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT NX, FLOAT NY, FLOAT NZ
				, FLOAT U0, FLOAT V0
				, FLOAT U1, FLOAT V1) : p(X,Y,Z),n(NX,NY,NZ),u0(U0),v0(V0),u1(U1),v1(V1){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2)	};
	};

	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx()							{	a = 0;		 b = 1;		 c = 2;		}
		VtxIdx(WORD A, WORD B, WORD C)		{	a = A;		 b = B;		 c = C;		}
		VtxIdx(WORD* R)						{	a = R[0];	 b = R[1];	 c = R[2];	}

		operator WORD* ()					{		return (WORD *) &a;				}
		operator CONST WORD* () const		{		return (CONST WORD *) &a;		}
	};

protected:
	PDEV			m_pDev;
	INT				m_iN;														// Number of tile for Width
	FLOAT			m_fW;														// Width of tile for x;

	INT				m_iNvx;														// Vertex Number
	INT				m_iNix;														// Index Number
	INT				m_iVxS;														// Vertex Size
	DWORD			m_dFVF;


	VtxNUV1*		m_pVtx;
	VtxIdx*			m_pIdx;
	PDTX			m_pTx0;
	PDTX			m_pTx1;

	FLOAT			m_fAl;
	VEC3			m_vcLgt;

	
public:
	CMcField();
	virtual ~CMcField();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	FLOAT	GetHeight(VEC3& pos);
	
protected:
	void	NormalSet();
	VEC3	NormalVec(int z, int x);

	void	MapLoad();
};

#endif