// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	m_pTx0	= NULL;
	m_pTx1	= NULL;
	m_iNvx	= 0;
	m_iNix	= 0;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Create(PDEV pDev)
{
	m_pDev = pDev;

	m_fAl = 45;
	m_fW = 1.f;
	m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	
	//	Load texture
	D3DXCreateTextureFromFile(m_pDev, "Map/map.bmp", &m_pTx0);
	D3DXCreateTextureFromFile(m_pDev, "Map/detail5.jpg", &m_pTx1);


	MapLoad();

	
	return 0;
}


void CMcField::Destroy()
{
	
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pIdx	);
	
	SAFE_RELEASE(	m_pTx0	);
	SAFE_RELEASE(	m_pTx1	);
}


INT	CMcField::FrameMove()
{
	return 0;
}

void CMcField::Render()
{
//	m_light.Direction = m_vcLgt;

	m_pDev->SetTexture(0, m_pTx0);
	m_pDev->SetTexture(1, m_pTx1);
	m_pDev->SetFVF(m_dFVF);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNvx, m_iNix, m_pIdx, D3DFMT_INDEX16, m_pVtx, m_iVxS);
	
	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
}




FLOAT CMcField::GetHeight(VEC3& pos)
{
	INT	x;
	INT	z;

	x = INT(pos.x/m_fW);
	z = INT(pos.z/m_fW);

	INT index = m_iN*z + x;

	VEC3 pos0 = m_pVtx[index].p;
	VEC3 posX;
	VEC3 posZ;
	VEC3 posT;


	float dX = pos.x - pos0.x;
	float dZ = pos.z - pos0.z;

	if( (x+z)%2)			// Ȧ��
	{
		if(dZ >(m_fW-dX))			// ���� �ﰢ��
		{
			index += (m_iN+1);

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index-1].p;
			posZ = m_pVtx[index-m_iN].p;
		}

		else
		{
			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index+1].p;
			posZ = m_pVtx[index+m_iN].p;
		}
	}
	else					// ¦��
	{
		if(dZ > dX)			// ���� �ﰢ��
		{
			index += (m_iN);

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index+1].p;
			posZ = m_pVtx[index-m_iN].p;
		}

		else
		{
			index += 1;

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index-1].p;
			posZ = m_pVtx[index+m_iN].p;
		}
	}

	posT  = pos0 + (posX - pos0) * dX/m_fW + (posZ - pos0) * dZ/m_fW;


	return posT.y;
}


void CMcField::NormalSet()
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	
	for(INT z=0; z<m_iN; ++z)
	{
		for(INT x=0; x<m_iN; ++x)
		{
			m_pVtx[m_iN*z + x].n = -NormalVec(z, x);
		}
	}
}


VEC3 CMcField::NormalVec(int z, int x)
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	INT		i;

	INT		index = m_iN*z + x;
	INT		iVtx[10];

	iVtx[9] = index;
	iVtx[0] = iVtx[9];
	iVtx[1] = iVtx[9];
	iVtx[2] = iVtx[9];
	iVtx[3] = iVtx[9];
	iVtx[4] = iVtx[9];
	iVtx[5] = iVtx[9];
	iVtx[6] = iVtx[9];
	iVtx[7] = iVtx[9];
	iVtx[8] = iVtx[9];
	
	if(0==z && 0==x)
	{
		iVtx[0] = iVtx[9] + 1;
		iVtx[1] = iVtx[0] + m_iN;
		iVtx[2] = iVtx[9] + m_iN;
	}

	else if(0==z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] + m_iN;
		iVtx[1] = iVtx[0] - 1;
		iVtx[2] = iVtx[9] - 1;
	}

	else if(0==z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] - 1;			
		}
		else
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] + m_iN;
			iVtx[3] = iVtx[2] - 1;
			iVtx[4] = iVtx[9] - 1;
		}
	}
	
	else if( (m_iN-1) == z && 0==x)
	{
		iVtx[0] = iVtx[9] - m_iN;
		iVtx[1] = iVtx[0] + 1;
		iVtx[2] = iVtx[9] + 1;
	}

	else if( (m_iN-1) == z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] - 1;
		iVtx[1] = iVtx[0] - m_iN;
		iVtx[2] = iVtx[9] - m_iN;

	}

	else if((m_iN-1) == z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
		}
		else
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[0] - m_iN;
			iVtx[2] = iVtx[9] - m_iN;
			iVtx[3] = iVtx[2] + 1;
			iVtx[4] = iVtx[9] + 1;
		}
	}

	else if(0 == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[9] + 1;
			iVtx[2] = iVtx[9] + m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[0] + 1;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[2] + m_iN;
			iVtx[4] = iVtx[9] + m_iN;
		}
	}

	else if((m_iN-1) == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[9] - 1;
			iVtx[2] = iVtx[9] - m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[0] - 1;
			iVtx[2] = iVtx[9] - 1;
			iVtx[3] = iVtx[2] - m_iN;
			iVtx[4] = iVtx[9] - m_iN;
		}
	}
	

	else
	{
		if(index%2)																// Ȧ ��
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[9] + m_iN;
			iVtx[4] = iVtx[0];
		}
		else																	// ¦ ��
		{

//			iVtx[6] = index +m_iN	-1;		iVtx[5] = index + m_iN;	iVtx[4] = index +m_iN	+1;
//			iVtx[7] = index			-1;		iVtx[9] = index		  ;	iVtx[3] = index			+1;
//			iVtx[0] = index -m_iN	-1;		iVtx[1] = index - m_iN;	iVtx[2] = index -m_iN	+1;

			iVtx[6] = index +m_iN	-1;		iVtx[5] = iVtx[6] + 1;	iVtx[4] = iVtx[5] + 1;
			iVtx[7] = index			-1;		iVtx[9] = iVtx[7] + 1;	iVtx[3] = iVtx[9] + 1;
			iVtx[0] = index -m_iN	-1;		iVtx[1] = iVtx[0] + 1;	iVtx[2] = iVtx[1] + 1;
			iVtx[8] = iVtx[0];
		}
	}

	for(i=0; i<8; ++i)
	{
		a = m_pVtx[iVtx[i+0] ].p - m_pVtx[iVtx[9] ].p;
		b = m_pVtx[iVtx[i+1] ].p - m_pVtx[iVtx[9] ].p;
		D3DXVec3Cross(&nT, &a, &b);
		D3DXVec3Normalize(&nT, &nT);
		n +=nT;
	}

	
	D3DXVec3Normalize(&n, &n);
	
	return n;
}



void CMcField::MapLoad()
{
	FILE* fp;
	
	INT x, z;
	TCHAR sFile[] = "Map/Height.raw";

	
	fp = fopen(sFile, "rb");
	
	if(!fp)
	{
		return;
	}
	
	long end;
	
	fseek(fp, 0L, SEEK_SET);	fseek (fp, 0L, SEEK_END);	end	   = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	
	BYTE*	pHi = new BYTE[end];
	fread(pHi, sizeof(BYTE), end, fp);
	fclose(fp);
	
	
	m_dFVF = VtxNUV1::FVF;
	m_iVxS = sizeof(VtxNUV1);
	m_iNvx = end;
	m_iN = int(sqrtf( FLOAT(m_iNvx)));
	m_pVtx = new VtxNUV1[m_iNvx];
	
	for(z=0; z<m_iN; ++z)
	{
		for(x=0; x<m_iN; ++x)
		{
			FLOAT fH = pHi[ (m_iN-1-z) * m_iN + x]*.2f;
			m_pVtx[z * m_iN +x ].p = VEC3(FLOAT(x * m_fW), fH, FLOAT(z * m_fW));

			m_pVtx[z * m_iN +x ].p -= VEC3(m_fW, 0.f, m_fW) * m_iN * 0.5f;
		}
	}
	
	SAFE_DELETE_ARRAY(	pHi	);
	
	
	for(z=0; z<m_iN; ++z)														// ������ UV�� ä���.
	{
		for(x=0; x<m_iN; ++x)
		{
			m_pVtx[z * m_iN +x ].u0 = x /FLOAT(m_iN-1);
			m_pVtx[z * m_iN +x ].v0 = z /FLOAT(m_iN-1);

			m_pVtx[z * m_iN +x ].u1 = x /4.0F;
			m_pVtx[z * m_iN +x ].v1 = z /4.0F;
		}
	}
	

	NormalSet();																// ���� ���͸� ä���.


	
	INT iN = m_iN-1;
	
	m_iNix = 8 * (m_iN-1)/2 * (m_iN-1)/2;
	
	m_pIdx = new VtxIdx[m_iNix];
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iN*z + m_iN+1 + 2*x;
			
			f[6] = index +m_iN-1;	f[5] = index + m_iN;	f[4] = index +m_iN+1;
			f[7] = index      -1;	f[8] = index	   ;	f[3] = index      +1;
			f[0] = index -m_iN-1;	f[1] = index - m_iN;	f[2] = index -m_iN+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pIdx[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}	
}