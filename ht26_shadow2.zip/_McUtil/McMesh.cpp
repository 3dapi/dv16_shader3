// Implementation of the CMcMesh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcMesh::CMcMesh()
{
	m_pDev	= NULL;
	m_pMesh	= NULL;
	m_dMtrl	= 0;
	m_pMtrl	= NULL;
	m_pTex	= NULL;
	
}

CMcMesh::~CMcMesh()
{
	Destroy();
}


INT CMcMesh::Create(LPDIRECT3DDEVICE9 pDev, char* xFileName, char* TexturePath)
{
	HRESULT hr=-1;

	m_pDev = pDev;

	char	sTexPath[MAX_PATH]={0};
	
	if(TexturePath)
	{
		strcpy(sTexPath, TexturePath);

		if('/' == sTexPath[strlen(sTexPath)-1])
			sTexPath[strlen(sTexPath)-1]=0;
	}

	//��Ƽ���� ���۸� �������� ���� �ӽ� ����
	LPD3DXBUFFER pD3DXMtrlBuffer;

	//1. �޽��� ���� �ε��Ѵ�.

	if( FAILED( D3DXLoadMeshFromX( xFileName
		,	D3DXMESH_SYSTEMMEM
		,	m_pDev, NULL
		,	&pD3DXMtrlBuffer, NULL
		,	&m_dMtrl, &m_pMesh ) ) )
	{
		return -1;
	}


	// 2. ��Ƽ����� �ؽ�ó�� �����Ѵ�.
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	m_pMtrl = new D3DMATERIAL9[m_dMtrl];
	m_pTex  = new LPDIRECT3DTEXTURE9[m_dMtrl];

	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		m_pMtrl[i] = d3dxMaterials[i].MatD3D;		// ��Ƽ���� ����
		m_pMtrl[i].Ambient = m_pMtrl[i].Diffuse;	// ��Ƽ������ Ambient ����
		m_pTex[i] = NULL;

		if(NULL == TexturePath)
			continue;


		if( d3dxMaterials[i].pTextureFilename != NULL &&  lstrlen(d3dxMaterials[i].pTextureFilename) > 0 )
		{

			// �ؽ�ó�� �����Ѵ�.
			TCHAR	sFile[260];

			sprintf(sFile, "%s/%s", sTexPath, d3dxMaterials[i].pTextureFilename);

			//�ؽ�ó ����
			hr = D3DXCreateTextureFromFileEx(m_pDev
							, sFile
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, D3DFMT_UNKNOWN
							, D3DPOOL_MANAGED
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, NULL
							, NULL
							, &m_pTex[i]);

			if( FAILED( hr ) )
			{
	//			MessageBox( GetActiveWindow(), "Could not find texture map", "Meshes.exe", MB_OK);
			}

		}
	}

	// �ӽ� ���۸� �����Ѵ�.
	pD3DXMtrlBuffer->Release();




	// Create Star VB
	D3DXVECTOR3	vcCenter;

	INT		nVtx = m_pMesh->GetNumVertices();
	DWORD	dFVF = m_pMesh->GetFVF();
	
	UINT	dStride = D3DXGetFVFVertexSize(dFVF);
	
	void* pSrc;
	m_pMesh->LockVertexBuffer(0, (void**)&pSrc);
		D3DXComputeBoundingSphere((VEC3*)pSrc, nVtx, dStride, &vcCenter, &m_fRadius);
	m_pMesh->UnlockVertexBuffer();

	return 0;
}



void CMcMesh::Destroy()
{
	if(m_pMtrl)
	{
		delete[] m_pMtrl;
		m_pMtrl = NULL;
	
		for( DWORD i = 0; i < m_dMtrl; i++ )
		{
			if( m_pTex[i] )
				m_pTex[i]->Release();
		}

		delete[] m_pTex;
		m_pTex = NULL;
	}

	if(m_pMesh)
	{
		m_pMesh->Release();
		m_pMesh = NULL;
	}
}


INT CMcMesh::FrameMove()
{
	return 0;
}


void CMcMesh::Render(BOOL bUseTexture, BOOL bUseMaterial, BOOL bAlphablending)
{
//	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
//	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
//	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
//	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
//
//	// �ؽ�ó U, V, W�� ��巹�� ��带 Mirror���� �����Ѵ�.
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);
//	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_MIRROR);
//
//	// �ؽ�ó�� ���͸��� Linear�� �����Ѵ�.
//	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
//	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
//	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	if(bAlphablending)
	{
		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

		m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
		m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

		m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
		m_pDev->SetRenderState( D3DRS_ALPHAREF,        156 );
		m_pDev->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATER );
	}


	for( DWORD i=0; i<m_dMtrl; i++ )
	{
		if(bUseTexture)
			m_pDev->SetTexture( 0, m_pTex[i] );

		if(bUseMaterial)
			m_pDev->SetMaterial( &m_pMtrl[i] );

		m_pMesh->DrawSubset( i );
	}


	if(bAlphablending)
	{
		m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	}

	if(bUseTexture)
		m_pDev->SetTexture( 0, NULL);
}


INT CMcMesh::SetFVF(DWORD dwFVF )
{
	LPD3DXMESH pTemp= NULL;

	if(!m_pMesh)
		return -1;


	if(FAILED(m_pMesh->CloneMeshFVF( D3DXMESH_SYSTEMMEM, dwFVF, m_pDev, &pTemp) ) )
		return -1;

	
	m_pMesh->Release();
	m_pMesh = pTemp;

	D3DXComputeNormals( m_pMesh, NULL );

	dwFVF = m_pMesh->GetFVF();

	return 0;
}







