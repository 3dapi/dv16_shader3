// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxUV1
	{
		VEC3	p;
		FLOAT	u, v;
		
		VtxUV1()					: p(0,0,0),u(0),v(0){}
		VtxUV1(FLOAT X, FLOAT Y
				, FLOAT U, FLOAT V)	: p(X,Y,0),u(U),v(V){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_TEX1)	};
		
	};

protected:
	PDEV		m_pDev;				// Device

	PDEF		m_pEft;				// ID3DXEffect*
	PDVD		m_pFVF;				// Declarator

	MATA		m_mtWld;			// Wolrd Matrix
	VtxUV1		m_pVtx[4];

	PDTX		m_pTex;
	FLOAT		m_Time;

public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

