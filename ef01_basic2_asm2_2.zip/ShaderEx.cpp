// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;

	m_pFVF	= NULL;
	m_pEft	= NULL;

	m_pTex	= NULL;
	m_Time	= 0.f;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	
	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER pErr = NULL;
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	

	DWORD	dFVF = VtxUV1::FVF;
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	m_pVtx[0] = VtxUV1( -1.0f,  1.0f, 0.0f, 0.0f );
	m_pVtx[1] = VtxUV1(  1.0f,  1.0f, 1.0f, 0.0f );
	m_pVtx[2] = VtxUV1(  1.0f, -1.0f, 1.0f, 1.0f );
	m_pVtx[3] = VtxUV1( -1.0f, -1.0f, 0.0f, 1.0f );
	
	hr = D3DXCreateTextureFromFile(m_pDev, "texture/cloudsTurb256.tga", &m_pTex);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);

	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::FrameMove()
{
	m_Time	= g_pApp->m_fTime;

	// Update World Matrix
	D3DXMatrixIdentity(&m_mtWld);
	
	return 0;
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


void CShaderEx::Render()
{
	D3DXMATRIX  mtViw;
	D3DXMATRIX  mtPrj;

	D3DXMatrixIdentity( &mtViw);
	D3DXMatrixIdentity( &mtPrj);
	
	m_pDev->SetVertexDeclaration( m_pFVF);

	D3DXVECTOR4 cv[6];
	D3DXMATRIX	mtTM = m_mtWld * mtViw * mtPrj;
	memcpy(cv, &mtTM, sizeof(D3DXVECTOR4)*4);
	cv[4] = D3DXVECTOR4( (float)m_Time*0.02585f,(float)m_Time*0.00515f, 0.0f, 0.0f);


	D3DXVECTOR4 cp[8];
	cp[0] = D3DXVECTOR4( 0.0f, 0.5f, 1.0f, .75f);
	cp[1] = D3DXVECTOR4( .07f, .07f, 0.0f, 0.0f);
	cp[2] = D3DXVECTOR4( 1.0f, 0.7f, 0.5f, 1.0f);
	cp[3] = D3DXVECTOR4( 0.2f, 0.2f, 0.0f, 0.0f);
	cp[4] = D3DXVECTOR4( 1.0f, 0.7f, 0.5f, 1.0f);
	cp[5] = D3DXVECTOR4( 0.7f, 0.0f, 0.7f, 1.0f);
	cp[6] = D3DXVECTOR4( 0.0f, 0.0f, 0.7f, 1.0f);


	m_pEft->SetVectorArray( "m_cv", cv, 6);
	m_pEft->SetVectorArray( "m_cp", cp, 8);
	m_pEft->SetTexture("m_pTex", m_pTex);

	m_pEft->SetTechnique("Tech0");

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1) );

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);
}


